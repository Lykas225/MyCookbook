# MyCookbook (com.mycookbook.app)

Android-приложение «Моя кулинарная книга»: рецепты, пошаговые видеоуроки, фото/видео архив,
таймер, калькулятор порций, план питания.

## Как собрать APK через GitHub
1. Загрузите всё содержимое этой папки в репозиторий (папка `.github` должна быть в корне).
2. Откройте вкладку **Actions → Build APK → Run workflow** (или просто сделайте commit в `main`).
3. Когда сборка завершится, скачайте артефакт **MyCookbook-APK** — внутри `app-debug.apk`.

## Локальная сборка
Android Studio (Ladybug+) → Open → Run. Либо `gradle assembleDebug` (Gradle 8.9, JDK 17).
