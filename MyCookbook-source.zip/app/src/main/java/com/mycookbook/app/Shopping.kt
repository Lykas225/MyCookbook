@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

fun shopAmount(it: ShopItem): String {
    val s = ingredientLine(Ingredient(it.name, it.amount, it.unit), 1.0)
    return if (s.isBlank()) "" else " — " + s
}

@Composable
fun ShoppingScreen(store: CookbookStore, nav: NavHostController) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }
    var picker by remember { mutableStateOf(false) }
    val open = store.shopping.filter { !it.done }
    val done = store.shopping.filter { it.done }

    fun share() {
        val text = (open.map { "☐ " + it.name + shopAmount(it) } + done.map { "☑ " + it.name }).joinToString("\n")
        val i = android.content.Intent(android.content.Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(android.content.Intent.EXTRA_TEXT, "Список покупок\n" + text)
        ctx.startActivity(android.content.Intent.createChooser(i, "Поделиться списком"))
    }

    fun fromPlan() {
        val today = java.time.LocalDate.now().toString()
        var n = 0
        store.plan.forEach { (k, rid) ->
            if (k.substringBefore('|') >= today) {
                val r = store.recipe(rid)
                if (r != null) {
                    store.addShopRecipe(r, r.servings)
                    n++
                }
            }
        }
        Toast.makeText(ctx, if (n > 0) "Добавлены продукты для блюд: $n" else "В плане на ближайшие дни нет блюд", Toast.LENGTH_LONG).show()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Список покупок") },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } },
                actions = {
                    IconButton(onClick = { share() }, enabled = store.shopping.isNotEmpty()) { Icon(Icons.Filled.Share, "Поделиться") }
                    IconButton(onClick = { store.clearDoneShop() }, enabled = done.isNotEmpty()) { Icon(Icons.Filled.Delete, "Убрать купленное") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize().imePadding(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        name, { name = it },
                        placeholder = { Text("Что купить? Например: молоко 1 л") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = {
                        val t = name.trim()
                        if (t.isNotEmpty()) {
                            store.addShop(t, 0.0, "")
                            name = ""
                        }
                    }) { Icon(Icons.Filled.Add, "Добавить") }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { fromPlan() }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp)) {
                        Text("📅 Из плана", maxLines = 1)
                    }
                    OutlinedButton(onClick = { picker = true }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp)) {
                        Text("📖 Из рецепта", maxLines = 1)
                    }
                }
            }
            if (store.shopping.isEmpty()) {
                item { HintText("Список пуст. Добавьте продукты вручную, из плана питания, из рецепта или попросите ИИ-помощника.") }
            }
            items(open, key = { it.id }) { it2 ->
                ShopRow(store, it2)
            }
            if (done.isNotEmpty()) {
                item { Text("Куплено", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp)) }
                items(done, key = { it.id }) { it2 ->
                    ShopRow(store, it2)
                }
            }
        }
    }

    if (picker) {
        RecipePickerDialog(
            recipes = store.recipes.sortedBy { it.title.lowercase() },
            title = "Продукты из рецепта",
            allowClear = false,
            onPick = { r ->
                if (r != null) {
                    store.addShopRecipe(r, r.servings)
                    Toast.makeText(ctx, "Продукты добавлены", Toast.LENGTH_SHORT).show()
                }
                picker = false
            },
            onDismiss = { picker = false }
        )
    }
}

@Composable
fun ShopRow(store: CookbookStore, item: ShopItem) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = item.done, onCheckedChange = { store.toggleShop(item.id) })
            Text(
                item.name + shopAmount(item),
                modifier = Modifier.weight(1f),
                textDecoration = if (item.done) androidx.compose.ui.text.style.TextDecoration.LineThrough else null,
                color = if (item.done) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
            )
            IconButton(onClick = { store.removeShop(item.id) }) { Icon(Icons.Filled.Close, "Удалить") }
        }
    }
}
