@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

private fun <T> JSONArray?.objs(f: (JSONObject) -> T): List<T> {
    if (this == null) return emptyList()
    val out = ArrayList<T>()
    for (i in 0 until length()) out.add(f(getJSONObject(i)))
    return out
}

private fun recipeToJson(r: Recipe): JSONObject {
    val o = JSONObject()
    o.put("id", r.id)
    o.put("title", r.title)
    o.put("category", r.category)
    o.put("description", r.description)
    o.put("servings", r.servings)
    o.put("tempC", r.tempC)
    o.put("timeMin", r.timeMin)
    o.put("notes", r.notes)
    o.put("secrets", r.secrets)
    o.put("favorite", r.favorite)
    o.put("lastViewed", r.lastViewed)
    o.put("createdAt", r.createdAt)
    val ing = JSONArray()
    r.ingredients.forEach { i ->
        val j = JSONObject()
        j.put("name", i.name)
        j.put("amount", i.amount)
        j.put("unit", i.unit)
        ing.put(j)
    }
    o.put("ingredients", ing)
    val st = JSONArray()
    r.steps.forEach { s ->
        val j = JSONObject()
        j.put("text", s.text)
        j.put("timerMin", s.timerMin)
        j.put("mediaPath", s.mediaPath ?: JSONObject.NULL)
        j.put("video", s.mediaIsVideo)
        st.put(j)
    }
    o.put("steps", st)
    return o
}

private fun recipeFromJson(o: JSONObject): Recipe = Recipe(
    id = o.getString("id"),
    title = o.optString("title"),
    category = o.optInt("category", 0),
    description = o.optString("description"),
    servings = o.optInt("servings", 1).coerceAtLeast(1),
    ingredients = o.optJSONArray("ingredients").objs {
        Ingredient(it.optString("name"), it.optDouble("amount", 0.0), it.optString("unit", "г"))
    },
    tempC = o.optInt("tempC", 0),
    timeMin = o.optInt("timeMin", 0),
    notes = o.optString("notes"),
    secrets = o.optString("secrets"),
    steps = o.optJSONArray("steps").objs {
        Step(
            it.optString("text"),
            it.optInt("timerMin", 0),
            if (it.isNull("mediaPath")) null else it.optString("mediaPath"),
            it.optBoolean("video", false)
        )
    },
    favorite = o.optBoolean("favorite", false),
    lastViewed = o.optLong("lastViewed", 0L),
    createdAt = o.optLong("createdAt", 0L)
)

private fun mediaToJson(m: MediaItem): JSONObject {
    val o = JSONObject()
    o.put("id", m.id)
    o.put("path", m.path)
    o.put("video", m.isVideo)
    o.put("recipeId", m.recipeId ?: JSONObject.NULL)
    o.put("addedAt", m.addedAt)
    return o
}

private fun mediaFromJson(o: JSONObject): MediaItem = MediaItem(
    id = o.getString("id"),
    path = o.getString("path"),
    isVideo = o.optBoolean("video", false),
    recipeId = if (o.isNull("recipeId")) null else o.optString("recipeId"),
    addedAt = o.optLong("addedAt", 0L)
)

class CookbookStore(private val ctx: Context) {
    private val file = File(ctx.filesDir, "cookbook.json")
    private val prefs = ctx.getSharedPreferences("cookbook_prefs", Context.MODE_PRIVATE)

    var recipes by mutableStateOf<List<Recipe>>(emptyList())
        private set
    var media by mutableStateOf<List<MediaItem>>(emptyList())
        private set
    var plan by mutableStateOf<Map<String, String>>(emptyMap())
        private set
    var wallpaper by mutableIntStateOf(prefs.getInt("wallpaper", 1))
        private set

    init {
        load()
    }

    private fun load() {
        if (!file.exists()) {
            recipes = seedRecipes()
            save()
            return
        }
        try {
            val o = JSONObject(file.readText())
            recipes = o.optJSONArray("recipes").objs { recipeFromJson(it) }
            media = o.optJSONArray("media").objs { mediaFromJson(it) }
            val p = o.optJSONObject("plan")
            val m = HashMap<String, String>()
            if (p != null) {
                val keys = p.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    m[k] = p.getString(k)
                }
            }
            plan = m
        } catch (e: Exception) {
            // keep whatever was loaded
        }
    }

    private fun save() {
        try {
            val o = JSONObject()
            val ra = JSONArray()
            recipes.forEach { ra.put(recipeToJson(it)) }
            o.put("recipes", ra)
            val ma = JSONArray()
            media.forEach { ma.put(mediaToJson(it)) }
            o.put("media", ma)
            val po = JSONObject()
            plan.forEach { (k, v) -> po.put(k, v) }
            o.put("plan", po)
            val tmp = File(ctx.filesDir, "cookbook.json.tmp")
            tmp.writeText(o.toString())
            tmp.renameTo(file)
        } catch (e: Exception) {
            // ignore
        }
    }

    fun recipe(id: String): Recipe? = recipes.firstOrNull { it.id == id }

    fun mediaOf(recipeId: String): List<MediaItem> =
        media.filter { it.recipeId == recipeId && File(it.path).exists() }.sortedByDescending { it.addedAt }

    fun coverOf(recipeId: String): MediaItem? {
        val l = media.filter { it.recipeId == recipeId && File(it.path).exists() }.sortedBy { it.addedAt }
        return l.firstOrNull { !it.isVideo } ?: l.firstOrNull()
    }

    fun saveRecipe(r: Recipe, mediaList: List<MediaItem>) {
        val keep = mediaList.map { it.id }.toSet()
        media.filter { it.recipeId == r.id && it.id !in keep }.forEach { File(it.path).delete() }
        val others = media.filter { it.recipeId != r.id }
        val merged = mediaList.toMutableList()
        r.steps.forEach { s ->
            val p = s.mediaPath
            if (p != null && merged.none { it.path == p }) {
                merged.add(MediaItem(UUID.randomUUID().toString(), p, s.mediaIsVideo, r.id, System.currentTimeMillis()))
            }
        }
        media = others + merged
        recipes = if (recipes.any { it.id == r.id }) recipes.map { if (it.id == r.id) r else it } else listOf(r) + recipes
        save()
    }

    fun deleteRecipe(id: String) {
        recipes = recipes.filter { it.id != id }
        media = media.map { if (it.recipeId == id) it.copy(recipeId = null) else it }
        plan = plan.filterValues { it != id }
        save()
    }

    fun toggleFavorite(id: String) {
        recipes = recipes.map { if (it.id == id) it.copy(favorite = !it.favorite) else it }
        save()
    }

    fun markViewed(id: String) {
        recipes = recipes.map { if (it.id == id) it.copy(lastViewed = System.currentTimeMillis()) else it }
        save()
    }

    fun addMedia(path: String, isVideo: Boolean, recipeId: String?) {
        media = listOf(MediaItem(UUID.randomUUID().toString(), path, isVideo, recipeId, System.currentTimeMillis())) + media
        save()
    }

    fun linkMedia(id: String, recipeId: String?) {
        media = media.map { if (it.id == id) it.copy(recipeId = recipeId) else it }
        save()
    }

    fun deleteMedia(id: String) {
        media.firstOrNull { it.id == id }?.let { File(it.path).delete() }
        media = media.filter { it.id != id }
        save()
    }

    fun exportData(): JSONObject {
        fun nm(p: String) = File(p).name
        val rs = recipes.map { r -> r.copy(steps = r.steps.map { s -> s.copy(mediaPath = s.mediaPath?.let { nm(it) }) }) }
        val ms = media.map { it.copy(path = nm(it.path)) }
        val o = JSONObject()
        o.put("format", 1)
        val ra = JSONArray()
        rs.forEach { ra.put(recipeToJson(it)) }
        o.put("recipes", ra)
        val ma = JSONArray()
        ms.forEach { ma.put(mediaToJson(it)) }
        o.put("media", ma)
        val po = JSONObject()
        plan.forEach { (k, v) -> po.put(k, v) }
        o.put("plan", po)
        return o
    }

    fun importData(o: JSONObject, mediaDir: File, replace: Boolean): Int {
        fun fixPath(p: String): String = File(mediaDir, File(p).name).absolutePath
        val rs = o.optJSONArray("recipes").objs { recipeFromJson(it) }
            .map { r -> r.copy(steps = r.steps.map { s -> s.copy(mediaPath = s.mediaPath?.let { fixPath(it) }) }) }
        val ms = o.optJSONArray("media").objs { mediaFromJson(it) }.map { it.copy(path = fixPath(it.path)) }
        val pm = HashMap<String, String>()
        val p = o.optJSONObject("plan")
        if (p != null) {
            val keys = p.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                pm[k] = p.getString(k)
            }
        }
        val added: Int
        if (replace) {
            recipes = rs
            media = ms
            plan = pm
            added = rs.size
        } else {
            val ids = recipes.map { it.id }.toSet()
            val newR = rs.filter { it.id !in ids }
            added = newR.size
            val mids = media.map { it.id }.toSet()
            recipes = recipes + newR
            media = media + ms.filter { it.id !in mids }
            plan = pm + plan
        }
        save()
        return added
    }

    fun setPlan(date: String, slot: Int, recipeId: String?) {
        val k = "$date|$slot"
        plan = if (recipeId == null) plan - k else plan + (k to recipeId)
        save()
    }

    fun chooseWallpaper(i: Int) {
        wallpaper = i
        prefs.edit().putInt("wallpaper", i).apply()
    }
}
