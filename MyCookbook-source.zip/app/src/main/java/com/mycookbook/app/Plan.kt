@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

@Composable
fun PlanScreen(store: CookbookStore, nav: NavHostController) {
    var weekOffset by remember { mutableIntStateOf(0) }
    var picking by remember { mutableStateOf<Pair<String, Int>?>(null) }
    val today = java.time.LocalDate.now()
    val monday = today.with(java.time.DayOfWeek.MONDAY).plusWeeks(weekOffset.toLong())
    val ru = Locale("ru")
    val days = (0..6).map { monday.plusDays(it.toLong()) }

    fun dayTitle(d: java.time.LocalDate): String {
        val dn = d.dayOfWeek.getDisplayName(java.time.format.TextStyle.SHORT, ru).replaceFirstChar { it.uppercase() }
        val mn = d.month.getDisplayName(java.time.format.TextStyle.SHORT, ru)
        return "$dn, ${d.dayOfMonth} $mn"
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column(Modifier.statusBarsPadding().padding(top = 12.dp)) {
                Text("План питания", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                OutlinedButton(onClick = { nav.navigate("shopping") }) {
                    Icon(Icons.Filled.ShoppingCart, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Список покупок")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { weekOffset-- }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Прошлая неделя") }
                    Text(
                        dayTitle(days.first()) + " — " + dayTitle(days.last()),
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    IconButton(onClick = { weekOffset++ }) { Icon(Icons.AutoMirrored.Filled.ArrowForward, "Следующая неделя") }
                }
                if (weekOffset != 0) {
                    TextButton(onClick = { weekOffset = 0 }) { Text("Вернуться к этой неделе") }
                }
            }
        }
        items(days, key = { it.toString() }) { d ->
            val isToday = d == today
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isToday) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text(dayTitle(d) + if (isToday) "  •  сегодня" else "", fontWeight = FontWeight.Bold)
                    MEALS.forEachIndexed { slot, label ->
                        val rid = store.plan["$d|$slot"]
                        val r = rid?.let { store.recipe(it) }
                        Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(label, modifier = Modifier.width(100.dp), style = MaterialTheme.typography.bodyMedium)
                            Text(
                                r?.title ?: "—",
                                modifier = Modifier
                                    .weight(1f)
                                    .then(if (r != null) Modifier.clickable { nav.navigate("recipe/${r.id}") } else Modifier),
                                color = if (r != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = if (r != null) FontWeight.SemiBold else FontWeight.Normal,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            IconButton(onClick = { picking = d.toString() to slot }, modifier = Modifier.size(36.dp)) {
                                Icon(if (r == null) Icons.Filled.Add else Icons.Filled.Edit, "Выбрать блюдо")
                            }
                        }
                    }
                }
            }
        }
    }

    picking?.let { (date, slot) ->
        RecipePickerDialog(
            recipes = store.recipes.sortedBy { it.title.lowercase() },
            title = MEALS[slot],
            allowClear = true,
            onPick = { store.setPlan(date, slot, it?.id); picking = null },
            onDismiss = { picking = null }
        )
    }
}
