@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

class IngEdit(name: String = "", amount: String = "", unit: String = "г") {
    var name by mutableStateOf(name)
    var amount by mutableStateOf(amount)
    var unit by mutableStateOf(unit)
}

class StepEdit(text: String = "", timer: String = "", mediaPath: String? = null, isVideo: Boolean = false) {
    var text by mutableStateOf(text)
    var timer by mutableStateOf(timer)
    var mediaPath by mutableStateOf(mediaPath)
    var isVideo by mutableStateOf(isVideo)
}

@Composable
fun MediaMenuButton(label: String, actions: MediaActions, onOpen: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { onOpen(); open = true }, contentPadding = PaddingValues(horizontal = 12.dp)) {
            Icon(Icons.Filled.CameraAlt, null, Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(label, fontSize = 13.sp, maxLines = 1)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(text = { Text("📷 Сделать фото") }, onClick = { open = false; actions.takePhoto() })
            DropdownMenuItem(text = { Text("🖼 Фото из галереи") }, onClick = { open = false; actions.pickPhoto() })
            DropdownMenuItem(text = { Text("🎥 Снять видео") }, onClick = { open = false; actions.recordVideo() })
            DropdownMenuItem(text = { Text("📁 Видео из телефона") }, onClick = { open = false; actions.pickVideo() })
        }
    }
}

@Composable
fun EditorScreen(store: CookbookStore, id: String, nav: NavHostController) {
    val existing = remember(id) { store.recipe(id) }
    val recipeId = remember(id) { existing?.id ?: UUID.randomUUID().toString() }

    var title by remember { mutableStateOf(existing?.title ?: "") }
    var category by remember { mutableIntStateOf(existing?.category ?: 0) }
    var description by remember { mutableStateOf(existing?.description ?: "") }
    var servings by remember { mutableStateOf((existing?.servings ?: 4).toString()) }
    var timeMin by remember { mutableStateOf(existing?.timeMin?.takeIf { it > 0 }?.toString() ?: "") }
    var temp by remember { mutableStateOf(existing?.tempC?.takeIf { it > 0 }?.toString() ?: "") }
    var secrets by remember { mutableStateOf(existing?.secrets ?: "") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }

    val ingredients = remember {
        mutableStateListOf<IngEdit>().also { l ->
            existing?.ingredients?.forEach { l.add(IngEdit(it.name, if (it.amount > 0) formatAmount(it.amount) else "", it.unit)) }
            if (l.isEmpty()) l.add(IngEdit())
        }
    }
    val steps = remember {
        mutableStateListOf<StepEdit>().also { l ->
            existing?.steps?.forEach { l.add(StepEdit(it.text, if (it.timerMin > 0) it.timerMin.toString() else "", it.mediaPath, it.mediaIsVideo)) }
            if (l.isEmpty()) l.add(StepEdit())
        }
    }
    val initialIds = remember { store.media.filter { it.recipeId == recipeId }.map { it.id }.toSet() }
    val media = remember { mutableStateListOf<MediaItem>().also { it.addAll(store.media.filter { m -> m.recipeId == recipeId }) } }
    var target by remember { mutableIntStateOf(-1) }

    val actions = rememberMediaActions { path, video ->
        val t = target
        if (t >= 0 && t < steps.size) {
            steps[t].mediaPath = path
            steps[t].isVideo = video
        } else {
            media.add(MediaItem(UUID.randomUUID().toString(), path, video, recipeId, System.currentTimeMillis()))
        }
    }

    fun cancel() {
        media.filter { it.id !in initialIds }.forEach { File(it.path).delete() }
        nav.popBackStack()
    }

    fun save() {
        val r = Recipe(
            id = recipeId,
            title = title.trim().ifBlank { "Без названия" },
            category = category,
            description = description.trim(),
            servings = (servings.toIntOrNull() ?: 1).coerceAtLeast(1),
            ingredients = ingredients.filter { it.name.isNotBlank() }.map { Ingredient(it.name.trim(), parseNum(it.amount), it.unit) },
            tempC = temp.toIntOrNull() ?: 0,
            timeMin = timeMin.toIntOrNull() ?: 0,
            notes = notes.trim(),
            secrets = secrets.trim(),
            steps = steps.filter { it.text.isNotBlank() || it.mediaPath != null }
                .map { Step(it.text.trim(), it.timer.toIntOrNull() ?: 0, it.mediaPath, it.isVideo) },
            favorite = existing?.favorite ?: false,
            lastViewed = existing?.lastViewed ?: 0L,
            createdAt = existing?.createdAt ?: System.currentTimeMillis()
        )
        store.saveRecipe(r, media.toList())
        nav.popBackStack()
    }

    BackHandler { cancel() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (existing == null) "Новый рецепт" else "Редактирование") },
                navigationIcon = { IconButton(onClick = { cancel() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } },
                actions = { TextButton(onClick = { save() }) { Text("Сохранить", fontWeight = FontWeight.Bold) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(title, { title = it }, label = { Text("Название блюда") }, singleLine = true, modifier = Modifier.fillMaxWidth())

            Text("Категория", style = MaterialTheme.typography.labelLarge)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CATEGORIES.forEachIndexed { i, c ->
                    FilterChip(selected = category == i, onClick = { category = i }, label = { Text(c.first + " " + c.second) })
                }
            }

            OutlinedTextField(description, { description = it }, label = { Text("Краткое описание") }, modifier = Modifier.fillMaxWidth())

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    servings, { v -> if (v.all { it.isDigit() } && v.length <= 2) servings = v },
                    label = { Text("Порций") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    timeMin, { v -> if (v.all { it.isDigit() } && v.length <= 4) timeMin = v },
                    label = { Text("Время, мин") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    temp, { v -> if (v.all { it.isDigit() } && v.length <= 3) temp = v },
                    label = { Text("°C") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f)
                )
            }

            Text("Ингредиенты и граммовки", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            ingredients.forEachIndexed { idx, ing ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(ing.name, { ing.name = it }, label = { Text("Продукт") }, singleLine = true, modifier = Modifier.weight(1.6f))
                    Spacer(Modifier.width(6.dp))
                    OutlinedTextField(
                        ing.amount, { v -> if (v.all { it.isDigit() || it == ',' || it == '.' }) ing.amount = v },
                        label = { Text("Кол-во") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f)
                    )
                    UnitButton(ing.unit) { ing.unit = it }
                    IconButton(onClick = { if (ingredients.size > 1) ingredients.removeAt(idx) else { ing.name = ""; ing.amount = "" } }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Filled.Close, "Удалить")
                    }
                }
            }
            OutlinedButton(onClick = { ingredients.add(IngEdit()) }) {
                Icon(Icons.Filled.Add, null)
                Spacer(Modifier.width(6.dp))
                Text("Добавить продукт")
            }

            Text("Как приготовить (пошагово)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            steps.forEachIndexed { idx, st ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Шаг ${idx + 1}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            IconButton(onClick = { if (steps.size > 1) steps.removeAt(idx) else { st.text = ""; st.timer = ""; st.mediaPath = null } }, modifier = Modifier.size(36.dp)) {
                                Icon(Icons.Filled.Close, "Удалить шаг")
                            }
                        }
                        OutlinedTextField(st.text, { st.text = it }, label = { Text("Что нужно сделать") }, modifier = Modifier.fillMaxWidth())
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                st.timer, { v -> if (v.all { it.isDigit() } && v.length <= 4) st.timer = v },
                                label = { Text("Таймер, мин") }, singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f)
                            )
                            MediaMenuButton("Фото / видео", actions) { target = idx }
                        }
                        val mp = st.mediaPath
                        if (mp != null) {
                            Box {
                                MediaThumb(mp, st.isVideo, Modifier.size(width = 160.dp, height = 100.dp))
                                IconButton(
                                    onClick = { st.mediaPath = null },
                                    modifier = Modifier.align(Alignment.TopEnd).size(30.dp).background(Color(0x99000000), CircleShape)
                                ) { Icon(Icons.Filled.Close, "Убрать", tint = Color.White, modifier = Modifier.size(16.dp)) }
                            }
                        }
                    }
                }
            }
            OutlinedButton(onClick = { steps.add(StepEdit()) }) {
                Icon(Icons.Filled.Add, null)
                Spacer(Modifier.width(6.dp))
                Text("Добавить шаг")
            }

            OutlinedTextField(secrets, { secrets = it }, label = { Text("💡 Секреты и хитрости") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(notes, { notes = it }, label = { Text("📝 Личные заметки") }, modifier = Modifier.fillMaxWidth())

            Text("Фото и видео блюда", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (media.isNotEmpty()) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    media.forEach { m ->
                        Box {
                            MediaThumb(m.path, m.isVideo, Modifier.size(100.dp))
                            IconButton(
                                onClick = { media.remove(m) },
                                modifier = Modifier.align(Alignment.TopEnd).size(30.dp).background(Color(0x99000000), CircleShape)
                            ) { Icon(Icons.Filled.Close, "Убрать", tint = Color.White, modifier = Modifier.size(16.dp)) }
                        }
                    }
                }
            }
            MediaAddButtons(actions) { target = -1 }

            Button(onClick = { save() }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                Text("Сохранить рецепт", fontSize = 16.sp)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
