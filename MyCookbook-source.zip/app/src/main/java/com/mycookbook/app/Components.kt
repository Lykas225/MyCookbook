@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

fun formatAmount(a: Double): String {
    val r = Math.round(a * 100) / 100.0
    val s = if (r == Math.floor(r)) r.toLong().toString() else r.toString()
    return s.replace('.', ',')
}

fun parseNum(s: String): Double = s.replace(',', '.').toDoubleOrNull() ?: 0.0

fun formatTime(min: Int): String {
    if (min <= 0) return ""
    val h = min / 60
    val m = min % 60
    return when {
        h == 0 -> "$m мин"
        m == 0 -> "$h ч"
        else -> "$h ч $m мин"
    }
}

fun formatClock(sec: Int): String {
    val s = sec.coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val ss = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, ss)
    else String.format(Locale.US, "%02d:%02d", m, ss)
}

fun ingredientLine(i: Ingredient, factor: Double): String {
    val amount = if (i.unit == "по вкусу" || i.amount <= 0.0) "" else formatAmount(i.amount * factor) + " "
    return amount + (if (amount.isEmpty() && i.unit.isEmpty()) "" else i.unit)
}

class MediaActions(
    val takePhoto: () -> Unit,
    val pickPhoto: () -> Unit,
    val recordVideo: () -> Unit,
    val pickVideo: () -> Unit
)

@Composable
fun rememberMediaActions(onAdded: (String, Boolean) -> Unit): MediaActions {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cb = rememberUpdatedState(onAdded)
    var pending by remember { mutableStateOf<File?>(null) }

    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = pending
        pending = null
        if (f != null) {
            if (ok && f.exists() && f.length() > 0) cb.value(f.absolutePath, false) else f.delete()
        }
    }
    val videoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CaptureVideo()) { ok ->
        val f = pending
        pending = null
        if (f != null) {
            if (ok && f.exists() && f.length() > 0) cb.value(f.absolutePath, true) else f.delete()
        }
    }
    val pickImages = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        scope.launch {
            for (u in uris) {
                val p = withContext(Dispatchers.IO) { MediaFiles.copyFrom(ctx, u, false) }
                if (p != null) cb.value(p, false)
            }
        }
    }
    val pickVideos = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        scope.launch {
            for (u in uris) {
                val p = withContext(Dispatchers.IO) { MediaFiles.copyFrom(ctx, u, true) }
                if (p != null) cb.value(p, true)
            }
        }
    }

    return remember {
        MediaActions(
            takePhoto = {
                try {
                    val f = MediaFiles.newFile(ctx, false)
                    pending = f
                    photoLauncher.launch(MediaFiles.uriFor(ctx, f))
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Не удалось открыть камеру", Toast.LENGTH_SHORT).show()
                }
            },
            pickPhoto = {
                try {
                    pickImages.launch("image/*")
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Галерея недоступна", Toast.LENGTH_SHORT).show()
                }
            },
            recordVideo = {
                try {
                    val f = MediaFiles.newFile(ctx, true)
                    pending = f
                    videoLauncher.launch(MediaFiles.uriFor(ctx, f))
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Не удалось открыть камеру", Toast.LENGTH_SHORT).show()
                }
            },
            pickVideo = {
                try {
                    pickVideos.launch("video/*")
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Галерея недоступна", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }
}

@Composable
fun MediaAddButtons(actions: MediaActions, onBefore: () -> Unit = {}) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(
                onClick = { onBefore(); actions.takePhoto() },
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 8.dp)
            ) {
                Icon(Icons.Filled.CameraAlt, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Сделать фото", fontSize = 13.sp, maxLines = 1)
            }
            FilledTonalButton(
                onClick = { onBefore(); actions.pickPhoto() },
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 8.dp)
            ) {
                Icon(Icons.Filled.PhotoLibrary, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Из галереи", fontSize = 13.sp, maxLines = 1)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(
                onClick = { onBefore(); actions.recordVideo() },
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 8.dp)
            ) {
                Icon(Icons.Filled.Videocam, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Снять видео", fontSize = 13.sp, maxLines = 1)
            }
            FilledTonalButton(
                onClick = { onBefore(); actions.pickVideo() },
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 8.dp)
            ) {
                Icon(Icons.Filled.VideoLibrary, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Видео из телефона", fontSize = 13.sp, maxLines = 1)
            }
        }
    }
}

@Composable
fun MediaThumb(path: String, isVideo: Boolean, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null) {
    Box(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = File(path),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        if (isVideo) {
            Icon(Icons.Filled.PlayCircle, null, tint = Color.White, modifier = Modifier.size(36.dp))
        }
    }
}

@Composable
fun RecipeImage(store: CookbookStore, recipe: Recipe, modifier: Modifier) {
    val cover = store.coverOf(recipe.id)
    if (cover != null) {
        MediaThumb(cover.path, cover.isVideo, modifier)
    } else {
        Box(
            modifier
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Text(CATEGORIES.getOrNull(recipe.category)?.first ?: "🍽", fontSize = 30.sp)
        }
    }
}

@Composable
fun RecipeRow(store: CookbookStore, recipe: Recipe, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            RecipeImage(store, recipe, Modifier.size(72.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(recipe.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(
                    CATEGORIES.getOrNull(recipe.category)?.second ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                val meta = listOfNotNull(
                    if (recipe.timeMin > 0) "⏱ " + formatTime(recipe.timeMin) else null,
                    if (recipe.tempC > 0) "🌡 ${recipe.tempC}°C" else null,
                    "🍽 ${recipe.servings}"
                ).joinToString("  ")
                Text(meta, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (recipe.favorite) {
                Icon(Icons.Filled.Favorite, null, tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
fun RecipeTile(store: CookbookStore, recipe: Recipe, onClick: () -> Unit) {
    Column(
        Modifier
            .width(150.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
    ) {
        RecipeImage(store, recipe, Modifier.size(150.dp))
        Spacer(Modifier.height(6.dp))
        Text(recipe.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        modifier = modifier.padding(horizontal = 16.dp, vertical = 10.dp)
    )
}

@Composable
fun HintText(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
    )
}

@Composable
fun InfoChip(text: String) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.primaryContainer)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
    }
}

@Composable
fun VideoPlayer(path: String, modifier: Modifier = Modifier) {
    AndroidView(
        factory = { c ->
            VideoView(c).apply {
                val mc = MediaController(c)
                mc.setAnchorView(this)
                setMediaController(mc)
                setVideoPath(path)
                setOnPreparedListener { it.start() }
            }
        },
        modifier = modifier
    )
}

@Composable
fun FullscreenMedia(
    path: String,
    isVideo: Boolean,
    onDismiss: () -> Unit,
    actions: @Composable RowScope.() -> Unit = {}
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            if (isVideo) {
                VideoPlayer(path, Modifier.fillMaxSize().padding(top = 96.dp, bottom = 24.dp))
            } else {
                AsyncImage(
                    model = File(path),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(top = 96.dp)
                )
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .padding(horizontal = 8.dp, vertical = 24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                actions()
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Filled.Close, "Закрыть", tint = Color.White)
                }
            }
        }
    }
}

@Composable
fun RecipePickerDialog(
    recipes: List<Recipe>,
    title: String,
    allowClear: Boolean,
    onPick: (Recipe?) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            LazyColumn(Modifier.heightIn(max = 360.dp)) {
                if (allowClear) {
                    item {
                        TextButton(onClick = { onPick(null) }) { Text("— Не привязывать / очистить —") }
                    }
                }
                if (recipes.isEmpty()) {
                    item { Text("Пока нет рецептов") }
                }
                items(recipes, key = { it.id }) { r ->
                    Text(
                        (CATEGORIES.getOrNull(r.category)?.first ?: "🍽") + "  " + r.title,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPick(r) }
                            .padding(vertical = 12.dp)
                    )
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
fun MediaViewerDialog(item: MediaItem, store: CookbookStore, onDismiss: () -> Unit) {
    var picker by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    val cur = store.media.firstOrNull { it.id == item.id } ?: item
    val recipeName = cur.recipeId?.let { store.recipe(it)?.title }

    FullscreenMedia(item.path, item.isVideo, onDismiss, actions = {
        TextButton(onClick = { picker = true }) {
            Icon(Icons.Filled.Link, null, tint = Color.White)
            Spacer(Modifier.width(6.dp))
            Text(recipeName ?: "Привязать к рецепту", color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 170.dp))
        }
        IconButton(onClick = { confirm = true }) {
            Icon(Icons.Filled.Delete, "Удалить", tint = Color.White)
        }
    })

    if (picker) {
        RecipePickerDialog(
            recipes = store.recipes,
            title = "Привязать к рецепту",
            allowClear = true,
            onPick = { store.linkMedia(item.id, it?.id); picker = false },
            onDismiss = { picker = false }
        )
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Удалить файл?") },
            text = { Text("Фото или видео будет удалено с телефона.") },
            confirmButton = {
                TextButton(onClick = { store.deleteMedia(item.id); confirm = false; onDismiss() }) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Отмена") } }
        )
    }
}

@Composable
fun UnitButton(unit: String, onChange: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        TextButton(onClick = { open = true }, contentPadding = PaddingValues(horizontal = 6.dp)) {
            Text(if (unit.isBlank()) "—" else unit, maxLines = 1)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            UNITS.forEach { u ->
                DropdownMenuItem(text = { Text(u) }, onClick = { onChange(u); open = false })
            }
        }
    }
}
