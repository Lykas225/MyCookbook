@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

private val DarkScheme = darkColorScheme(
    primary = Color(0xFFE3B25E),
    onPrimary = Color(0xFF2B1A0C),
    primaryContainer = Color(0xFF5A3A1F),
    onPrimaryContainer = Color(0xFFFFE6BE),
    secondary = Color(0xFFD9A073),
    onSecondary = Color(0xFF2B1A0C),
    background = Color(0xFF2B1C13),
    onBackground = Color(0xFFF1E2C6),
    surface = Color(0xFF35241A),
    onSurface = Color(0xFFF1E2C6),
    surfaceVariant = Color(0xFF45301F),
    onSurfaceVariant = Color(0xFFD2BE9E),
    surfaceContainer = Color(0xFF35241A),
    surfaceContainerHigh = Color(0xFF3E2B1E),
    surfaceContainerHighest = Color(0xFF45301F),
    outline = Color(0xFF8A7050),
    error = Color(0xFFFF8A80)
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF8B3A1E),
    onPrimary = Color(0xFFFFF4DC),
    primaryContainer = Color(0xFFEBCFA6),
    onPrimaryContainer = Color(0xFF3E1E0C),
    secondary = Color(0xFF7A5230),
    onSecondary = Color.White,
    background = Color(0xFFF5E9D0),
    onBackground = Color(0xFF3B2A1A),
    surface = Color(0xFFFBF3E0),
    onSurface = Color(0xFF3B2A1A),
    surfaceVariant = Color(0xFFEBDDBF),
    onSurfaceVariant = Color(0xFF6B5237),
    surfaceContainer = Color(0xFFFBF3E0),
    surfaceContainerHigh = Color(0xFFF1E3C8),
    surfaceContainerHighest = Color(0xFFEBDDBF),
    outline = Color(0xFFB39868),
    error = Color(0xFFB3261E)
)

private fun bookTypography(): Typography {
    val b = Typography()
    val f = androidx.compose.ui.text.font.FontFamily.Serif
    return Typography(
        displayLarge = b.displayLarge.copy(fontFamily = f),
        displayMedium = b.displayMedium.copy(fontFamily = f),
        displaySmall = b.displaySmall.copy(fontFamily = f),
        headlineLarge = b.headlineLarge.copy(fontFamily = f),
        headlineMedium = b.headlineMedium.copy(fontFamily = f),
        headlineSmall = b.headlineSmall.copy(fontFamily = f),
        titleLarge = b.titleLarge.copy(fontFamily = f),
        titleMedium = b.titleMedium.copy(fontFamily = f),
        titleSmall = b.titleSmall.copy(fontFamily = f),
        bodyLarge = b.bodyLarge.copy(fontFamily = f),
        bodyMedium = b.bodyMedium.copy(fontFamily = f),
        bodySmall = b.bodySmall.copy(fontFamily = f),
        labelLarge = b.labelLarge.copy(fontFamily = f),
        labelMedium = b.labelMedium.copy(fontFamily = f),
        labelSmall = b.labelSmall.copy(fontFamily = f)
    )
}

private val BookTypography = bookTypography()
private val BookShapes = Shapes(
    small = RoundedCornerShape(6.dp),
    medium = RoundedCornerShape(8.dp),
    large = RoundedCornerShape(12.dp)
)

@Composable
fun CookbookTheme(wallpaper: Int, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (wallpaper == 0) DarkScheme else LightScheme,
        typography = BookTypography,
        shapes = BookShapes,
        content = content
    )
}
