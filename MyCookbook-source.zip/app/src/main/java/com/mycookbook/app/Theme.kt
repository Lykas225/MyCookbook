@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

private val DarkScheme = darkColorScheme(
    primary = Color(0xFFFF6A2B),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF4A2312),
    onPrimaryContainer = Color(0xFFFFDBCB),
    secondary = Color(0xFFFFB38A),
    onSecondary = Color(0xFF3A1A0A),
    background = Color(0xFF141414),
    onBackground = Color(0xFFF2F2F2),
    surface = Color(0xFF1C1C1C),
    onSurface = Color(0xFFF2F2F2),
    surfaceVariant = Color(0xFF2A2A2A),
    onSurfaceVariant = Color(0xFFBDBDBD),
    surfaceContainer = Color(0xFF1C1C1C),
    surfaceContainerHigh = Color(0xFF242424),
    surfaceContainerHighest = Color(0xFF2A2A2A),
    outline = Color(0xFF6E6E6E),
    error = Color(0xFFE5484D)
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFFB85C3C),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFF6DDD0),
    onPrimaryContainer = Color(0xFF4A1F0E),
    secondary = Color(0xFF8A5A44),
    onSecondary = Color.White,
    background = Color(0xFFFBF6EE),
    onBackground = Color(0xFF2B1D14),
    surface = Color(0xFFFFFBF5),
    onSurface = Color(0xFF2B1D14),
    surfaceVariant = Color(0xFFF2E8DA),
    onSurfaceVariant = Color(0xFF6B5748),
    surfaceContainer = Color(0xFFFFFBF5),
    surfaceContainerHigh = Color(0xFFF6EDE0),
    surfaceContainerHighest = Color(0xFFF2E8DA),
    outline = Color(0xFFB9A593),
    error = Color(0xFFBA1A1A)
)

@Composable
fun CookbookTheme(wallpaper: Int, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (wallpaper == 0) DarkScheme else LightScheme, content = content)
}
