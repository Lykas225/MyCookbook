@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mycookbook.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

val LocalVoiceHub = staticCompositionLocalOf<GlobalVoiceHub> {
    error("GlobalVoiceHub not provided")
}

class GlobalVoiceHub(
    private val context: Context,
    private val store: CookbookStore,
    private val timer: TimerState,
    private val nav: NavHostController,
    private val scope: CoroutineScope,
    private val onRequestMicPermission: (String) -> Unit
) {
    private val prefs = context.getSharedPreferences("cookbook_prefs", Context.MODE_PRIVATE)

    var handsFree by mutableStateOf(prefs.getBoolean("ratatouille_hands_free", false))
        private set
    var voiceMode by mutableStateOf(VoiceMode.OFF)
        private set
    var lastHeard by mutableStateOf("")
        private set
    var lastReply by mutableStateOf("")
        private set
    var aiBusy by mutableStateOf(false)
        private set
    var showHelp by mutableStateOf(false)
    var showVoiceSettings by mutableStateOf(false)
    var voiceProfile by mutableStateOf(RemyVoiceProfile.load(prefs))
        private set

    private var currentRoute: String = "home"
    private var activeRecipeId: String? = null
    private var screenHandler: ((VoiceCommand) -> Boolean)? = null

    private val assistant: VoiceAssistant = VoiceAssistant(
        context = context,
        onModeChange = { m -> voiceMode = m },
        onHandsFreeChange = { enabled ->
            handsFree = enabled
            prefs.edit().putBoolean("ratatouille_hands_free", enabled).apply()
        },
        onHeardText = { t -> lastHeard = t },
        onCommand = { cmd -> handleCommand(cmd) }
    )

    init {
        timer.onTimerFinished = { t ->
            val msg = timer.announceText(t)
            lastReply = msg
            assistant.speak(msg, keepDialog = handsFree)
        }
        if (handsFree) {
            val granted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (granted) {
                assistant.setHandsFree(true)
            } else {
                handsFree = false
                prefs.edit().putBoolean("ratatouille_hands_free", false).apply()
            }
        }
    }

    fun updateContext(route: String, recipeId: String?) {
        currentRoute = route
        activeRecipeId = recipeId
    }

    fun registerScreenHandler(handler: ((VoiceCommand) -> Boolean)?) {
        screenHandler = handler
    }

    fun setAiBusyState(busy: Boolean) {
        aiBusy = busy
    }

    fun clearReply() {
        lastReply = ""
    }

    fun openHelp() {
        showHelp = true
    }

    fun openVoiceSettings() {
        showVoiceSettings = true
    }

    fun availableRussianVoices(): List<Pair<String, String>> = assistant.getRussianVoices()

    fun updateVoiceProfile(newProfile: RemyVoiceProfile) {
        voiceProfile = newProfile
        RemyVoiceProfile.save(prefs, newProfile)
        assistant.updateVoiceProfile(newProfile)
    }

    fun testRemyVoice(previewProfile: RemyVoiceProfile = voiceProfile) {
        updateVoiceProfile(previewProfile)
        reply(RemyPersona.samplePhrase(previewProfile.frenchStyle))
    }

    fun speak(text: String, keepDialog: Boolean = false, showInBanner: Boolean = false) {
        if (showInBanner) lastReply = text
        assistant.speak(text, keepDialog = keepDialog)
    }

    fun reply(text: String, keepDialog: Boolean = false) {
        lastReply = text
        assistant.speak(text, keepDialog = keepDialog)
    }

    fun stopSpeaking() {
        assistant.stopSpeaking()
    }

    fun triggerVoice(action: String) {
        val granted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) {
            executeVoiceAction(action)
        } else {
            onRequestMicPermission(action)
        }
    }

    fun onPermissionGranted(action: String) {
        executeVoiceAction(action)
    }

    private fun executeVoiceAction(action: String) {
        if (action == "handsfree") {
            val next = !handsFree
            handsFree = next
            prefs.edit().putBoolean("ratatouille_hands_free", next).apply()
            assistant.setHandsFree(next)
            if (next) {
                reply(RemyPersona.handsFreeGreeting(voiceProfile.frenchStyle))
            } else {
                assistant.stopSpeaking()
            }
        } else {
            assistant.startSingleCommand()
        }
    }

    fun onAppPause() {
        assistant.pauseForLifecycle()
    }

    fun onAppResume() {
        assistant.resumeForLifecycle()
    }

    fun destroy() {
        timer.onTimerFinished = null
        screenHandler = null
        assistant.destroy()
    }

    private fun navigateTop(route: String) {
        nav.navigate(route) {
            popUpTo("home") { inclusive = false }
            launchSingleTop = true
        }
    }

    private fun findIngredientInRecipe(recipe: Recipe, query: String): String {
        val q = query.lowercase().replace('ё', 'е').trim()
        val stem = if (q.length >= 4) q.dropLast(1) else q
        val stem2 = if (q.length >= 5) q.dropLast(2) else stem
        val matches = recipe.ingredients.filter { ing ->
            val n = ing.name.lowercase().replace('ё', 'е')
            n.contains(q) || n.contains(stem) || (stem2.length >= 3 && n.contains(stem2)) ||
                q.split(" ").any { w -> w.length >= 3 && n.contains(w.dropLast(if (w.length >= 5) 1 else 0)) }
        }
        if (matches.isEmpty()) return "В рецепте «${recipe.title}» я не нашёл «$query»."
        return matches.joinToString(". ") { ing ->
            val line = ingredientLine(ing, 1.0)
            if (line.isBlank()) "${ing.name} — по вкусу" else "${ing.name}: $line"
        }
    }

    private fun handleCommand(cmd: VoiceCommand) {
        // Сначала даём шанс текущему экрану (например, CookScreen перехватывает навигацию по шагам и порции)
        if (screenHandler?.invoke(cmd) == true) return

        val curRecipe = activeRecipeId?.let { store.recipe(it) }

        scope.launch {
            when (cmd) {
                is VoiceCommand.StopSpeaking -> {
                    assistant.stopSpeaking()
                }
                is VoiceCommand.Sleep -> {
                    handsFree = false
                    prefs.edit().putBoolean("ratatouille_hands_free", false).apply()
                }
                is VoiceCommand.OpenVoiceSettings -> {
                    showVoiceSettings = true
                    reply(if (voiceProfile.frenchStyle) "Открываю настройки моего голоса, шеф!" else "Открываю настройки голоса.")
                }
                is VoiceCommand.ShowHelp -> {
                    showHelp = true
                    reply(if (voiceProfile.frenchStyle) "Бонжур, шеф! Я работаю на всех страницах книги! Скажите: готовь борщ, поставь таймер на 10 минут, настрой голос, или задайте любой кулинарный вопрос." else "Я работаю на всех страницах книги! Скажите: готовь борщ, покажи сладкую выпечку, поставь таймер на 10 минут, открой покупки, назад, или задайте любой вопрос.")
                }

                // --- Глобальная навигация по всем разделам и экранам ---
                is VoiceCommand.OpenHome -> {
                    reply("Открываю главную.")
                    nav.navigate("home") {
                        popUpTo("home") { inclusive = true }
                        launchSingleTop = true
                    }
                }
                is VoiceCommand.OpenRecipes -> {
                    reply("Открываю все рецепты.")
                    nav.navigate("recipes?cat=-1&sub=") {
                        popUpTo("home") { inclusive = false }
                    }
                }
                is VoiceCommand.OpenCategory -> {
                    val catName = CATEGORIES.getOrNull(cmd.categoryIndex)?.second ?: "Рецепты"
                    val subName = subCategoryInfo(cmd.categoryIndex, cmd.subCategory)?.title
                    val spoken = if (subName != null) "$catName — $subName" else catName
                    reply("Открываю раздел «$spoken».")
                    nav.navigate("recipes?cat=${cmd.categoryIndex}&sub=${cmd.subCategory}") {
                        popUpTo("home") { inclusive = false }
                    }
                }
                is VoiceCommand.OpenPlan -> {
                    reply("Открываю план питания.")
                    navigateTop("plan")
                }
                is VoiceCommand.AskTodayPlan -> {
                    val todayStr = java.time.LocalDate.now().toString()
                    val meals = (0..2).mapNotNull { sl ->
                        store.plan["$todayStr|$sl"]?.let { rid -> store.recipe(rid)?.title }
                            ?.let { t -> "${MEALS[sl].substringAfter(' ')}: $t" }
                    }
                    reply(
                        if (meals.isEmpty()) "На сегодня в плане блюд пока нет."
                        else "Сегодня в плане: ${meals.joinToString(". ")}."
                    )
                }
                is VoiceCommand.OpenShopping -> {
                    reply("Открываю список покупок.")
                    navigateTop("shopping")
                }
                is VoiceCommand.AddToShopping -> {
                    store.addShop(cmd.item, 0.0, "")
                    reply("Добавил ${cmd.item} в список покупок.")
                }
                is VoiceCommand.AddRecipeToShopping -> {
                    if (curRecipe != null) {
                        store.addShopRecipe(curRecipe, curRecipe.servings)
                        reply("Добавил все продукты для «${curRecipe.title}» в список покупок.")
                    } else {
                        reply("Откройте рецепт, чтобы добавить его продукты в покупки.")
                    }
                }
                is VoiceCommand.OpenTools -> {
                    reply("Открываю меню.")
                    navigateTop("tools")
                }
                is VoiceCommand.OpenTimers -> {
                    reply("Открываю таймеры.")
                    nav.navigate("timer") { launchSingleTop = true }
                }
                is VoiceCommand.OpenFridge -> {
                    reply("Открываю холодильник.")
                    nav.navigate("fridge") { launchSingleTop = true }
                }
                is VoiceCommand.OpenScanner -> {
                    reply("Открываю оцифровку рецепта.")
                    nav.navigate("scanner") { launchSingleTop = true }
                }
                is VoiceCommand.OpenCalc -> {
                    reply("Открываю калькулятор порций.")
                    nav.navigate("calc") { launchSingleTop = true }
                }
                is VoiceCommand.OpenWeb -> {
                    reply("Открываю поиск рецептов в интернете.")
                    nav.navigate("web") { launchSingleTop = true }
                }
                is VoiceCommand.OpenArchive -> {
                    reply(if (cmd.tab == 1) "Открываю видеоархив." else "Открываю фотоархив.")
                    nav.navigate("archive?tab=${cmd.tab}") { launchSingleTop = true }
                }
                is VoiceCommand.OpenBackup -> {
                    reply("Открываю резервную копию.")
                    nav.navigate("backup") { launchSingleTop = true }
                }
                is VoiceCommand.OpenNewRecipe -> {
                    reply("Открываю создание нового рецепта.")
                    nav.navigate("edit/new")
                }
                is VoiceCommand.OpenAi -> {
                    reply("Открываю чат с помощником.")
                    if (curRecipe != null) nav.navigate("ai/${curRecipe.id}") else nav.navigate("ai")
                }
                is VoiceCommand.ToggleTheme -> {
                    val next = if (store.wallpaper == 0) 1 else 0
                    store.chooseWallpaper(next)
                    reply(if (next == 0) "Включил тёмную тему." else "Включил светлую тему.")
                }

                // --- Поиск, запуск готовки и действия с открытым рецептом ---
                is VoiceCommand.CookRecipe -> {
                    val found = findBestRecipeByVoice(store.recipes, cmd.query)
                    if (found != null) {
                        reply("Открываю готовку: «${found.title}»!")
                        nav.navigate("cook/${found.id}")
                    } else {
                        store.searchQuery = cmd.query
                        nav.navigate("recipes?cat=-1&sub=") {
                            popUpTo("home") { inclusive = false }
                        }
                        reply("Рецепт «${cmd.query}» в книге не нашёл. Можете спросить его у меня или найти в интернете.")
                    }
                }
                is VoiceCommand.FindRecipe -> {
                    val qLow = cmd.query.lowercase().replace('ё', 'е')
                    val matches = store.recipes.filter {
                        it.title.lowercase().replace('ё', 'е').contains(qLow)
                    }
                    val best = matches.firstOrNull() ?: findBestRecipeByVoice(store.recipes, cmd.query)
                    if (matches.size > 1) {
                        store.searchQuery = cmd.query
                        val top = matches.take(3).joinToString(", ") { it.title }
                        nav.navigate("recipes?cat=-1&sub=") {
                            popUpTo("home") { inclusive = false }
                        }
                        reply("Нашёл ${matches.size} рецептов: $top. Показал их на экране.")
                    } else if (best != null) {
                        reply("Открываю рецепт «${best.title}».")
                        nav.navigate("recipe/${best.id}")
                    } else {
                        reply("По запросу «${cmd.query}» в книге ничего не нашёл.")
                    }
                }
                is VoiceCommand.StartCurrentCook -> {
                    if (curRecipe != null) {
                        if (curRecipe.steps.isNotEmpty()) {
                            reply("Запускаю пошаговую готовку: «${curRecipe.title}».")
                            nav.navigate("cook/${curRecipe.id}")
                        } else {
                            reply("В этом рецепте пока нет пошаговой инструкции.")
                        }
                    } else {
                        reply("Сначала откройте рецепт или скажите: «Рататуй, готовь борщ».")
                    }
                }
                is VoiceCommand.OpenVideo -> {
                    if (curRecipe != null) {
                        reply("Открываю видео приготовления.")
                        nav.navigate("video/${curRecipe.id}")
                    } else {
                        reply("Сначала откройте рецепт, чтобы посмотреть видео приготовления.")
                    }
                }
                is VoiceCommand.ToggleFavorite -> {
                    if (curRecipe != null) {
                        val willBeFav = !curRecipe.favorite
                        store.toggleFavorite(curRecipe.id)
                        reply(if (willBeFav) "Добавил «${curRecipe.title}» в любимые." else "Убрал «${curRecipe.title}» из любимых.")
                    } else {
                        reply("Откройте рецепт, чтобы добавить его в любимые.")
                    }
                }
                is VoiceCommand.ReadIngredients -> {
                    if (curRecipe != null) {
                        if (curRecipe.ingredients.isEmpty()) {
                            reply("Ингредиенты не указаны.")
                        } else {
                            val listText = curRecipe.ingredients.joinToString(", ") {
                                val qty = ingredientLine(it, 1.0)
                                if (qty.isBlank()) it.name else "${it.name} $qty"
                            }
                            reply("Для «${curRecipe.title}» на ${curRecipe.servings} порций понадобится: $listText.")
                        }
                    } else {
                        reply("Откройте нужный рецепт, и я зачитаю его ингредиенты.")
                    }
                }
                is VoiceCommand.AskIngredient -> {
                    if (curRecipe != null) {
                        reply(findIngredientInRecipe(curRecipe, cmd.query))
                    } else {
                        reply("Откройте рецепт, чтобы я подсказал количество продукта «${cmd.query}».")
                    }
                }
                is VoiceCommand.AskTemp -> {
                    if (curRecipe != null) {
                        reply(
                            if (curRecipe.tempC > 0) "Температура приготовления: ${curRecipe.tempC} градусов."
                            else "В этом рецепте температура духовки не указана."
                        )
                    } else {
                        reply("Откройте рецепт, чтобы узнать температуру приготовления.")
                    }
                }
                is VoiceCommand.AskTotalTime -> {
                    if (curRecipe != null) {
                        reply(
                            if (curRecipe.timeMin > 0) "Общее время приготовления: ${formatDurationRu(curRecipe.timeMin * 60)}."
                            else "Общее время в этом рецепте не указано."
                        )
                    } else {
                        reply("Откройте рецепт, чтобы узнать время приготовления.")
                    }
                }
                is VoiceCommand.ReadSecrets -> {
                    if (curRecipe != null) {
                        val text = listOf(curRecipe.secrets, curRecipe.notes).filter { it.isNotBlank() }.joinToString(". ")
                        reply(text.ifBlank { "Особых секретов или заметок к этому рецепту пока нет." })
                    } else {
                        reply("Откройте рецепт, и я зачитаю его секреты.")
                    }
                }

                // --- Глобальное «назад» вне режима готовки ---
                is VoiceCommand.PrevStep -> {
                    if (nav.popBackStack()) {
                        reply("Возвращаюсь назад.")
                    } else {
                        reply("Вы уже на главном экране.")
                    }
                }

                // --- Все 10 таймеров с любой страницы ---
                is VoiceCommand.TimerStart -> {
                    if (cmd.seconds > 0) {
                        val started = timer.start(cmd.seconds, cmd.label)
                        if (started == null) {
                            reply("Уже запущено максимум 10 таймеров. Сначала остановите один из них.")
                        } else {
                            reply("Запустил ${started.label} на ${formatDurationRu(cmd.seconds)}.")
                        }
                    } else {
                        val paused = timer.findTimer(preferPaused = true)
                        if (paused != null && !paused.running && !paused.finished) {
                            timer.resume(paused.id)
                            reply("Продолжил ${paused.label}.")
                        } else {
                            reply("Уточните время, например: поставь таймер на 10 минут.")
                        }
                    }
                }
                is VoiceCommand.TimerAdd -> {
                    val target = timer.findTimer(number = cmd.number, query = cmd.query)
                    if (target == null) {
                        reply("Нет активных таймеров.")
                    } else {
                        val upd = timer.addTime(target.id, cmd.deltaSeconds)
                        if (upd != null) {
                            reply("Добавил ${formatDurationRu(cmd.deltaSeconds)} к ${upd.label}. Осталось ${formatDurationRu(upd.remainingSec)}.")
                        }
                    }
                }
                is VoiceCommand.TimerPause -> {
                    if (cmd.all) {
                        val n = timer.pauseAll()
                        reply(if (n > 0) "Поставил на паузу таймеров: $n." else "Нет идущих таймеров.")
                    } else {
                        val target = timer.findTimer(number = cmd.number, query = cmd.query)
                        if (target == null) reply("Активных таймеров нет.")
                        else {
                            timer.pause(target.id)
                            reply("${target.label} на паузе.")
                        }
                    }
                }
                is VoiceCommand.TimerResume -> {
                    if (cmd.all) {
                        val n = timer.resumeAll()
                        reply(if (n > 0) "Продолжил таймеров: $n." else "Нет таймеров на паузе.")
                    } else {
                        val target = timer.findTimer(number = cmd.number, query = cmd.query, preferPaused = true)
                        if (target == null) reply("Нет таймеров на паузе.")
                        else {
                            timer.resume(target.id)
                            reply("Продолжил ${target.label}.")
                        }
                    }
                }
                is VoiceCommand.TimerStop -> {
                    if (cmd.all) {
                        val n = timer.dismissAll()
                        reply(if (n > 0) "Остановил все таймеры." else "Активных таймеров нет.")
                    } else {
                        val target = timer.findTimer(number = cmd.number, query = cmd.query, preferFinished = true)
                        if (target == null) reply("Активных таймеров нет.")
                        else {
                            timer.dismiss(target.id)
                            reply("Остановил ${target.label}.")
                        }
                    }
                }
                is VoiceCommand.TimerStatus -> {
                    if (timer.timers.isEmpty()) {
                        reply("Сейчас нет запущенных таймеров.")
                    } else if (cmd.number != null || !cmd.query.isNullOrBlank()) {
                        val target = timer.findTimer(number = cmd.number, query = cmd.query)
                        if (target == null) reply("Такой таймер не найден.")
                        else if (target.finished) reply("${target.label} уже закончился!")
                        else {
                            val st = if (target.running) "осталось" else "на паузе, осталось"
                            reply("${target.label}: $st ${formatDurationRu(target.remainingSec)}.")
                        }
                    } else {
                        val summary = timer.timers.joinToString(". ") { t ->
                            when {
                                t.finished -> "${t.label} уже готов"
                                t.running -> "${t.label} — осталось ${formatDurationRu(t.remainingSec)}"
                                else -> "${t.label} на паузе, ${formatDurationRu(t.remainingSec)}"
                            }
                        }
                        reply("Активных таймеров ${timer.timers.size}. $summary.")
                    }
                }

                // --- Любой кулинарный вопрос ИИ вслух на любой странице ---
                is VoiceCommand.AskAi -> {
                    if (aiBusy) return@launch
                    aiBusy = true
                    val french = voiceProfile.frenchStyle
                    lastReply = if (french) "Реми колдует над ответом…" else "Думаю над ответом…"
                    assistant.speak(RemyPersona.thinkingPhrase(french))
                    try {
                        val recipeCtx = if (curRecipe != null) {
                            "Пользователь сейчас открыл рецепт «${curRecipe.title}» (порций: ${curRecipe.servings}). "
                        } else ""
                        val sys = RemyPersona.voiceAiSystem(recipeCtx, french)
                        val ans = withContext(Dispatchers.IO) {
                            AiClient.chatCfgSmart(prefs, sys, listOf("user" to cmd.question), maxTokens = 350)
                        }
                        val clean = ans.replace(Regex("[*_#`]+"), "").trim()
                        reply(clean.ifBlank { "Не расслышал, повторите пожалуйста." })
                    } catch (e: Exception) {
                        reply("Не удалось связаться с ИИ, проверьте интернет.")
                    }
                    aiBusy = false
                }

                else -> {
                    reply("Откройте пошаговую готовку для команд по шагам, или скажите, например: «Рататуй, готовь борщ» или «таймер 10 минут».")
                }
            }
        }
    }
}

/** Компактная глобальная панель Рататуя — отображается на всех страницах, где нет собственной встроенной карточки. */
@Composable
fun GlobalVoiceBar(hub: GlobalVoiceHub, modifier: Modifier = Modifier) {
    val bg = when {
        hub.aiBusy -> MaterialTheme.colorScheme.secondaryContainer
        hub.voiceMode == VoiceMode.LISTENING_COMMAND -> MaterialTheme.colorScheme.errorContainer
        hub.voiceMode == VoiceMode.WAITING_WAKE -> MaterialTheme.colorScheme.primaryContainer
        hub.voiceMode == VoiceMode.SPEAKING -> MaterialTheme.colorScheme.secondaryContainer
        else -> MaterialTheme.colorScheme.surfaceContainerHigh
    }
    val fg = when {
        hub.aiBusy -> MaterialTheme.colorScheme.onSecondaryContainer
        hub.voiceMode == VoiceMode.LISTENING_COMMAND -> MaterialTheme.colorScheme.onErrorContainer
        hub.voiceMode == VoiceMode.WAITING_WAKE -> MaterialTheme.colorScheme.onPrimaryContainer
        hub.voiceMode == VoiceMode.SPEAKING -> MaterialTheme.colorScheme.onSecondaryContainer
        else -> MaterialTheme.colorScheme.onSurface
    }
    val label = when {
        hub.aiBusy -> "🐭 Рататуй думает…"
        hub.voiceMode == VoiceMode.LISTENING_COMMAND ->
            if (hub.lastHeard.isNotBlank()) "🎤 «${hub.lastHeard}»" else "🎤 Слушаю команду…"
        hub.voiceMode == VoiceMode.WAITING_WAKE -> "👂 Жду «Рататуй» / «Реми»"
        hub.voiceMode == VoiceMode.SPEAKING -> "🔊 Рататуй говорит… (нажмите — тихо)"
        else -> "🐭 Позвать Рататуя / Реми"
    }

    Column(modifier.fillMaxWidth()) {
        if (hub.lastReply.isNotBlank()) {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "🐭 ${hub.lastReply}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { hub.clearReply() }, modifier = Modifier.size(26.dp)) {
                        Icon(Icons.Filled.Close, "Скрыть", modifier = Modifier.size(15.dp))
                    }
                }
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
        Row(
            Modifier
                .fillMaxWidth()
                .background(bg)
                .clickable {
                    if (hub.voiceMode == VoiceMode.SPEAKING) hub.stopSpeaking()
                    else hub.triggerVoice("single")
                }
                .padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (hub.handsFree) Icons.Filled.RecordVoiceOver else Icons.Filled.Mic,
                "Рататуй",
                tint = if (hub.voiceMode == VoiceMode.LISTENING_COMMAND) MaterialTheme.colorScheme.error
                else if (hub.handsFree) MaterialTheme.colorScheme.primary
                else fg,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = fg,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { hub.openVoiceSettings() }, modifier = Modifier.size(30.dp)) {
                Icon(Icons.Filled.Tune, "Настройка голоса Реми", tint = fg, modifier = Modifier.size(18.dp))
            }
            IconButton(onClick = { hub.openHelp() }, modifier = Modifier.size(30.dp)) {
                Icon(Icons.Filled.HelpOutline, "Команды Рататуя", tint = fg, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(2.dp))
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (hub.handsFree) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface.copy(alpha = 0.7f),
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { hub.triggerVoice("handsfree") }
            ) {
                Text(
                    if (hub.handsFree) "Без рук ✓" else "Без рук",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (hub.handsFree) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }
    }
}


/** Бесплатная настройка голоса Реми прямо внутри APK (без API-ключей и подписок). */
@Composable
fun RemyVoiceSettingsDialog(hub: GlobalVoiceHub, onDismiss: () -> Unit) {
    var pitch by remember { mutableFloatStateOf(hub.voiceProfile.pitch) }
    var rate by remember { mutableFloatStateOf(hub.voiceProfile.rate) }
    var voiceName by remember { mutableStateOf(hub.voiceProfile.voiceName) }
    var frenchStyle by remember { mutableStateOf(hub.voiceProfile.frenchStyle) }
    val voices = remember { hub.availableRussianVoices() }

    fun currentProfile() = RemyVoiceProfile(
        pitch = pitch,
        rate = rate,
        voiceName = voiceName,
        frenchStyle = frenchStyle
    )

    val presets = listOf(
        Triple("🐭 Реми", 1.28f, 1.12f),
        Triple("👨‍🍳 Шеф", 1.05f, 1.04f),
        Triple("⚡ Шустрый", 1.38f, 1.24f),
        Triple("🎙 Обычный", 1.00f, 1.00f)
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🐭 Голос шеф-повара Реми") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "Бесплатный встроенный голос прямо на телефоне — без API-ключей и подписок. ИИ пишет реплики в стиле харизматичного французского шеф-повара, а телефон озвучивает их выбранным тембром.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text("Характер голоса (пресеты)", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    presets.forEach { (label, pVal, rVal) ->
                        val isMatch = kotlin.math.abs(pitch - pVal) < 0.03f && kotlin.math.abs(rate - rVal) < 0.03f
                        FilterChip(
                            selected = isMatch,
                            onClick = {
                                pitch = pVal
                                rate = rVal
                            },
                            label = { Text(label, fontSize = 12.sp) }
                        )
                    }
                }

                Column {
                    Text(
                        "Высота голоса (тон): ${(pitch * 100).toInt()}%" +
                            if (pitch >= 1.20f) " — мультяшный" else if (pitch <= 0.92f) " — басовитый" else "",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Slider(
                        value = pitch,
                        onValueChange = { pitch = it },
                        valueRange = 0.80f..1.60f
                    )
                }

                Column {
                    Text(
                        "Скорость речи: ${(rate * 100).toInt()}%",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Slider(
                        value = rate,
                        onValueChange = { rate = it },
                        valueRange = 0.80f..1.45f
                    )
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { frenchStyle = !frenchStyle }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("🇫🇷 Французский шарм Реми", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            Text(
                                "«Бонжур, шеф!», «Вуаля!», «Манифик!» в репликах и ответах ИИ",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(checked = frenchStyle, onCheckedChange = { frenchStyle = it })
                    }
                }

                if (voices.isNotEmpty()) {
                    Text("Голос синтезатора телефона", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = voiceName.isEmpty(),
                            onClick = { voiceName = "" },
                            label = { Text("Авто (лучший)", fontSize = 12.sp) }
                        )
                        voices.take(8).forEach { (id, label) ->
                            FilterChip(
                                selected = voiceName == id,
                                onClick = { voiceName = id },
                                label = { Text(label, fontSize = 12.sp) }
                            )
                        }
                    }
                }

                FilledTonalButton(
                    onClick = { hub.testRemyVoice(currentProfile()) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Filled.VolumeUp, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Проверить голос Реми")
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                hub.updateVoiceProfile(currentProfile())
                onDismiss()
            }) {
                Text("Сохранить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Закрыть") }
        }
    )
}
