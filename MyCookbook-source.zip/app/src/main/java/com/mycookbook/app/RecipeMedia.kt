@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mycookbook.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavHostController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

object RecipeMediaHelper {
    private val memCache = ConcurrentHashMap<String, String>()
    private val sem = Semaphore(4)

    fun aiPhotoUrl(recipe: Recipe, variant: Int = 0): String {
        val seed = (recipe.id.hashCode() and 0x7fffffff) + variant * 97
        val prompt = URLEncoder.encode(
            "appetizing food photography of ${recipe.title}, dish on plate, warm kitchen lighting, realistic",
            "UTF-8"
        )
        return "https://image.pollinations.ai/prompt/$prompt?width=640&height=480&nologo=true&seed=$seed"
    }

    private fun fetchWikipediaThumb(query: String): String? {
        return try {
            val q = URLEncoder.encode(query, "UTF-8")
            val apiUrl = "https://ru.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=$q&gsrlimit=4&prop=pageimages&piprop=thumbnail&pithumbsize=640&format=json"
            val c = URL(apiUrl).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 10000
            c.setRequestProperty("User-Agent", "MyCookbookAndroid/1.0")
            if (c.responseCode != 200) return null
            val body = c.inputStream.use { String(it.readBytes(), Charsets.UTF_8) }
            c.disconnect()
            val pages = JSONObject(body).optJSONObject("query")?.optJSONObject("pages") ?: return null
            var best: Pair<Int, String>? = null
            val keys = pages.keys()
            while (keys.hasNext()) {
                val p = pages.getJSONObject(keys.next())
                val idx = p.optInt("index", 99)
                val thumb = p.optJSONObject("thumbnail")?.optString("source") ?: ""
                if (thumb.isNotBlank() && !thumb.lowercase().endsWith(".svg") && !thumb.lowercase().contains(".svg.")) {
                    if (best == null || idx < best.first) {
                        best = idx to thumb
                    }
                }
            }
            best?.second
        } catch (e: Exception) {
            null
        }
    }

    suspend fun getAutoPhotoUrl(ctx: Context, recipe: Recipe): String {
        memCache[recipe.id]?.let { return it }
        val prefs = ctx.getSharedPreferences("auto_covers_v1", Context.MODE_PRIVATE)
        val saved = prefs.getString(recipe.id, null)
        if (!saved.isNullOrBlank()) {
            memCache[recipe.id] = saved
            return saved
        }
        return withContext(Dispatchers.IO) {
            sem.withPermit {
                memCache[recipe.id]?.let { return@withPermit it }
                val cleanTitle = recipe.title
                    .replace(Regex("\([^)]*\)"), "")
                    .replace("«", "")
                    .replace("»", "")
                    .trim()
                val wiki = fetchWikipediaThumb(cleanTitle)
                    ?: fetchWikipediaThumb("$cleanTitle блюдо")
                val chosen = wiki ?: aiPhotoUrl(recipe)
                memCache[recipe.id] = chosen
                prefs.edit().putString(recipe.id, chosen).apply()
                chosen
            }
        }
    }

    fun switchPhotoVariant(ctx: Context, recipe: Recipe): String {
        val prefs = ctx.getSharedPreferences("auto_covers_v1", Context.MODE_PRIVATE)
        val cur = memCache[recipe.id] ?: prefs.getString(recipe.id, "") ?: ""
        val nextVariant = if (cur.contains("pollinations.ai")) {
            val m = Regex("seed=(\d+)").find(cur)?.groupValues?.get(1)?.toIntOrNull() ?: 1
            (m % 100) + 1
        } else 1
        val nextUrl = aiPhotoUrl(recipe, nextVariant)
        memCache[recipe.id] = nextUrl
        prefs.edit().putString(recipe.id, nextUrl).apply()
        return nextUrl
    }

    fun videoSearchUrl(title: String, platform: Int): String {
        val q = URLEncoder.encode("рецепт $title", "UTF-8")
        return when (platform) {
            0 -> "https://vkvideo.ru/?q=$q"
            1 -> "https://rutube.ru/search/?query=$q"
            else -> "https://m.youtube.com/results?search_query=$q"
        }
    }
}

@Composable
fun RecipeVideoScreen(store: CookbookStore, id: String, nav: NavHostController) {
    val recipe = store.recipe(id)
    val ctx = LocalContext.current
    if (recipe == null) {
        Box(Modifier.fillMaxSize()) { Text("Рецепт не найден") }
        return
    }

    val hasPinned = recipe.videoUrl.isNotBlank()
    var tab by remember { mutableIntStateOf(0) }
    var currentUrl by remember {
        mutableStateOf(if (hasPinned) recipe.videoUrl else RecipeMediaHelper.videoSearchUrl(recipe.title, 0))
    }
    var canBack by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(true) }
    val webHolder = remember { arrayOfNulls<WebView>(1) }

    BackHandler(enabled = canBack) { webHolder[0]?.goBack() }
    DisposableEffect(Unit) { onDispose { webHolder[0]?.destroy() } }

    fun loadPlatform(idx: Int) {
        tab = idx
        val u = RecipeMediaHelper.videoSearchUrl(recipe.title, idx)
        currentUrl = u
        webHolder[0]?.loadUrl(u)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Видео: ${recipe.title}", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад")
                    }
                },
                actions = {
                    IconButton(onClick = { webHolder[0]?.reload() }) {
                        Icon(Icons.Filled.Refresh, "Обновить")
                    }
                    IconButton(onClick = {
                        try {
                            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(currentUrl)))
                        } catch (e: Exception) {
                            Toast.makeText(ctx, "Не удалось открыть в браузере", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Icon(Icons.Filled.OpenInBrowser, "Открыть в браузере")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            TabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.background) {
                Tab(selected = tab == 0, onClick = { loadPlatform(0) }, text = { Text("VK Видео") })
                Tab(selected = tab == 1, onClick = { loadPlatform(1) }, text = { Text("Rutube") })
                Tab(selected = tab == 2, onClick = { loadPlatform(2) }, text = { Text("YouTube") })
            }
            AndroidView(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                factory = { c ->
                    WebView(c).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        webChromeClient = WebChromeClient()
                        webViewClient = object : WebViewClient() {
                            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                                loading = true
                                if (url != null) currentUrl = url
                                canBack = view?.canGoBack() ?: false
                            }
                            override fun onPageFinished(view: WebView?, url: String?) {
                                loading = false
                                if (url != null) currentUrl = url
                                canBack = view?.canGoBack() ?: false
                            }
                            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                                if (url != null) currentUrl = url
                                canBack = view?.canGoBack() ?: false
                            }
                        }
                        webHolder[0] = this
                        loadUrl(currentUrl)
                    }
                }
            )
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        store.setVideoUrl(recipe.id, currentUrl)
                        Toast.makeText(ctx, "Видео закреплено за этим рецептом", Toast.LENGTH_SHORT).show()
                    },
                    enabled = currentUrl.startsWith("http"),
                    modifier = Modifier.weight(1f).height(46.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Filled.PushPin, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Закрепить это видео", maxLines = 1)
                }
            }
        }
    }
}
