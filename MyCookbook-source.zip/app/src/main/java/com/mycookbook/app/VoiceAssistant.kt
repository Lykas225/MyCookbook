package com.mycookbook.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class VoiceAssistant(
    private val context: Context,
    private val onStateChange: (Boolean) -> Unit = {},
    private val onCommand: (String) -> Unit
) {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var ready = false

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("ru", "RU")
                ready = true
            }
        }
        setupRecognizer()
    }

    private fun setupRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    onStateChange(true)
                }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    onStateChange(false)
                }
                override fun onError(error: Int) {
                    onStateChange(false)
                }
                override fun onResults(results: Bundle?) {
                    onStateChange(false)
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.joinToString(" ")?.lowercase() ?: return
                    when {
                        text.contains("дальше") || text.contains("следующ") || text.contains("вперед") || text.contains("вперёд") -> onCommand("NEXT")
                        text.contains("назад") || text.contains("предыдущ") -> onCommand("PREV")
                        text.contains("повтори") || text.contains("ещё раз") || text.contains("еще раз") || text.contains("прочитай") -> onCommand("REPEAT")
                        text.contains("таймер") || text.contains("старт") || text.contains("запусти") -> onCommand("TIMER_START")
                        text.contains("пауза") || text.contains("стоп") || text.contains("выключи") || text.contains("хватит") -> onCommand("TIMER_STOP")
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    fun speak(text: String) {
        if (!ready || text.isBlank()) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "cook_step")
    }

    fun stopSpeaking() {
        tts?.stop()
    }

    fun startListening() {
        if (speechRecognizer == null) setupRecognizer()
        val sr = speechRecognizer ?: return
        tts?.stop()
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        onStateChange(true)
        sr.startListening(intent)
    }

    fun destroy() {
        tts?.stop()
        tts?.shutdown()
        speechRecognizer?.destroy()
    }
}
