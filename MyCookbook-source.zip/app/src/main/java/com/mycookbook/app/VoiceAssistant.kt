package com.mycookbook.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

enum class VoiceMode {
    OFF,
    WAITING_WAKE,
    LISTENING_COMMAND,
    SPEAKING
}

sealed class VoiceCommand {
    object NextStep : VoiceCommand()
    object PrevStep : VoiceCommand()
    data class GoToStep(val stepNumber: Int) : VoiceCommand()
    object GoToStart : VoiceCommand()
    object RepeatStep : VoiceCommand()
    object StopSpeaking : VoiceCommand()
    object ReadIngredients : VoiceCommand()
    data class AskIngredient(val query: String) : VoiceCommand()
    data class SetServings(val servings: Int) : VoiceCommand()
    data class ChangeServings(val delta: Int) : VoiceCommand()
    object AskTemp : VoiceCommand()
    object AskTotalTime : VoiceCommand()
    object ReadSecrets : VoiceCommand()
    data class TimerStart(val seconds: Int, val label: String) : VoiceCommand()
    data class TimerAdd(val deltaSeconds: Int, val number: Int?, val query: String?) : VoiceCommand()
    data class TimerPause(val number: Int?, val query: String?, val all: Boolean) : VoiceCommand()
    data class TimerResume(val number: Int?, val query: String?, val all: Boolean) : VoiceCommand()
    data class TimerStop(val number: Int?, val query: String?, val all: Boolean) : VoiceCommand()
    data class TimerStatus(val number: Int?, val query: String?) : VoiceCommand()
    data class AddToShopping(val item: String) : VoiceCommand()
    object OpenTimers : VoiceCommand()
    object OpenVideo : VoiceCommand()
    object OpenShopping : VoiceCommand()
    object OpenPlan : VoiceCommand()
    object AskTodayPlan : VoiceCommand()
    object OpenFridge : VoiceCommand()
    object OpenScanner : VoiceCommand()
    object OpenCalc : VoiceCommand()
    object OpenAi : VoiceCommand()
    object OpenWeb : VoiceCommand()
    data class OpenCategory(val categoryIndex: Int) : VoiceCommand()
    data class CookRecipe(val query: String) : VoiceCommand()
    data class FindRecipe(val query: String) : VoiceCommand()
    object ShowHelp : VoiceCommand()
    object Sleep : VoiceCommand()
    data class AskAi(val question: String) : VoiceCommand()
}

object RatatouilleParser {
    // Имена «Рататуй» и «Реми» + частые ошибки распознавания речи Android (с границами слов)
    private val wakeRegexes = listOf(
        Regex("(?<![а-яa-z])(?:ратату[йяюеи]?|ратоту[йяюеи]?|ротату[йяюеи]?|рототу[йяюеи]?|рататуем|ратуй|рата\\s+туй|ра\\s+та\\s+туй|рота\\s+туй)(?![а-яa-z])"),
        Regex("(?<![а-яa-z])(?:реми|рэми|рэмми|ремми|рими|рами|реме|рэме)(?![а-яa-z])"),
        Regex("(?<![а-яa-z])(?:мышонок|шеф\\s+повар|эй\\s+шеф|эй\\s+повар)(?![а-яa-z])")
    )

    private val greetingOnlyWords = setOf(
        "привет", "эй", "слушай", "тут", "здесь", "помоги", "помощник", "алло", "ау", "да"
    )

    /** Returns Pair(hasWakeWord, remainderAfterWakeWord) */
    fun extractWake(raw: String): Pair<Boolean, String> {
        val low = raw.lowercase().replace('ё', 'е').trim()
        for (rx in wakeRegexes) {
            val m = rx.find(low)
            if (m != null) {
                val after = low.substring(m.range.last + 1)
                    .trimStart(' ', ',', '.', '!', '?', ':', '-', '—')
                return true to after
            }
        }
        return false to low
    }

    fun isGreetingOnly(remainder: String): Boolean {
        val clean = remainder.trim(' ', ',', '.', '!', '?')
        if (clean.isEmpty()) return true
        val words = clean.split(Regex("\\s+")).filter { it.isNotBlank() }
        return words.all { it in greetingOnlyWords }
    }

    private val wordNumbers = mapOf(
        "ноль" to 0,
        "один" to 1, "одна" to 1, "одну" to 1, "первый" to 1, "первую" to 1, "первого" to 1,
        "два" to 2, "две" to 2, "второй" to 2, "вторую" to 2, "второго" to 2,
        "три" to 3, "третий" to 3, "третью" to 3, "третьего" to 3,
        "четыре" to 4, "четвёртый" to 4, "четвертый" to 4, "четвёртую" to 4, "четвертую" to 4,
        "пять" to 5, "пятый" to 5, "пятую" to 5,
        "шесть" to 6, "шестой" to 6, "шестую" to 6,
        "семь" to 7, "седьмой" to 7, "седьмую" to 7,
        "восемь" to 8, "восьмой" to 8, "восьмую" to 8,
        "девять" to 9, "девятый" to 9, "девятую" to 9,
        "десять" to 10, "десятый" to 10, "десятую" to 10,
        "одиннадцать" to 11, "двенадцать" to 12, "тринадцать" to 13,
        "четырнадцать" to 14, "пятнадцать" to 15, "шестнадцать" to 16,
        "семнадцать" to 17, "восемнадцать" to 18, "девятнадцать" to 19,
        "двадцать" to 20, "двадцать пять" to 25, "тридцать" to 30,
        "сорок" to 40, "сорок пять" to 45, "пятьдесят" to 50, "шестьдесят" to 60,
        "девяносто" to 90
    )

    private fun normalizeNumbers(text: String): String {
        var s = text.lowercase().replace('ё', 'е')
        // Replace multi-word numbers first, then single words
        val sorted = wordNumbers.entries.sortedByDescending { it.key.length }
        for ((word, num) in sorted) {
            s = s.replace(Regex("(?<![а-яa-z0-9])$word(?![а-яa-z0-9])"), num.toString())
        }
        // Combine compound numbers like "20 5" -> "25"
        s = Regex("\\b(20|30|40|50|60|70|80|90)\\s+([1-9])\\b").replace(s) { m ->
            val tens = m.groupValues[1].toInt()
            val ones = m.groupValues[2].toInt()
            (tens + ones).toString()
        }
        return s
    }

    fun parseDurationSeconds(text: String): Int {
        val s = normalizeNumbers(text)
        var total = 0
        if (s.contains("полтора часа") || s.contains("полторы часа")) total += 90 * 60
        if (s.contains("полчаса") || s.contains("пол часа")) total += 30 * 60
        if (s.contains("четверть часа")) total += 15 * 60
        if (s.contains("полминуты") || s.contains("пол минуты")) total += 30

        val hMatch = Regex("(\\d+)\\s*(?:час\\w*|ч\\b)").find(s)
        if (hMatch != null) total += (hMatch.groupValues[1].toIntOrNull() ?: 0) * 3600
        else if (Regex("(?<![\\dа-я])на\\s+час(?![а-я])").containsMatchIn(s)) total += 3600

        val mMatch = Regex("(\\d+)\\s*(?:минут\\w*|мин\\b)").find(s)
        if (mMatch != null) total += (mMatch.groupValues[1].toIntOrNull() ?: 0) * 60
        else if (Regex("(?<![\\dа-я])(?:на\\s+)?минуту(?![а-я])").containsMatchIn(s) && !s.contains("полминуты")) total += 60

        val sMatch = Regex("(\\d+)\\s*(?:секунд\\w*|сек\\b)").find(s)
        if (sMatch != null) total += (sMatch.groupValues[1].toIntOrNull() ?: 0)

        // If user just said "таймер 5" without unit, assume minutes
        if (total == 0) {
            val bare = Regex("(?:таймер|на|добавь|прибавь|плюс)\\s+(\\d+)\\b").find(s)
            if (bare != null) {
                val n = bare.groupValues[1].toIntOrNull() ?: 0
                if (n in 1..240) total = n * 60
            }
        }
        return total
    }

    private fun extractTimerNumber(s: String): Int? {
        val m = Regex("(?:таймер\\w*|номер\\w*|№)\\s*(\\d{1,2})\\b").find(s)
        val n = m?.groupValues?.get(1)?.toIntOrNull()
        return if (n != null && n in 1..10) n else null
    }

    private fun extractTimerLabel(rawNorm: String): String {
        var cleaned = rawNorm
        val removePatterns = listOf(
            "поставь", "запусти", "включи", "заведи", "установи", "добавь", "прибавь", "создай",
            "останови", "выключи", "удали", "сбрось", "отмени", "убери", "пауза", "приостанови",
            "продолжи", "возобнови", "проверь", "сколько", "осталось", "таймер\\w*", "номер\\w*",
            "полтора часа", "полчаса", "пол часа", "четверть часа", "полминуты", "пол минуты",
            "\\d+\\s*(?:час\\w*|ч\\b|минут\\w*|мин\\b|секунд\\w*|сек\\b)",
            "\\b(?:на|для|к|в|с|по|час|минуту|секунду|все|всех|сигнал|звонок|пожалуйста|мне|еще|ещё)\\b",
            "\\b\\d+\\b"
        )
        for (p in removePatterns) {
            cleaned = cleaned.replace(Regex(p, RegexOption.IGNORE_CASE), " ")
        }
        cleaned = cleaned.replace(Regex("\\s+"), " ").trim()
        return if (cleaned.length >= 2) cleaned.replaceFirstChar { it.uppercase() } else ""
    }

    private fun matchCategory(s: String): Int? {
        val isNav = s.contains("открой") || s.contains("покажи") || s.contains("раздел") ||
            s.contains("категор") || s.contains("рецепты") || s.split(Regex("\\s+")).size <= 3
        if (!isNav) return null
        return when {
            s.contains("несладк") && s.contains("выпеч") -> 5
            s.contains("сладк") && s.contains("выпеч") -> 13
            s.contains("завтрак") -> 0
            s.contains("суп") -> 1
            s.contains("основн") -> 2
            s.contains("салат") -> 3
            s.contains("закуск") -> 4
            s.contains("выпеч") -> 13
            s.contains("десерт") -> 6
            s.contains("напит") || s.contains("чаи") || s.contains("кофе") -> 7
            s.contains("консерв") || s.contains("заготовк") -> 8
            s.contains("мяс") -> 9
            s.contains("птиц") -> 10
            s.contains("рыб") || s.contains("морепродукт") -> 11
            s.contains("овощ") -> 12
            else -> null
        }
    }

    fun parse(rawCommand: String): VoiceCommand {
        val orig = rawCommand.trim()
        val s = normalizeNumbers(orig)

        // 0. Sleep / deactivate wake mode
        if (s.contains("отключи голос") || s.contains("выключи микрофон") || s.contains("иди спать") || s == "спи" || s.contains("выключись") || s.contains("отключись")) {
            return VoiceCommand.Sleep
        }

        // 1. Stop speaking / silence
        if (s == "тихо" || s == "замолчи" || s.contains("хватит говорить") || s.contains("стоп озвуч") || s.contains("не читай")) {
            return VoiceCommand.StopSpeaking
        }

        // 2. Open timers / video / help / screens / categories / recipes
        if ((s.contains("открой") || s.contains("покажи") || s.contains("перейди")) && s.contains("таймер")) {
            return VoiceCommand.OpenTimers
        }
        if (s.contains("видео")) {
            return VoiceCommand.OpenVideo
        }
        if (s.contains("что ты умеешь") || s.contains("список команд") || s.contains("какие команды") || s == "помощь" || s == "команды") {
            return VoiceCommand.ShowHelp
        }
        if (s.contains("холодильник")) {
            return VoiceCommand.OpenFridge
        }
        if (s.contains("сканер") || s.contains("оцифр")) {
            return VoiceCommand.OpenScanner
        }
        if (s.contains("калькулятор")) {
            return VoiceCommand.OpenCalc
        }
        if (s.contains("интернет") || s.contains("поиск в сети")) {
            return VoiceCommand.OpenWeb
        }
        if ((s.contains("открой") || s.contains("покажи")) && (s.contains("чат") || s.contains("ии помощник"))) {
            return VoiceCommand.OpenAi
        }
        if ((s.contains("открой") || s.contains("покажи") || s.contains("что купить")) && (s.contains("покупк") || s.contains("список покупок")) && !s.contains("добав") && !s.contains("запиш")) {
            return VoiceCommand.OpenShopping
        }
        if (s.contains("что в плане") || s.contains("что сегодня готов") || s.contains("меню на сегодня") || s.contains("план на сегодня")) {
            return VoiceCommand.AskTodayPlan
        }
        if ((s.contains("открой") || s.contains("покажи")) && (s.contains("план") || s.contains("меню на неделю"))) {
            return VoiceCommand.OpenPlan
        }

        // 2b. Open category by voice ("открой мясо", "покажи сладкую выпечку", "рыба", "птица", "овощи")
        val catHit = matchCategory(s)
        if (catHit != null) {
            return VoiceCommand.OpenCategory(catHit)
        }

        // 2c. Start cooking a specific recipe ("готовь борщ", "давай приготовим шарлотку", "как приготовить плов")
        val cookPrefix = Regex("^(?:давай\\s+)?(?:приготовим|готовим|готовь|начни готовить|как приготовить|варим|жарим|печем|испечем)\\s+(.+)$").find(s)
        if (cookPrefix != null) {
            val q = cookPrefix.groupValues[1]
                .replace(Regex("\\b(рецепт|блюдо|пожалуйста|мне|сейчас)\\b"), "")
                .trim()
            if (q.length >= 2 && !q.contains("на ужин") && !q.contains("на обед") && !q.contains("на завтрак") && !q.startsWith("из ")) {
                return VoiceCommand.CookRecipe(q)
            }
        }

        // 2d. Find / open recipe ("найди борщ", "открой рецепт оливье")
        val findPrefix = Regex("^(?:найди|поищи|открой|покажи)\\s+(?:рецепт\\s+)?(.+)$").find(s)
        if (findPrefix != null) {
            val q = findPrefix.groupValues[1]
                .replace(Regex("\\b(рецепт|рецепты|блюдо|пожалуйста|мне)\\b"), "")
                .trim()
            if (q.length >= 2) {
                return VoiceCommand.FindRecipe(q)
            }
        }

        // 3. Add to shopping list
        if (s.contains("список покупок") || s.contains("в покупки") || s.startsWith("купить ") || s.startsWith("надо купить ")) {
            val item = orig.lowercase()
                .replace(Regex("(добавь|запиши|положи|внеси|надо)?\\s*(в список покупок|в покупки|купить)"), "")
                .replace(Regex("\\b(пожалуйста|мне)\\b"), "")
                .trim()
            if (item.isNotBlank()) return VoiceCommand.AddToShopping(item)
        }

        // 4. Timer management (up to 10 timers)
        val hasTimerWord = s.contains("таймер") || s.contains("будильник") || s.contains("сигнал") || s.contains("звонок")
        val isAll = s.contains("все ") || s.endsWith(" все") || s.contains("всех")

        // 4a. Timer status ("сколько осталось", "какие таймеры")
        if ((s.contains("сколько осталось") || s.contains("сколько времени осталось") || s.contains("какие таймер") || s.contains("проверь таймер") || s.contains("статус таймер")) && !s.contains("готов")) {
            val num = extractTimerNumber(s)
            val lbl = extractTimerLabel(s)
            return VoiceCommand.TimerStatus(num, lbl.ifBlank { null })
        }

        // 4b. Add time to timer ("добавь 5 минут к таймеру")
        if ((s.contains("добав") || s.contains("прибав") || s.contains("продли") || s.contains("плюс")) &&
            (hasTimerWord || s.contains("минут") || s.contains("секунд") || s.contains("час")) &&
            !s.contains("порц")
        ) {
            val sec = parseDurationSeconds(s)
            if (sec > 0) {
                val num = extractTimerNumber(s)
                val lbl = extractTimerLabel(s)
                return VoiceCommand.TimerAdd(sec, num, lbl.ifBlank { null })
            }
        }

        // 4c. Stop / delete / turn off timer or alarm
        if (s.contains("стоп") || s.contains("останов") || s.contains("выключ") || s.contains("отключ") || s.contains("удал") || s.contains("сброс") || s.contains("отмен") || s.contains("убери таймер") || s.contains("хватит звен")) {
            if (hasTimerWord || s == "стоп" || s == "выключи" || s == "отключи" || s == "хватит") {
                val num = extractTimerNumber(s)
                val lbl = extractTimerLabel(s)
                return VoiceCommand.TimerStop(num, lbl.ifBlank { null }, isAll)
            }
        }

        // 4d. Pause timer
        if (s.contains("пауз") || s.contains("приостанов")) {
            val num = extractTimerNumber(s)
            val lbl = extractTimerLabel(s)
            return VoiceCommand.TimerPause(num, lbl.ifBlank { null }, isAll)
        }

        // 4e. Resume timer
        if (s.contains("продолж") || s.contains("возобнов")) {
            val num = extractTimerNumber(s)
            val lbl = extractTimerLabel(s)
            return VoiceCommand.TimerResume(num, lbl.ifBlank { null }, isAll)
        }

        // 4f. Start timer ("поставь таймер на 5 минут", "засеки 10 минут", "таймер суп 20 минут")
        val dur = parseDurationSeconds(s)
        if (hasTimerWord || s.contains("засеки") || (dur > 0 && (s.contains("поставь") || s.contains("запусти") || s.contains("включи") || s.contains("заведи")))) {
            val lbl = extractTimerLabel(s)
            return VoiceCommand.TimerStart(dur, lbl)
        }

        // 5. Recipe navigation
        val stepMatch = Regex("(?:шаг|пункт)\\s*(?:номер\\s*)?(\\d+)\\b").find(s)
            ?: Regex("(?:перейди|открой|давай)\\s+(?:на\\s+)?(\\d+)\\s*(?:шаг|пункт)").find(s)
        if (stepMatch != null) {
            val stepNum = stepMatch.groupValues[1].toIntOrNull()
            if (stepNum != null && stepNum > 0) return VoiceCommand.GoToStep(stepNum)
        }

        if (s.contains("в начало") || s.contains("сначала") || s.contains("подготовк") || s.contains("начало рецепта")) {
            return VoiceCommand.GoToStart
        }
        if (s.contains("дальше") || s.contains("следующ") || s.contains("вперед") || s.contains("далее") || s == "готово" || s == "сделал" || s == "сделала") {
            return VoiceCommand.NextStep
        }
        if (s.contains("назад") || s.contains("предыдущ") || s.contains("вернись") || s.contains("обратно")) {
            return VoiceCommand.PrevStep
        }
        if (s.contains("повтор") || s.contains("еще раз") || s.contains("прочитай") || s.contains("что делать") || s.contains("какой шаг") || s.contains("читай")) {
            return VoiceCommand.RepeatStep
        }

        // 6. Servings & portions
        if (s.contains("порц")) {
            val numMatch = Regex("(\\d+)").find(s)
            val n = numMatch?.groupValues?.get(1)?.toIntOrNull()
            return when {
                s.contains("увелич") || s.contains("добав") || s.contains("больше") -> VoiceCommand.ChangeServings(n ?: 1)
                s.contains("уменьш") || s.contains("убери") || s.contains("меньше") -> VoiceCommand.ChangeServings(-(n ?: 1))
                n != null && n in 1..99 -> VoiceCommand.SetServings(n)
                else -> VoiceCommand.ChangeServings(1)
            }
        }

        // 7. Temperature, time, secrets
        if (s.contains("температур") || s.contains("градус") || s.contains("духовк")) {
            return VoiceCommand.AskTemp
        }
        if (s.contains("сколько готов") || s.contains("общее время") || s.contains("долго готов") || s.contains("время приготов")) {
            return VoiceCommand.AskTotalTime
        }
        if (s.contains("секрет") || s.contains("хитрост") || s.contains("совет") || s.contains("заметк")) {
            return VoiceCommand.ReadSecrets
        }

        // 8. Ingredients ("ингредиенты" vs "сколько муки / сколько нужно сахара")
        if (s.contains("ингредиент") || s.contains("какие продукт") || s.contains("список продукт") || s.contains("что нужно для")) {
            return VoiceCommand.ReadIngredients
        }
        if (s.startsWith("сколько ") || s.contains("сколько нужно ") || s.contains("сколько надо ") || s.contains("сколько положить ") || s.contains("сколько добавить ")) {
            val prod = s.replace(Regex("^(?:а\\s+)?сколько\\s+(?:нужно|надо|положить|добавить|брать|взять|идет|идёт)?\\s*"), "")
                .replace("?", "")
                .trim()
            if (prod.isNotBlank() && !prod.contains("варить") && !prod.contains("жарить") && !prod.contains("выпекать") && !prod.contains("тушить") && !prod.contains("печь")) {
                return VoiceCommand.AskIngredient(prod)
            }
        }

        // 9. Any other culinary question → Ask AI aloud
        return VoiceCommand.AskAi(orig)
    }
}

class VoiceAssistant(
    private val context: Context,
    private val onModeChange: (VoiceMode) -> Unit = {},
    private val onHeardText: (String) -> Unit = {},
    private val onCommand: (VoiceCommand) -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var ttsReady = false
    private var pendingSpeech: Pair<String, Boolean>? = null
    private var destroyed = false

    private var handsFreeEnabled = false
    private var inDialogUntilMs = 0L
    private var isRecognizing = false
    private var consecutiveErrors = 0
    private var mode: VoiceMode = VoiceMode.OFF

    private val restartRunnable = Runnable {
        if (!destroyed && mode != VoiceMode.SPEAKING && mode != VoiceMode.OFF) {
            beginRecognitionInternal()
        }
    }

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("ru", "RU")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        mainHandler.post {
                            if (!destroyed) setMode(VoiceMode.SPEAKING)
                        }
                    }

                    override fun onDone(utteranceId: String?) {
                        mainHandler.post { onTtsFinished() }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        mainHandler.post { onTtsFinished() }
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        mainHandler.post { onTtsFinished() }
                    }
                })
                ttsReady = true
                mainHandler.post {
                    val queued = pendingSpeech
                    pendingSpeech = null
                    if (queued != null && !destroyed) {
                        speak(queued.first, queued.second)
                    }
                }
            }
        }
        setupRecognizer()
    }

    private fun setMode(newMode: VoiceMode) {
        if (mode != newMode) {
            mode = newMode
            onModeChange(newMode)
        }
    }

    private fun onTtsFinished() {
        if (destroyed) return
        val now = System.currentTimeMillis()
        when {
            now < inDialogUntilMs -> {
                setMode(VoiceMode.LISTENING_COMMAND)
                scheduleRestart(300L)
            }
            handsFreeEnabled -> {
                setMode(VoiceMode.WAITING_WAKE)
                scheduleRestart(450L)
            }
            else -> {
                setMode(VoiceMode.OFF)
            }
        }
    }

    private fun setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) return
        try {
            speechRecognizer?.destroy()
        } catch (e: Exception) {
        }
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isRecognizing = true
                consecutiveErrors = 0
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                isRecognizing = false
            }

            override fun onError(error: Int) {
                isRecognizing = false
                if (destroyed || mode == VoiceMode.OFF || mode == VoiceMode.SPEAKING) return
                when (error) {
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                        handsFreeEnabled = false
                        inDialogUntilMs = 0L
                        setMode(VoiceMode.OFF)
                    }
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                        try {
                            speechRecognizer?.cancel()
                        } catch (e: Exception) {
                        }
                        scheduleRestart(900L)
                    }
                    SpeechRecognizer.ERROR_CLIENT, SpeechRecognizer.ERROR_AUDIO -> {
                        consecutiveErrors++
                        if (consecutiveErrors >= 2) {
                            consecutiveErrors = 0
                            setupRecognizer()
                        }
                        if (handsFreeEnabled || System.currentTimeMillis() < inDialogUntilMs) {
                            scheduleRestart(1200L)
                        } else {
                            setMode(VoiceMode.OFF)
                        }
                    }
                    else -> {
                        // Normal timeout / no speech / network blip — keep wake-word listening alive
                        val now = System.currentTimeMillis()
                        if (mode == VoiceMode.LISTENING_COMMAND && now >= inDialogUntilMs) {
                            if (handsFreeEnabled) {
                                setMode(VoiceMode.WAITING_WAKE)
                                scheduleRestart(500L)
                            } else {
                                setMode(VoiceMode.OFF)
                            }
                        } else if (handsFreeEnabled || now < inDialogUntilMs) {
                            scheduleRestart(650L)
                        } else {
                            setMode(VoiceMode.OFF)
                        }
                    }
                }
            }

            override fun onResults(results: Bundle?) {
                isRecognizing = false
                consecutiveErrors = 0
                if (destroyed) return
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val best = matches?.firstOrNull()?.trim() ?: ""
                if (best.isEmpty()) {
                    resumeListeningIfNeeded()
                    return
                }
                handleRecognizedPhrase(best, matches ?: listOf(best))
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!partial.isNullOrBlank()) {
                    // В режиме ожидания имени не засоряем экран посторонними разговорами
                    val isCmd = mode == VoiceMode.LISTENING_COMMAND || System.currentTimeMillis() < inDialogUntilMs
                    if (isCmd || RatatouilleParser.extractWake(partial).first) {
                        onHeardText(partial)
                    }
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun handleRecognizedPhrase(primary: String, allCandidates: List<String>) {
        // Проверяем все варианты распознавания Android на наличие имени «Рататуй» / «Реми»
        var wakeFound = false
        var afterWake = ""
        for (cand in allCandidates) {
            val (found, rem) = RatatouilleParser.extractWake(cand)
            if (found) {
                wakeFound = true
                afterWake = rem
                break
            }
        }

        val now = System.currentTimeMillis()
        val inActiveDialog = mode == VoiceMode.LISTENING_COMMAND || now < inDialogUntilMs

        if (mode == VoiceMode.WAITING_WAKE && !inActiveDialog) {
            if (!wakeFound) {
                // В фоне полностью игнорируем посторонние разговоры на кухне
                resumeListeningIfNeeded()
                return
            }
            onHeardText(primary)
            if (RatatouilleParser.isGreetingOnly(afterWake)) {
                // Сценарий 1 (Диалог): позвали по имени → откликается и ждёт команду
                inDialogUntilMs = System.currentTimeMillis() + 14000L
                speak("Да, слушаю!", keepDialog = true)
                return
            }
            // Сценарий 2 (Слитная команда): «Рататуй, дальше» / «Реми, таймер 5 минут»
            // Выполняем сразу и возвращаемся в режим ожидания имени
            inDialogUntilMs = 0L
            dispatchCommand(afterWake)
        } else {
            // Активное прослушивание команды (после отклика «Да, слушаю!» или ручного нажатия)
            onHeardText(primary)
            val cleanText = if (wakeFound && !RatatouilleParser.isGreetingOnly(afterWake)) afterWake else primary
            if (wakeFound && RatatouilleParser.isGreetingOnly(afterWake)) {
                inDialogUntilMs = System.currentTimeMillis() + 14000L
                speak("Слушаю вас!", keepDialog = true)
                return
            }
            // После выполнения команды в диалоге возвращаемся в фоновый режим ожидания имени
            inDialogUntilMs = 0L
            dispatchCommand(cleanText)
        }
    }

    private fun dispatchCommand(text: String) {
        val cmd = RatatouilleParser.parse(text)
        if (cmd is VoiceCommand.Sleep) {
            setHandsFree(false)
            speak("Хорошо, отдыхаю. Если понадоблюсь — нажмите микрофон.", keepDialog = false)
            return
        }
        onCommand(cmd)
        // Если команда не запустила озвучку сразу, возвращаем нужный режим прослушивания
        mainHandler.postDelayed({
            if (!destroyed && mode != VoiceMode.SPEAKING) {
                resumeListeningIfNeeded()
            }
        }, 500L)
    }

    private fun resumeListeningIfNeeded() {
        val now = System.currentTimeMillis()
        when {
            now < inDialogUntilMs -> {
                setMode(VoiceMode.LISTENING_COMMAND)
                scheduleRestart(350L)
            }
            handsFreeEnabled -> {
                setMode(VoiceMode.WAITING_WAKE)
                scheduleRestart(450L)
            }
            else -> {
                setMode(VoiceMode.OFF)
            }
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        mainHandler.removeCallbacks(restartRunnable)
        mainHandler.postDelayed(restartRunnable, delayMs)
    }

    private fun stopRecognitionInternal() {
        mainHandler.removeCallbacks(restartRunnable)
        isRecognizing = false
        try {
            speechRecognizer?.cancel()
        } catch (e: Exception) {
        }
    }

    private fun beginRecognitionInternal() {
        if (destroyed || mode == VoiceMode.SPEAKING || mode == VoiceMode.OFF) return
        if (speechRecognizer == null) setupRecognizer()
        val sr = speechRecognizer ?: return
        if (isRecognizing) {
            try {
                sr.cancel()
            } catch (e: Exception) {
            }
            isRecognizing = false
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
        }
        try {
            sr.startListening(intent)
        } catch (e: Exception) {
            scheduleRestart(1000L)
        }
    }

    fun setHandsFree(enabled: Boolean) {
        mainHandler.post {
            if (destroyed) return@post
            handsFreeEnabled = enabled
            if (enabled) {
                if (mode != VoiceMode.SPEAKING) {
                    setMode(VoiceMode.WAITING_WAKE)
                    beginRecognitionInternal()
                }
            } else {
                inDialogUntilMs = 0L
                stopRecognitionInternal()
                if (mode != VoiceMode.SPEAKING) {
                    setMode(VoiceMode.OFF)
                }
            }
        }
    }

    fun startSingleCommand() {
        mainHandler.post {
            if (destroyed) return@post
            tts?.stop()
            inDialogUntilMs = System.currentTimeMillis() + 14000L
            setMode(VoiceMode.LISTENING_COMMAND)
            beginRecognitionInternal()
        }
    }

    fun speak(text: String, keepDialog: Boolean = false) {
        mainHandler.post {
            if (destroyed || text.isBlank()) return@post
            if (keepDialog) {
                inDialogUntilMs = System.currentTimeMillis() + 14000L
            }
            if (!ttsReady) {
                pendingSpeech = text to keepDialog
                return@post
            }
            stopRecognitionInternal()
            setMode(VoiceMode.SPEAKING)
            val params = Bundle()
            val res = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "ratatouille_${System.currentTimeMillis()}")
            if (res == null || res == TextToSpeech.ERROR) {
                onTtsFinished()
            }
        }
    }

    fun stopSpeaking() {
        mainHandler.post {
            pendingSpeech = null
            tts?.stop()
            onTtsFinished()
        }
    }

    fun destroy() {
        destroyed = true
        handsFreeEnabled = false
        inDialogUntilMs = 0L
        pendingSpeech = null
        mainHandler.removeCallbacksAndMessages(null)
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
        }
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (e: Exception) {
        }
        tts = null
        speechRecognizer = null
    }
}
