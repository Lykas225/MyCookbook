@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

data class UpdateInfo(val code: Long, val url: String, val size: Long, val notes: String)

object Updater {
    private const val REPO = "Lykas225/MyCookbook"

    fun installedCode(ctx: Context): Long = try {
        androidx.core.content.pm.PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(ctx.packageName, 0))
    } catch (e: Exception) {
        0L
    }

    fun installedName(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
    } catch (e: Exception) {
        ""
    }

    fun fetchLatest(): UpdateInfo {
        val c = java.net.URL("https://api.github.com/repos/$REPO/releases/latest").openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("User-Agent", "MyCookbook-App")
        val code = c.responseCode
        if (code != 200) throw Exception("GitHub ответил $code")
        val o = JSONObject(c.inputStream.use { String(it.readBytes(), Charsets.UTF_8) })
        val tag = o.optString("tag_name")
        val num = tag.filter { it.isDigit() }.toLongOrNull() ?: 0L
        val assets = o.optJSONArray("assets") ?: throw Exception("в релизе нет файлов")
        for (i in 0 until assets.length()) {
            val a = assets.getJSONObject(i)
            if (a.optString("name").endsWith(".apk")) {
                return UpdateInfo(num, a.getString("browser_download_url"), a.optLong("size", 0L), o.optString("body").trim())
            }
        }
        throw Exception("в релизе нет APK")
    }

    fun check(ctx: Context): UpdateInfo? {
        val i = fetchLatest()
        return if (i.code > installedCode(ctx)) i else null
    }

    fun download(ctx: Context, url: String, onProgress: (Float) -> Unit): File {
        val dir = File(ctx.cacheDir, "updates")
        dir.mkdirs()
        dir.listFiles()?.forEach { it.delete() }
        val f = File(dir, "MyCookbook.apk")
        val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 60000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "MyCookbook-App")
        if (c.responseCode != 200) throw Exception("скачивание: код ${c.responseCode}")
        val total = c.contentLengthLong
        c.inputStream.use { input ->
            f.outputStream().use { out ->
                val buf = ByteArray(32 * 1024)
                var done = 0L
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    if (total > 0) onProgress(done.toFloat() / total)
                }
            }
        }
        if (f.length() < 100000) throw Exception("файл повреждён")
        return f
    }

    /** false — нужно сначала разрешить установку из этого приложения. */
    fun install(ctx: Context, f: File): Boolean {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            val i = android.content.Intent(
                android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                android.net.Uri.parse("package:" + ctx.packageName)
            )
            i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            return false
        }
        val uri = androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
        val i = android.content.Intent(android.content.Intent.ACTION_VIEW)
        i.setDataAndType(uri, "application/vnd.android.package-archive")
        i.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return true
    }
}

@Composable
fun UpdateScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val installed = remember { Updater.installedCode(ctx) }
    val name = remember { Updater.installedName(ctx) }
    var info by remember { mutableStateOf<UpdateInfo?>(null) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(-1f) }
    var apk by remember { mutableStateOf<File?>(null) }

    fun check() {
        if (busy) return
        scope.launch {
            busy = true
            status = "Проверяю…"
            try {
                val i = withContext(Dispatchers.IO) { Updater.fetchLatest() }
                info = i
                status = if (i.code > installed) "Доступна новая версия: ${i.code}" else "Установлена последняя версия"
            } catch (e: Exception) {
                status = "Не удалось проверить: " + (e.message ?: "нет связи")
            }
            busy = false
        }
    }

    fun downloadAndInstall() {
        val i = info ?: return
        if (busy) return
        scope.launch {
            busy = true
            try {
                var f = apk
                if (f == null || !f.exists()) {
                    status = "Скачиваю…"
                    progress = 0f
                    f = withContext(Dispatchers.IO) { Updater.download(ctx, i.url) { p -> progress = p } }
                    apk = f
                }
                progress = -1f
                if (Updater.install(ctx, f)) {
                    status = "Подтвердите установку в окне Android"
                } else {
                    status = "Разрешите установку из этого приложения и нажмите кнопку ещё раз"
                }
            } catch (e: Exception) {
                progress = -1f
                status = "Ошибка: " + (e.message ?: "нет связи")
            }
            busy = false
        }
    }

    LaunchedEffect(Unit) { check() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Обновление приложения") },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Установлена версия: $installed" + (if (name.isNotBlank()) " ($name)" else ""), style = MaterialTheme.typography.titleMedium)
            Text(status, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            if (busy && progress < 0f) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (progress >= 0f) LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
            val i = info
            if (i != null && i.code > installed) {
                if (i.size > 0) Text("Размер: " + String.format(Locale.US, "%.1f", i.size / 1048576.0) + " МБ")
                if (i.notes.isNotBlank()) Text(i.notes)
                Button(
                    onClick = { downloadAndInstall() },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(16.dp)
                ) { Text("Скачать и установить") }
            }
            OutlinedButton(onClick = { check() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text("Проверить обновления")
            }
            Text(
                "Ваши рецепты и фото при обновлении сохраняются.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
