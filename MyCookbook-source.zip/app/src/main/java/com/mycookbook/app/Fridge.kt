@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mycookbook.app

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun FridgeScreen(store: CookbookStore, nav: NavHostController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("cookbook_prefs", Context.MODE_PRIVATE) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    val quickItems = remember {
        listOf("Курица", "Картофель", "Яйца", "Сыр", "Помидоры", "Лук", "Молоко", "Мука", "Рис", "Фарш", "Грибы", "Капуста")
    }

    val tokens = remember(input) {
        input.split(',', ';', '\n')
            .map { it.trim().lowercase() }
            .filter { it.length >= 2 }
            .distinct()
    }

    val matched = remember(tokens, store.recipes) {
        if (tokens.isEmpty()) emptyList()
        else store.recipes.mapNotNull { r ->
            val hits = tokens.count { tok ->
                r.ingredients.any { it.name.lowercase().contains(tok) } || r.title.lowercase().contains(tok)
            }
            if (hits > 0) r to hits else null
        }.sortedByDescending { it.second }.take(15)
    }

    fun addQuick(word: String) {
        val cur = input.trim()
        val low = cur.lowercase()
        if (low.contains(word.lowercase())) return
        input = if (cur.isEmpty()) word else "$cur, $word"
    }

    fun generateWithAi() {
        val text = input.trim()
        if (busy || text.isEmpty()) return
        scope.launch {
            busy = true
            try {
                val cfg = AiProviders.load(prefs)
                val prompt = "Придумай вкусное и реальное блюдо из этих продуктов: $text. " +
                    "Можно добавить базовые вещи (соль, перец, масло, вода). " +
                    "Опиши подробные граммовки и понятные шаги."
                val raw = withContext(Dispatchers.IO) {
                    AiClient.chatCfg(cfg, AiClient.recipeJsonSystem(), listOf("user" to prompt), 4096, true)
                }
                val parsed = AiClient.parseRecipeJson(raw)
                if (parsed == null) {
                    Toast.makeText(ctx, "ИИ не смог оформить рецепт, попробуйте ещё раз", Toast.LENGTH_LONG).show()
                } else {
                    val id = WebImport.addToBook(ctx, store, parsed.copy(sourceUrl = "Из холодильника (ИИ)"))
                    Toast.makeText(ctx, "Рецепт «${parsed.title}» добавлен в книгу", Toast.LENGTH_SHORT).show()
                    nav.navigate("recipe/$id")
                }
            } catch (e: Exception) {
                Toast.makeText(ctx, "Ошибка ИИ: ${e.message ?: "нет связи"}", Toast.LENGTH_LONG).show()
            }
            busy = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Что в холодильнике") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).fillMaxSize().imePadding(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(
                    "Напишите продукты через запятую — подберём рецепты из вашей книги или придумаем новое блюдо с ИИ.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            item {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    label = { Text("Например: курица, картошка, сыр") },
                    trailingIcon = {
                        if (input.isNotEmpty()) {
                            IconButton(onClick = { input = "" }) { Icon(Icons.Filled.Close, "Очистить") }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    shape = RoundedCornerShape(14.dp)
                )
            }
            item {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    quickItems.forEach { itemName ->
                        AssistChip(onClick = { addQuick(itemName) }, label = { Text("+ $itemName") })
                    }
                }
            }
            item {
                Button(
                    onClick = { generateWithAi() },
                    enabled = input.isNotBlank() && !busy,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Filled.AutoAwesome, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (busy) "ИИ придумывает рецепт…" else "Придумать рецепт с ИИ", fontSize = 16.sp)
                }
            }

            if (tokens.isNotEmpty()) {
                item {
                    Text(
                        if (matched.isEmpty()) "В вашей книге совпадений нет — нажмите кнопку выше, чтобы ИИ придумал рецепт"
                        else "Подходящие рецепты в вашей книге (${matched.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                items(matched, key = { it.first.id }) { (r, hits) ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { nav.navigate("recipe/${r.id}") },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            RecipeImage(store, r, Modifier.size(64.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(r.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(
                                    "Совпадений: $hits из ${tokens.size}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
