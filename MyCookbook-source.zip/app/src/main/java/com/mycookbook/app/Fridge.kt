@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mycookbook.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun FridgeScreen(store: CookbookStore, nav: NavHostController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("cookbook_prefs", Context.MODE_PRIVATE) }

    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var statusText by remember { mutableStateOf("") }
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    var pendingPhotoFile by remember { mutableStateOf<File?>(null) }
    var aiSuggestions by remember { mutableStateOf("") }

    val quickItems = remember {
        listOf("Курица", "Картофель", "Яйца", "Сыр", "Помидоры", "Лук", "Молоко", "Мука", "Рис", "Фарш", "Грибы", "Капуста")
    }

    val tokens = remember(input) {
        input.split(',', ';', '\n')
            .map { it.trim().lowercase() }
            .filter { it.length >= 2 }
            .distinct()
    }

    val matched = remember(tokens, store.recipes) {
        if (tokens.isEmpty()) emptyList()
        else store.recipes.mapNotNull { r ->
            val hits = tokens.count { tok ->
                r.ingredients.any { it.name.lowercase().contains(tok) } || r.title.lowercase().contains(tok)
            }
            if (hits > 0) r to hits else null
        }.sortedByDescending { it.second }.take(15)
    }

    fun analyzeFridgePhoto(uri: Uri) {
        if (busy) return
        photoUri = uri
        aiSuggestions = ""
        scope.launch {
            busy = true
            statusText = "Рассматриваю холодильник и подбираю блюда…"
            try {
                val cfg = AiProviders.load(prefs)
                val b64 = withContext(Dispatchers.IO) { AiClient.encodeBitmapToBase64(ctx, uri) }
                val system = "Ты — дружелюбный кулинарный помощник. Отвечай по-русски, конкретно и аппетитно."
                val prompt = "Посмотри на это фото холодильника (или продуктов). " +
                    "1) В самой первой строке напиши строго в формате: ПРОДУКТЫ: продукт1, продукт2, продукт3 (только названия через запятую). " +
                    "2) Ниже предложи 3–4 конкретных вкусных блюда, которые можно приготовить из этих продуктов. " +
                    "Для каждого блюда укажи название, краткую суть и что из базового (соль, масло и т.п.) понадобится."
                val reply = withContext(Dispatchers.IO) {
                    AiClient.chatWithImageCfg(cfg, system, prompt, b64)
                }
                val lines = reply.lines()
                val prodLine = lines.firstOrNull { it.trim().uppercase().startsWith("ПРОДУКТЫ:") }
                if (prodLine != null) {
                    val found = prodLine.substringAfter(":").trim().trimEnd('.')
                    if (found.isNotBlank()) input = found
                    aiSuggestions = lines.filterNot { it == prodLine }.joinToString("\n").trim()
                } else {
                    aiSuggestions = reply.trim()
                }
            } catch (e: Exception) {
                Toast.makeText(ctx, "Ошибка анализа фото: ${e.message ?: "нет связи"}", Toast.LENGTH_LONG).show()
            }
            statusText = ""
            busy = false
        }
    }

    val takePictureLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = pendingPhotoFile
        pendingPhotoFile = null
        if (f != null) {
            if (ok && f.exists() && f.length() > 0) {
                analyzeFridgePhoto(Uri.fromFile(f))
            } else {
                f.delete()
            }
        }
    }

    fun launchCamera() {
        try {
            val f = MediaFiles.newFile(ctx, false)
            pendingPhotoFile = f
            takePictureLauncher.launch(MediaFiles.uriFor(ctx, f))
        } catch (e: Exception) {
            Toast.makeText(ctx, "Не удалось открыть камеру", Toast.LENGTH_SHORT).show()
        }
    }

    val cameraPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchCamera()
        else Toast.makeText(ctx, "Нужен доступ к камере", Toast.LENGTH_SHORT).show()
    }

    val pickPhotoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) analyzeFridgePhoto(uri)
    }

    fun addQuick(word: String) {
        val cur = input.trim()
        val low = cur.lowercase()
        if (low.contains(word.lowercase())) return
        input = if (cur.isEmpty()) word else "$cur, $word"
    }

    fun generateWithAi() {
        val text = input.trim()
        if (busy || text.isEmpty()) return
        scope.launch {
            busy = true
            statusText = "ИИ составляет подробный рецепт…"
            try {
                val cfg = AiProviders.load(prefs)
                val prompt = "Придумай вкусное и реальное блюдо из этих продуктов: $text. " +
                    "Можно добавить базовые вещи (соль, перец, масло, вода). " +
                    "Опиши подробные граммовки и понятные шаги."
                val raw = withContext(Dispatchers.IO) {
                    AiClient.chatCfg(cfg, AiClient.recipeJsonSystem(), listOf("user" to prompt), 4096, true)
                }
                val parsed = AiClient.parseRecipeJson(raw)
                if (parsed == null) {
                    Toast.makeText(ctx, "ИИ не смог оформить рецепт, попробуйте ещё раз", Toast.LENGTH_LONG).show()
                } else {
                    val id = WebImport.addToBook(ctx, store, parsed.copy(sourceUrl = "Из холодильника (ИИ)"))
                    Toast.makeText(ctx, "Рецепт «${parsed.title}» добавлен в книгу", Toast.LENGTH_SHORT).show()
                    nav.navigate("recipe/$id")
                }
            } catch (e: Exception) {
                Toast.makeText(ctx, "Ошибка ИИ: ${e.message ?: "нет связи"}", Toast.LENGTH_LONG).show()
            }
            statusText = ""
            busy = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Что в холодильнике") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).fillMaxSize().imePadding(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                if (busy) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    if (statusText.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text(statusText, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                    }
                }
                Text(
                    "Сфотографируйте открытый холодильник или продукты — помощник сам определит, что есть, и предложит блюда.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                            if (granted) launchCamera()
                            else cameraPermLauncher.launch(Manifest.permission.CAMERA)
                        },
                        enabled = !busy,
                        modifier = Modifier.weight(1f).height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp)
                    ) {
                        Icon(Icons.Filled.CameraAlt, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Фото холодильника", fontSize = 13.sp, maxLines = 1)
                    }
                    FilledTonalButton(
                        onClick = { pickPhotoLauncher.launch("image/*") },
                        enabled = !busy,
                        modifier = Modifier.weight(1f).height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp)
                    ) {
                        Icon(Icons.Filled.PhotoLibrary, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Из галереи", fontSize = 13.sp, maxLines = 1)
                    }
                }
            }

            if (photoUri != null) {
                item {
                    AsyncImage(
                        model = photoUri,
                        contentDescription = "Фото холодильника",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(16.dp))
                    )
                }
            }

            if (aiSuggestions.isNotBlank()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                "🤖 Идеи от помощника",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                aiSuggestions,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    label = { Text("Продукты (заполнятся сами по фото или вручную)") },
                    trailingIcon = {
                        if (input.isNotEmpty()) {
                            IconButton(onClick = { input = "" }) { Icon(Icons.Filled.Close, "Очистить") }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    shape = RoundedCornerShape(14.dp)
                )
            }
            item {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    quickItems.forEach { itemName ->
                        AssistChip(onClick = { addQuick(itemName) }, label = { Text("+ $itemName") })
                    }
                }
            }
            item {
                FilledTonalButton(
                    onClick = { generateWithAi() },
                    enabled = input.isNotBlank() && !busy,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Filled.AutoAwesome, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (busy) "ИИ придумывает рецепт…" else "Сохранить новый рецепт в книгу", fontSize = 15.sp)
                }
            }

            if (tokens.isNotEmpty()) {
                item {
                    Text(
                        if (matched.isEmpty()) "В вашей книге совпадений нет — сохраните рецепт от ИИ кнопкой выше"
                        else "Подходящие рецепты в вашей книге (${matched.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                items(matched, key = { it.first.id }) { (r, hits) ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { nav.navigate("recipe/${r.id}") },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            RecipeImage(store, r, Modifier.size(64.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(r.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(
                                    "Совпадений: $hits из ${tokens.size}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
