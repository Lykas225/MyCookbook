package com.mycookbook.app

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

enum class OcrMode {
    HANDWRITING,
    PRINTED
}

data class OcrPageSpec(
    val uri: Uri,
    val rotationDeg: Int = 0,
    val cropLeft: Float = 0f,
    val cropTop: Float = 0f,
    val cropRight: Float = 1f,
    val cropBottom: Float = 1f,
    val enhanceInk: Boolean = true
)

data class OcrResult(
    val text: String,
    val engineName: String
)

object OcrEngine {
    private const val DEFAULT_OCR_SPACE_KEY = "helloworld"

    /** Dedicated Mistral OCR API (/v1/ocr) — отличный выбор для рукописного и печатного русского текста без VPN. */
    fun callMistralOcr(apiKey: String, imageBase64: String): String {
        val body = JSONObject()
            .put("model", "mistral-ocr-latest")
            .put(
                "document",
                JSONObject()
                    .put("type", "image_url")
                    .put("image_url", "data:image/jpeg;base64,$imageBase64")
            )
        val (code, text) = AiClient.post(
            "https://api.mistral.ai/v1/ocr",
            mapOf("Authorization" to "Bearer ${apiKey.trim()}"),
            body.toString()
        )
        if (code !in 200..299) {
            val msg = try {
                JSONObject(text).optString("message").ifBlank {
                    JSONObject(text).optJSONObject("error")?.optString("message") ?: text.take(180)
                }
            } catch (e: Exception) {
                text.take(180)
            }
            throw Exception("Mistral OCR $code: $msg")
        }
        val pagesArr = JSONObject(text).optJSONArray("pages")
            ?: throw Exception("Mistral OCR: пустой ответ")
        val sb = StringBuilder()
        for (i in 0 until pagesArr.length()) {
            val md = pagesArr.optJSONObject(i)?.optString("markdown")?.trim() ?: ""
            if (md.isNotEmpty()) {
                val cleaned = md.replace(Regex("!\\[[^\\]]*\\]\\([^)]*\\)"), "").trim()
                if (cleaned.isNotEmpty()) {
                    if (sb.isNotEmpty()) sb.append("\n\n")
                    sb.append(cleaned)
                }
            }
        }
        val out = sb.toString().trim()
        if (out.length < 4) throw Exception("Mistral OCR: текст не найден")
        return out
    }

    /** Бесплатный OCR.space API (работает в РФ без VPN и без регистрации, поддерживает русский язык). */
    fun callOcrSpace(
        imageBase64: String,
        apiKey: String = DEFAULT_OCR_SPACE_KEY,
        engine: Int = 1
    ): String {
        val form = "base64Image=" + URLEncoder.encode("data:image/jpeg;base64,$imageBase64", "UTF-8") +
            "&language=rus" +
            "&OCREngine=$engine" +
            "&scale=true" +
            "&detectOrientation=true" +
            "&isTable=true" +
            "&isOverlayRequired=false"
        val bytes = form.toByteArray(Charsets.UTF_8)
        var lastErr: Exception? = null
        for (attempt in 0..1) {
            try {
                val c = URL("https://api.ocr.space/parse/image").openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.useCaches = false
                c.connectTimeout = 15000
                c.readTimeout = 40000
                c.setFixedLengthStreamingMode(bytes.size)
                c.setRequestProperty("Connection", "close")
                c.setRequestProperty("apikey", apiKey.ifBlank { DEFAULT_OCR_SPACE_KEY })
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=utf-8")
                c.outputStream.use { it.write(bytes) }
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val resp = stream?.use { String(it.readBytes(), Charsets.UTF_8) } ?: ""
                c.disconnect()
                if (code !in 200..299) {
                    throw Exception("OCR.space код $code")
                }
                val o = JSONObject(resp)
                if (o.optBoolean("IsErroredOnProcessing", false)) {
                    val em = o.opt("ErrorMessage")
                    val msg = when (em) {
                        is JSONArray -> (0 until em.length()).joinToString("; ") { em.optString(it) }
                        else -> em?.toString() ?: "ошибка обработки"
                    }
                    throw Exception("OCR.space: $msg")
                }
                val parsed = o.optJSONArray("ParsedResults")
                val sb = StringBuilder()
                if (parsed != null) {
                    for (i in 0 until parsed.length()) {
                        val t = parsed.optJSONObject(i)?.optString("ParsedText") ?: ""
                        if (t.isNotBlank()) {
                            if (sb.isNotEmpty()) sb.append("\n")
                            sb.append(t.trim())
                        }
                    }
                }
                val clean = sb.toString()
                    .replace("\r\n", "\n")
                    .replace("\r", "\n")
                    .replace(Regex("\n{3,}"), "\n\n")
                    .trim()
                if (clean.length < 4) throw Exception("OCR.space: текст на фото не обнаружен")
                return clean
            } catch (e: Exception) {
                lastErr = e
                if (attempt == 0) Thread.sleep(600)
            }
        }
        throw (lastErr ?: Exception("OCR.space недоступен"))
    }

    private fun runVisionChain(
        prefs: SharedPreferences,
        mode: OcrMode,
        hiResB64: String,
        compactB64: String
    ): OcrResult {
        val cfg = AiProviders.load(prefs)
        val isHand = mode == OcrMode.HANDWRITING
        val sys = AiClient.ocrHandwritingSystem(isHand)
        val prompt = if (isHand) {
            "Внимательно расшифруй и перепиши ВЕСЬ РУКОПИСНЫЙ (или печатный) рецепт с этого фото на русском языке. " +
                "Читай курсив и слитные буквы максимально точно. Сохрани название, все ингредиенты с цифрами и мерами, шаги и пометки. " +
                "Не выдумывай то, чего нет на фото."
        } else {
            "Точно перепиши весь печатный текст кулинарного рецепта с этого фото на русском языке. " +
                "Сохрани все числа, граммовки, ингредиенты и шаги без выдумок."
        }

        val attempts = ArrayList<Pair<String, () -> String>>()

        fun addMistral(key: String) {
            if (key.isBlank()) return
            attempts.add("Mistral OCR" to { callMistralOcr(key, hiResB64) })
            attempts.add("Mistral Vision" to {
                AiClient.openAiVision(
                    AiConfig("mistral", key, "mistral-small-latest", "https://api.mistral.ai/v1"),
                    sys, prompt, hiResB64, maxTokens = 3072, temperature = 0.1
                )
            })
            attempts.add("Mistral Pixtral" to {
                AiClient.openAiVision(
                    AiConfig("mistral", key, "pixtral-12b-2409", "https://api.mistral.ai/v1"),
                    sys, prompt, hiResB64, maxTokens = 3072, temperature = 0.1
                )
            })
        }

        fun addOpenRouter(key: String) {
            if (key.isBlank()) return
            attempts.add("OpenRouter Qwen-VL" to {
                AiClient.openAiVision(
                    AiConfig("openrouter", key, "qwen/qwen2.5-vl-72b-instruct:free", "https://openrouter.ai/api/v1"),
                    sys, prompt, hiResB64, maxTokens = 3072, temperature = 0.1
                )
            })
            attempts.add("OpenRouter Gemma-3" to {
                AiClient.openAiVision(
                    AiConfig("openrouter", key, "google/gemma-3-27b-it:free", "https://openrouter.ai/api/v1"),
                    sys, prompt, hiResB64, maxTokens = 3072, temperature = 0.1
                )
            })
            attempts.add("OpenRouter Mistral-VL" to {
                AiClient.openAiVision(
                    AiConfig("openrouter", key, "mistralai/mistral-small-3.1-24b-instruct:free", "https://openrouter.ai/api/v1"),
                    sys, prompt, hiResB64, maxTokens = 3072, temperature = 0.1
                )
            })
        }

        fun addGemini(key: String, model: String = "gemini-flash-latest") {
            if (key.isBlank()) return
            attempts.add("Google Gemini Vision" to {
                AiClient.callVisionGemini(
                    key, model.ifBlank { "gemini-flash-latest" },
                    sys, prompt, hiResB64, maxTokens = 3072, temperature = 0.1
                )
            })
        }

        fun addGroq(key: String) {
            if (key.isBlank()) return
            attempts.add("Groq Llama-4 Vision" to {
                AiClient.openAiVision(
                    AiConfig("groq", key, "meta-llama/llama-4-scout-17b-16e-instruct", "https://api.groq.com/openai/v1"),
                    sys, prompt, hiResB64, maxTokens = 3072, temperature = 0.1
                )
            })
        }

        // 1. Сначала приоритетно пробуем выбранного пользователем провайдера
        when (cfg.provider) {
            "mistral" -> addMistral(cfg.key.ifBlank { AiProviders.effectiveKey(prefs, "mistral") })
            "openrouter" -> addOpenRouter(cfg.key.ifBlank { AiProviders.effectiveKey(prefs, "openrouter") })
            "gemini" -> addGemini(cfg.key.ifBlank { AiProviders.effectiveKey(prefs, "gemini") }, cfg.model)
            "groq", "groq_fast" -> addGroq(cfg.key.ifBlank { AiProviders.effectiveKey(prefs, "groq") })
            "custom" -> {
                if (cfg.baseUrl.isNotBlank() && cfg.model.isNotBlank()) {
                    attempts.add("Свой сервер Vision" to {
                        AiClient.openAiVision(cfg, sys, prompt, hiResB64, maxTokens = 3072, temperature = 0.1)
                    })
                }
            }
        }

        // 2. Затем все остальные доступные ключи (сохранённые пользователем + вшитые в сборку)
        if (cfg.provider != "mistral") addMistral(AiProviders.effectiveKey(prefs, "mistral"))
        if (cfg.provider != "openrouter") addOpenRouter(AiProviders.effectiveKey(prefs, "openrouter"))
        if (cfg.provider != "gemini") addGemini(AiProviders.effectiveKey(prefs, "gemini"))
        if (cfg.provider != "groq" && cfg.provider != "groq_fast") addGroq(AiProviders.effectiveKey(prefs, "groq"))

        // 3. Бесплатный Vision без ключа (компактное фото <= 300 КБ, чтобы не ловить 413/таймаут)
        attempts.add("Pollinations Vision" to {
            AiClient.openAiVision(
                AiConfig("pollinations", "", "openai", "https://text.pollinations.ai/openai"),
                sys, prompt, compactB64, maxTokens = 2500, temperature = 0.1
            )
        })
        attempts.add("Pollinations Fast Vision" to {
            AiClient.openAiVision(
                AiConfig("pollinations_fast", "", "openai-fast", "https://text.pollinations.ai/openai"),
                sys, prompt, compactB64, maxTokens = 2500, temperature = 0.1
            )
        })

        var lastEx: Exception? = null
        for ((name, fn) in attempts) {
            try {
                val res = fn().trim()
                if (res.length >= 6 && !AiClient.isVisionRefusal(res)) {
                    return OcrResult(res, name)
                }
            } catch (e: Exception) {
                lastEx = e
            }
        }
        throw (lastEx ?: Exception("Vision ИИ не смог распознать фото"))
    }

    /**
     * Главная функция распознавания страницы рецепта.
     * forceEngine: null (авто по режиму), "vision" (Vision ИИ), "ocr_space" (OCR.space).
     */
    fun recognizePage(
        ctx: Context,
        prefs: SharedPreferences,
        page: OcrPageSpec,
        mode: OcrMode,
        forceEngine: String? = null
    ): OcrResult {
        val hiBmp = AiClient.loadPreparedBitmap(
            ctx = ctx,
            uri = page.uri,
            maxDim = 1600,
            extraRotationDeg = page.rotationDeg,
            cropLeft = page.cropLeft,
            cropTop = page.cropTop,
            cropRight = page.cropRight,
            cropBottom = page.cropBottom,
            enhanceInk = page.enhanceInk
        )
        val (hiResB64, compactB64) = try {
            val hi = AiClient.compressBitmapToBase64(hiBmp, initialQuality = 88, maxBytes = 860 * 1024)
            // Компактная копия <= 1024px / 280KB специально для бесплатных серверов без ключа
            val cScale = minOf(1f, 1024f / maxOf(hiBmp.width, hiBmp.height).coerceAtLeast(1))
            val cBmp = if (cScale < 1f) {
                android.graphics.Bitmap.createScaledBitmap(
                    hiBmp,
                    (hiBmp.width * cScale).toInt().coerceAtLeast(1),
                    (hiBmp.height * cScale).toInt().coerceAtLeast(1),
                    true
                )
            } else hiBmp
            val comp = try {
                AiClient.compressBitmapToBase64(cBmp, initialQuality = 80, maxBytes = 280 * 1024)
            } finally {
                if (cBmp !== hiBmp) cBmp.recycle()
            }
            hi to comp
        } finally {
            hiBmp.recycle()
        }

        val ocrSpaceKey = prefs.getString("ocr_space_key", null)?.trim().orEmpty().ifBlank { DEFAULT_OCR_SPACE_KEY }

        if (forceEngine == "ocr_space") {
            val txt = callOcrSpace(hiResB64, ocrSpaceKey, engine = 1)
            return OcrResult(txt, "OCR.space (русский OCR)")
        }
        if (forceEngine == "vision") {
            return runVisionChain(prefs, mode, hiResB64, compactB64)
        }

        return when (mode) {
            OcrMode.PRINTED -> {
                // Для печатного текста и скриншотов: сначала быстрый и точный русский OCR.space (без выдумок и без VPN)
                var ocrErr: Exception? = null
                try {
                    val txt = callOcrSpace(hiResB64, ocrSpaceKey, engine = 1)
                    if (txt.length >= 15) {
                        return OcrResult(txt, "OCR.space (печатный)")
                    }
                    ocrErr = Exception("OCR.space вернул слишком мало текста")
                } catch (e: Exception) {
                    ocrErr = e
                }
                // Если OCR.space не справился — каскад на Vision ИИ
                try {
                    runVisionChain(prefs, mode, hiResB64, compactB64)
                } catch (e: Exception) {
                    throw Exception("Не удалось распознать печатный текст (${ocrErr?.message}; ${e.message})")
                }
            }
            OcrMode.HANDWRITING -> {
                // Для рукописного почерка: сначала Vision ИИ (Mistral OCR / Vision / Gemini / OpenRouter / Pollinations)
                var visErr: Exception? = null
                try {
                    return runVisionChain(prefs, mode, hiResB64, compactB64)
                } catch (e: Exception) {
                    visErr = e
                }
                // Запасной вариант — OCR.space (если вдруг нет ключей и Pollinations перегружен)
                try {
                    val txt = callOcrSpace(hiResB64, ocrSpaceKey, engine = 1)
                    OcrResult(txt, "OCR.space (запасной)")
                } catch (e: Exception) {
                    throw Exception("Не удалось распознать рукопись (${visErr?.message}; ${e.message})")
                }
            }
        }
    }

    /** Есть ли хотя бы один ключ сильного Vision ИИ (у пользователя или в сборке). */
    fun hasStrongVisionKey(prefs: SharedPreferences): Boolean =
        listOf("mistral", "openrouter", "gemini", "groq").any {
            AiProviders.effectiveKey(prefs, it).isNotBlank()
        }

    /** Локальный безотказный разбор текста рецепта, если ИИ-структурирование недоступно или вернуло ошибку. */
    fun parseRecipeTextLocally(rawText: String, sourceLabel: String = "Оцифрованный рецепт"): ParsedRecipe {
        val lines = rawText
            .replace("\r\n", "\n")
            .replace("\r", "\n")
            .lines()
            .map { it.replace(Regex("^[#*•\\-—–]+\\s*"), "").replace("**", "").trim() }
            .filter { it.isNotBlank() }

        val title = lines.firstOrNull { l ->
            val low = l.lowercase()
            !low.startsWith("ингредиент") && !low.startsWith("продукт") && !low.startsWith("приготовлен")
        }?.take(100) ?: "Оцифрованный рецепт"

        val ingredients = ArrayList<Ingredient>()
        val steps = ArrayList<String>()
        val secrets = ArrayList<String>()

        var section = 0 // 0=auto, 1=ingredients, 2=steps, 3=secrets
        val unitPattern = Regex(
            "(?:^|\\s)(\\d+\\s*/\\s*\\d+|\\d+(?:[.,]\\d+)?)\\s*(кг|мл|стакан\\w*|штук\\w*|шт|гр|грамм\\w*|г|л|ст\\.?\\s?л\\.?|ч\\.?\\s?л\\.?|щепот\\w*)\\b",
            RegexOption.IGNORE_CASE
        )

        for (rawLine in lines) {
            if (rawLine == title) continue
            val low = rawLine.lowercase().trimEnd(':')
            when {
                low.startsWith("ингредиент") || low.startsWith("продукт") || low.startsWith("понадобит") || low == "состав" -> {
                    section = 1; continue
                }
                low.startsWith("приготовлен") || low.startsWith("способ приготов") || low.startsWith("шаги") || low.startsWith("как готовить") -> {
                    section = 2; continue
                }
                low.startsWith("совет") || low.startsWith("секрет") || low.startsWith("заметк") || low.startsWith("примечан") -> {
                    section = 3; continue
                }
            }

            if (section == 3) {
                secrets.add(rawLine)
                continue
            }

            val isNumberedStep = Regex("^\\d+[.)]\\s+").containsMatchIn(rawLine)
            val m = unitPattern.find(rawLine)
            val looksLikeIngredient = !isNumberedStep && (
                section == 1 ||
                    (section == 0 && (m != null || low.contains("по вкусу")) && rawLine.length <= 75)
                )

            if (looksLikeIngredient) {
                if (m != null) {
                    val amt = parseNum(m.groupValues[1])
                    val uRaw = m.groupValues[2].lowercase()
                    val unit = when {
                        uRaw.startsWith("кг") -> "кг"
                        uRaw.startsWith("мл") -> "мл"
                        uRaw.startsWith("стак") -> "стакан"
                        uRaw.startsWith("шт") -> "шт"
                        uRaw.startsWith("гр") || uRaw == "г" -> "г"
                        uRaw == "л" -> "л"
                        uRaw.startsWith("ст") -> "ст.л."
                        uRaw.startsWith("ч") -> "ч.л."
                        uRaw.startsWith("щеп") -> "щепотка"
                        else -> ""
                    }
                    val nameClean = rawLine.removeRange(m.range)
                        .replace(Regex("[—–\\-:]+\\s*$"), "")
                        .replace(Regex("^\\s*[—–\\-:]+"), "")
                        .trim()
                    if (nameClean.isNotBlank()) {
                        ingredients.add(Ingredient(nameClean, amt, unit))
                    } else {
                        ingredients.add(Ingredient(rawLine, 0.0, ""))
                    }
                } else if (low.contains("по вкусу")) {
                    val nameClean = rawLine.replace(Regex("по вкусу", RegexOption.IGNORE_CASE), "")
                        .replace(Regex("[—–\\-:,]+\\s*$"), "")
                        .trim()
                    ingredients.add(Ingredient(nameClean.ifBlank { rawLine }, 0.0, "по вкусу"))
                } else {
                    ingredients.add(Ingredient(rawLine, 0.0, ""))
                }
            } else {
                val cleanStep = rawLine.replace(Regex("^\\d+[.)]\\s*"), "").trim()
                if (cleanStep.isNotBlank()) steps.add(cleanStep)
            }
        }

        val fullLow = rawText.lowercase()
        val tempMatch = Regex("(\\d{2,3})\\s*(?:°|º|градус|с\\b|c\\b)").find(fullLow)
        val tempC = tempMatch?.groupValues?.get(1)?.toIntOrNull()?.let { if (it in 60..300) it else 0 } ?: 0
        val servMatch = Regex("(\\d{1,2})\\s*порц").find(fullLow)
        val servings = servMatch?.groupValues?.get(1)?.toIntOrNull()?.let { if (it in 1..99) it else 4 } ?: 4

        val cat = when {
            listOf("суп", "борщ", "щи ", "уха", "солянк", "бульон").any { fullLow.contains(it) } -> 1
            listOf("салат").any { fullLow.contains(it) } -> 3
            listOf("пирог", "булоч", "тесто", "выпеч", "шарлотк", "кекс", "печень", "пицц", "хлеб", "ватруш", "пирожк").any { fullLow.contains(it) } -> 5
            listOf("торт", "десерт", "крем", "тирамису", "чизкейк", "мусс").any { fullLow.contains(it) } -> 6
            listOf("чай", "кофе", "компот", "морс", "напит", "коктейл", "лимонад").any { fullLow.contains(it) } -> 7
            listOf("заготов", "на зиму", "закат", "варень", "маринован", "солен", "консерв").any { fullLow.contains(it) } -> 8
            listOf("блин", "омлет", "каша", "сырник", "оладь", "завтрак", "яичниц").any { fullLow.contains(it) } -> 0
            listOf("закуск", "бутерброд", "паштет", "рулет").any { fullLow.contains(it) } -> 4
            else -> 2
        }

        return ParsedRecipe(
            title = title,
            description = "",
            servings = servings,
            timeMin = 0,
            tempC = tempC,
            ingredients = ingredients,
            steps = steps,
            imageUrl = null,
            sourceUrl = sourceLabel,
            category = cat,
            secrets = secrets.joinToString("\n")
        )
    }
}
