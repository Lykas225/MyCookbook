@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

data class ParsedRecipe(
    val title: String,
    val description: String,
    val servings: Int,
    val timeMin: Int,
    val tempC: Int,
    val ingredients: List<Ingredient>,
    val steps: List<String>,
    val imageUrl: String?,
    val sourceUrl: String,
    val category: Int
)

object WebImport {
    private const val UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    fun httpGet(url: String): String {
        val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 25000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept-Language", "ru,en;q=0.8")
        val bytes = c.inputStream.use { it.readBytes() }
        val ct = c.contentType ?: ""
        var cs = Regex("charset=([\\w-]+)", RegexOption.IGNORE_CASE).find(ct)?.groupValues?.get(1)
        if (cs == null) {
            val head = String(bytes, 0, minOf(bytes.size, 3000), Charsets.ISO_8859_1)
            cs = Regex("charset=[\"']?([\\w-]+)", RegexOption.IGNORE_CASE).find(head)?.groupValues?.get(1)
        }
        return try {
            String(bytes, charset(cs ?: "UTF-8"))
        } catch (e: Exception) {
            String(bytes, Charsets.UTF_8)
        }
    }

    private fun clean(s: String): String =
        android.text.Html.fromHtml(s, android.text.Html.FROM_HTML_MODE_LEGACY).toString().replace('\u00a0', ' ').trim()

    private fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k).trim()

    private fun guessCategory(text: String): Int {
        val t = text.lowercase()
        fun has(vararg w: String) = w.any { t.contains(it) }
        return when {
            has("суп", "борщ", "щи ", "бульон", "солянк", "уха", "soup") -> 1
            has("салат", "salad") -> 3
            has("торт", "десерт", "пирожн", "мороженое", "кекс", "печенье", "cake", "dessert", "pudding") -> 6
            has("напит", "коктейл", "компот", "лимонад", "smoothie", "drink") -> 7
            has("заготов", "варень", "соленьe", "маринов") -> 8
            has("пирог", "выпеч", "хлеб", "булоч", "пицца", "pie", "bread") -> 5
            has("блин", "омлет", "каша", "сырник", "яичниц", "оладь", "завтрак", "breakfast") -> 0
            has("закуск", "бутерброд", "starter", "side") -> 4
            else -> 2
        }
    }

    private fun parseIso(s: String): Int {
        val m = Regex("P(?:(\\d+)D)?T?(?:(\\d+)H)?(?:(\\d+)M)?", RegexOption.IGNORE_CASE).find(s.trim()) ?: return 0
        val d = m.groupValues[1].toIntOrNull() ?: 0
        val h = m.groupValues[2].toIntOrNull() ?: 0
        val mi = m.groupValues[3].toIntOrNull() ?: 0
        return d * 1440 + h * 60 + mi
    }

    private fun yieldOf(v: Any?): Int = when (v) {
        is Number -> v.toInt()
        is String -> Regex("\\d+").find(v)?.value?.toIntOrNull() ?: 0
        is JSONArray -> if (v.length() > 0) yieldOf(v.opt(0)) else 0
        else -> 0
    }

    private fun imageOf(v: Any?): String? = when (v) {
        is String -> v.ifBlank { null }
        is JSONArray -> if (v.length() > 0) imageOf(v.opt(0)) else null
        is JSONObject -> v.str("url").ifBlank { null }
        else -> null
    }

    private fun tempFrom(steps: List<String>): Int {
        val m = Regex("(\\d{2,3})\\s*(?:°|º|C\\b|градус)").find(steps.joinToString(" ")) ?: return 0
        val v = m.groupValues[1].toIntOrNull() ?: return 0
        return if (v in 60..300) v else 0
    }

    private val ingRe = Regex(
        "^\\s*(\\d+\\s*/\\s*\\d+|\\d+(?:[.,]\\d+)?)\\s*(кг|мл|стакан\\w*|штук\\w*|шт|гр|грамм\\w*|г|л|ст\\.?\\s?л\\.?|ч\\.?\\s?л\\.?)\\.?\\s+(.+)$",
        RegexOption.IGNORE_CASE
    )

    private fun parseIngredient(raw: String): Ingredient {
        val line = clean(raw)
        val m = ingRe.find(line) ?: return Ingredient(line, 0.0, "")
        val numS = m.groupValues[1].replace(" ", "")
        val num = if (numS.contains('/')) {
            val p = numS.split('/')
            (p[0].toDoubleOrNull() ?: 0.0) / (p[1].toDoubleOrNull() ?: 1.0)
        } else {
            numS.replace(',', '.').toDoubleOrNull() ?: 0.0
        }
        if (num <= 0.0 || num.isNaN() || num.isInfinite()) return Ingredient(line, 0.0, "")
        val u = m.groupValues[2].lowercase()
        val unit = when {
            u.startsWith("кг") -> "кг"
            u.startsWith("мл") -> "мл"
            u.startsWith("стак") -> "стакан"
            u.startsWith("шт") -> "шт"
            u.startsWith("гр") || u == "г" -> "г"
            u == "л" -> "л"
            u.startsWith("ст") -> "ст.л."
            u.startsWith("ч") -> "ч.л."
            else -> ""
        }
        return Ingredient(m.groupValues[3].trim(), num, unit)
    }

    private fun flattenSteps(n: Any?, out: MutableList<String>) {
        when (n) {
            is String -> n.split(Regex("\\r?\\n+")).map { clean(it) }.filter { it.isNotBlank() }.forEach { out.add(it) }
            is JSONArray -> for (i in 0 until n.length()) flattenSteps(n.opt(i), out)
            is JSONObject -> {
                val items = n.opt("itemListElement")
                if (items != null) flattenSteps(items, out)
                else flattenSteps(n.str("text").ifBlank { n.str("name") }, out)
            }
        }
    }

    private fun isRecipeType(t: Any?): Boolean = when (t) {
        is String -> t.equals("Recipe", ignoreCase = true)
        is JSONArray -> (0 until t.length()).any { isRecipeType(t.opt(it)) }
        else -> false
    }

    private fun findRecipe(n: Any?): JSONObject? {
        when (n) {
            is JSONArray -> {
                for (i in 0 until n.length()) {
                    val r = findRecipe(n.opt(i))
                    if (r != null) return r
                }
            }
            is JSONObject -> {
                if (isRecipeType(n.opt("@type"))) return n
                val g = findRecipe(n.opt("@graph"))
                if (g != null) return g
                val me = findRecipe(n.opt("mainEntity"))
                if (me != null) return me
            }
        }
        return null
    }

    fun parseRecipe(html: String, url: String): ParsedRecipe? {
        val re = Regex(
            "<script[^>]*type=[\"']application/ld\\+json[\"'][^>]*>(.*?)</script>",
            setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)
        )
        for (m in re.findAll(html)) {
            val txt = m.groupValues[1].trim()
            val any = try {
                org.json.JSONTokener(txt).nextValue()
            } catch (e: Exception) {
                continue
            }
            val r = findRecipe(any) ?: continue
            val p = fromRecipeJson(r, url)
            if (p != null) return p
        }
        return null
    }

    private fun fromRecipeJson(o: JSONObject, url: String): ParsedRecipe? {
        val title = clean(o.str("name"))
        if (title.isBlank()) return null
        val ingArr = o.optJSONArray("recipeIngredient") ?: o.optJSONArray("ingredients")
        val ings = ArrayList<Ingredient>()
        if (ingArr != null) {
            for (i in 0 until minOf(ingArr.length(), 60)) {
                val s = ingArr.optString(i)
                if (s.isNotBlank()) ings.add(parseIngredient(s))
            }
        }
        val steps = ArrayList<String>()
        flattenSteps(o.opt("recipeInstructions"), steps)
        val st = steps.take(40).map { it.take(700) }
        if (ings.isEmpty() && st.isEmpty()) return null
        var time = parseIso(o.str("totalTime"))
        if (time == 0) time = parseIso(o.str("cookTime")) + parseIso(o.str("prepTime"))
        var img = imageOf(o.opt("image"))
        if (img != null) {
            img = try {
                java.net.URL(java.net.URL(url), img).toString()
            } catch (e: Exception) {
                img
            }
        }
        val serv = yieldOf(o.opt("recipeYield")).let { if (it in 1..99) it else 4 }
        return ParsedRecipe(
            title = title,
            description = clean(o.str("description")).take(300),
            servings = serv,
            timeMin = time,
            tempC = tempFrom(st),
            ingredients = ings,
            steps = st,
            imageUrl = img,
            sourceUrl = url,
            category = guessCategory(title + " " + o.str("recipeCategory"))
        )
    }

    fun searchMeals(q: String): List<ParsedRecipe> {
        val txt = httpGet("https://www.themealdb.com/api/json/v1/1/search.php?s=" + java.net.URLEncoder.encode(q.trim(), "UTF-8"))
        val arr = JSONObject(txt).optJSONArray("meals") ?: return emptyList()
        val out = ArrayList<ParsedRecipe>()
        for (i in 0 until arr.length()) {
            val m = arr.getJSONObject(i)
            val ings = ArrayList<Ingredient>()
            for (k in 1..20) {
                val name = m.str("strIngredient$k")
                if (name.isBlank()) continue
                val measure = m.str("strMeasure$k")
                ings.add(Ingredient(if (measure.isBlank()) name else "$name — $measure", 0.0, ""))
            }
            val instr = m.str("strInstructions")
            var lines = instr.split(Regex("\\r?\\n+")).map { it.trim() }
                .filter { it.isNotBlank() && !Regex("(?i)^(step\\s*)?\\d+[.)]?$").matches(it) }
            if (lines.size < 3) {
                lines = instr.split(Regex("(?<=[.!?])\\s+")).map { it.trim() }.filter { it.isNotBlank() }
            }
            val cat = m.str("strCategory")
            val category = when (cat.lowercase()) {
                "dessert" -> 6
                "breakfast" -> 0
                "starter", "side" -> 4
                else -> 2
            }
            val src = m.str("strSource").ifBlank { "https://www.themealdb.com/meal/" + m.str("idMeal") }
            out.add(
                ParsedRecipe(
                    title = m.str("strMeal"),
                    description = listOf(cat, m.str("strArea")).filter { it.isNotBlank() }.joinToString(", "),
                    servings = 4,
                    timeMin = 0,
                    tempC = tempFrom(lines),
                    ingredients = ings,
                    steps = lines.take(40),
                    imageUrl = m.str("strMealThumb").ifBlank { null },
                    sourceUrl = src,
                    category = category
                )
            )
        }
        return out
    }

    private fun downloadImage(ctx: Context, url: String): String? = try {
        val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 25000
        c.setRequestProperty("User-Agent", UA)
        val f = MediaFiles.newFile(ctx, false)
        c.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        if (f.length() > 1000) f.absolutePath else {
            f.delete()
            null
        }
    } catch (e: Exception) {
        null
    }

    suspend fun addToBook(ctx: Context, store: CookbookStore, p: ParsedRecipe): String {
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val mediaList = ArrayList<MediaItem>()
        val u = p.imageUrl
        if (u != null) {
            val path = withContext(Dispatchers.IO) { downloadImage(ctx, u) }
            if (path != null) mediaList.add(MediaItem(UUID.randomUUID().toString(), path, false, id, now))
        }
        val r = Recipe(
            id = id,
            title = p.title,
            category = p.category,
            description = p.description,
            servings = p.servings,
            ingredients = p.ingredients,
            tempC = p.tempC,
            timeMin = p.timeMin,
            notes = "Источник: " + p.sourceUrl,
            secrets = "",
            steps = p.steps.map { Step(it) },
            favorite = false,
            lastViewed = 0L,
            createdAt = now
        )
        store.saveRecipe(r, mediaList)
        return id
    }
}

@Composable
fun WebScreen(store: CookbookStore, nav: NavHostController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var catalogQuery by remember { mutableStateOf("") }
    var link by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var currentUrl by remember { mutableStateOf("") }
    var canBack by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf<List<ParsedRecipe>>(emptyList()) }
    var searched by remember { mutableStateOf(false) }
    val webHolder = remember { arrayOfNulls<android.webkit.WebView>(1) }

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_LONG).show()

    fun addParsed(p: ParsedRecipe) {
        if (busy) return
        scope.launch {
            busy = true
            try {
                val id = WebImport.addToBook(ctx, store, p)
                toast("Добавлено в книгу")
                nav.navigate("recipe/$id")
            } catch (e: Exception) {
                toast("Не удалось сохранить рецепт")
            }
            busy = false
        }
    }

    fun addFromUrl(raw: String) {
        if (busy) return
        var url = raw.trim()
        if (url.isEmpty()) return
        if (!url.startsWith("http")) url = "https://$url"
        scope.launch {
            busy = true
            try {
                val html = withContext(Dispatchers.IO) { WebImport.httpGet(url) }
                val p = WebImport.parseRecipe(html, url)
                if (p == null) {
                    toast("На этой странице не найден рецепт. Откройте страницу самого рецепта.")
                } else {
                    val id = WebImport.addToBook(ctx, store, p)
                    toast("Добавлено в книгу")
                    nav.navigate("recipe/$id")
                }
            } catch (e: Exception) {
                toast("Не удалось загрузить страницу. Проверьте интернет.")
            }
            busy = false
        }
    }

    fun searchCatalog() {
        if (busy || catalogQuery.isBlank()) return
        scope.launch {
            busy = true
            try {
                results = withContext(Dispatchers.IO) { WebImport.searchMeals(catalogQuery) }
                searched = true
            } catch (e: Exception) {
                toast("Не удалось выполнить поиск. Проверьте интернет.")
            }
            busy = false
        }
    }

    BackHandler(enabled = tab == 0 && canBack) { webHolder[0]?.goBack() }
    DisposableEffect(Unit) { onDispose { webHolder[0]?.destroy() } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Рецепты из интернета") },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            TabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.background) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("🔎 Поиск") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("📚 Каталог") })
                Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("🔗 Ссылка") })
            }

            if (tab == 0) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        query, { query = it },
                        placeholder = { Text("Например: борщ") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = {
                        webHolder[0]?.loadUrl(
                            "https://www.google.com/search?hl=ru&q=" + java.net.URLEncoder.encode("рецепт $query", "UTF-8")
                        )
                    }) { Icon(Icons.Filled.Search, "Найти") }
                }
            }

            Box(if (tab == 0) Modifier.weight(1f).fillMaxWidth() else Modifier.size(0.dp)) {
                AndroidView(
                    factory = { c ->
                        android.webkit.WebView(c).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            webViewClient = object : android.webkit.WebViewClient() {
                                override fun onPageFinished(view: android.webkit.WebView?, url: String?) {
                                    currentUrl = url ?: ""
                                    canBack = view?.canGoBack() ?: false
                                }

                                override fun doUpdateVisitedHistory(view: android.webkit.WebView?, url: String?, isReload: Boolean) {
                                    currentUrl = url ?: ""
                                    canBack = view?.canGoBack() ?: false
                                }
                            }
                            webHolder[0] = this
                            loadUrl("https://www.google.com/search?hl=ru&q=" + java.net.URLEncoder.encode("рецепты", "UTF-8"))
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }

            if (tab == 0) {
                Button(
                    onClick = { addFromUrl(currentUrl) },
                    enabled = !busy && currentUrl.startsWith("http") && !currentUrl.contains("google."),
                    modifier = Modifier.fillMaxWidth().padding(12.dp).height(50.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Filled.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Добавить эту страницу в книгу")
                }
            }

            if (tab == 1) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        catalogQuery, { catalogQuery = it },
                        placeholder = { Text("На английском: chicken, pasta…") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { searchCatalog() }) { Icon(Icons.Filled.Search, "Найти") }
                }
                if (searched && results.isEmpty()) HintText("Ничего не найдено. Попробуйте английское название.")
                LazyColumn(
                    Modifier.weight(1f),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(results, key = { it.sourceUrl + it.title }) { p ->
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))) {
                            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                AsyncImage(
                                    model = p.imageUrl,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.size(72.dp).clip(RoundedCornerShape(12.dp))
                                )
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(p.title, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Text(p.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Button(onClick = { addParsed(p) }, enabled = !busy, contentPadding = PaddingValues(horizontal = 12.dp)) {
                                    Text("В книгу")
                                }
                            }
                        }
                    }
                }
            }

            if (tab == 2) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Вставьте ссылку на страницу с рецептом — приложение заберёт название, продукты, шаги и фото.")
                    OutlinedTextField(
                        link, { link = it },
                        label = { Text("Ссылка на рецепт") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = { addFromUrl(link) },
                        enabled = !busy && link.isNotBlank(),
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) { Text("Добавить в книгу") }
                }
            }
        }
    }
}
