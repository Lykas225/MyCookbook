@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Jsoup
import java.util.UUID

data class ParsedRecipe(
    val title: String,
    val description: String,
    val servings: Int,
    val timeMin: Int,
    val tempC: Int,
    val ingredients: List<Ingredient>,
    val steps: List<String>,
    val imageUrl: String?,
    val sourceUrl: String,
    val category: Int
)

object WebImport {
    private const val UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    private val ruToEn = listOf(
        "куриц" to "chicken",
        "цыпл" to "chicken",
        "говядин" to "beef",
        "стейк" to "steak",
        "свинин" to "pork",
        "баранин" to "lamb",
        "рыб" to "fish",
        "лосос" to "salmon",
        "сёмг" to "salmon",
        "семг" to "salmon",
        "тунец" to "tuna",
        "треск" to "cod",
        "кревет" to "shrimp",
        "паст" to "pasta",
        "спагетти" to "spaghetti",
        "макарон" to "pasta",
        "лазань" to "lasagna",
        "пицц" to "pizza",
        "суп" to "soup",
        "борщ" to "soup",
        "салат" to "salad",
        "торт" to "cake",
        "пирог" to "pie",
        "выпечк" to "pie",
        "десерт" to "dessert",
        "печень" to "cookie",
        "брауни" to "brownie",
        "чизкейк" to "cheesecake",
        "блин" to "pancake",
        "панкейк" to "pancake",
        "завтрак" to "breakfast",
        "омлет" to "omelette",
        "яйц" to "egg",
        "картоф" to "potato",
        "картош" to "potato",
        "рис" to "rice",
        "плов" to "rice",
        "бургер" to "burger",
        "котлет" to "burger",
        "гриб" to "mushroom",
        "шампиньон" to "mushroom",
        "сыр" to "cheese",
        "шоколад" to "chocolate",
        "карри" to "curry",
        "лапш" to "noodle",
        "хлеб" to "bread",
        "яблок" to "apple",
        "лимон" to "lemon",
        "клубник" to "strawberry",
        "банан" to "banana",
        "томат" to "tomato",
        "помидор" to "tomato",
        "капуст" to "cabbage",
        "фасол" to "bean",
        "чечевиц" to "lentil",
        "тыкв" to "pumpkin",
        "баклажан" to "eggplant",
        "утк" to "duck",
        "индейк" to "turkey",
        "морепродукт" to "seafood",
        "тако" to "taco",
        "мяс" to "beef"
    )

    fun translateCatalogQuery(raw: String): String {
        val q = raw.trim().lowercase()
        if (q.isEmpty()) return ""
        val hasCyrillic = q.any { it in 'а'..'я' || it == 'ё' }
        if (!hasCyrillic) return q
        for ((ru, en) in ruToEn) {
            if (q.contains(ru)) return en
        }
        return ""
    }

    fun extractUrl(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return ""
        val found = Regex("https?://[^\\s<>\"']+").find(trimmed)?.value
        if (found != null) {
            return found.trimEnd('.', ',', ';', ')', ']', '!')
        }
        val firstToken = trimmed.split(Regex("\\s+")).firstOrNull()?.trim() ?: ""
        if (firstToken.contains('.')) return "https://$firstToken"
        return ""
    }

    fun httpGet(url: String): String {
        var current = url
        for (hop in 0..4) {
            val c = java.net.URL(current).openConnection() as java.net.HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 25000
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            c.setRequestProperty("Accept-Language", "ru-RU,ru;q=0.9,en;q=0.8")
            val code = c.responseCode
            if (code in listOf(301, 302, 303, 307, 308)) {
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (loc.isNullOrBlank()) throw Exception("пустой редирект ($code)")
                current = java.net.URL(java.net.URL(current), loc).toString()
                continue
            }
            if (code !in 200..299) {
                c.disconnect()
                throw Exception("сайт ответил кодом $code")
            }
            val bytes = c.inputStream.use { it.readBytes() }
            val ct = c.contentType ?: ""
            c.disconnect()
            var cs = Regex("charset=([\\w-]+)", RegexOption.IGNORE_CASE).find(ct)?.groupValues?.get(1)
            if (cs == null) {
                val head = String(bytes, 0, minOf(bytes.size, 3000), Charsets.ISO_8859_1)
                cs = Regex("charset=[\"']?([\\w-]+)", RegexOption.IGNORE_CASE).find(head)?.groupValues?.get(1)
            }
            return try {
                String(bytes, charset(cs ?: "UTF-8"))
            } catch (e: Exception) {
                String(bytes, Charsets.UTF_8)
            }
        }
        throw Exception("слишком много перенаправлений")
    }

    fun fetchHtml(url: String): String {
        return try {
            Jsoup.connect(url)
                .userAgent(UA)
                .header("Accept-Language", "ru-RU,ru;q=0.9,en;q=0.8")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .followRedirects(true)
                .ignoreContentType(true)
                .timeout(20000)
                .execute()
                .body()
        } catch (e: Exception) {
            httpGet(url)
        }
    }

    private fun clean(s: String): String =
        android.text.Html.fromHtml(s, android.text.Html.FROM_HTML_MODE_LEGACY).toString().replace('\u00a0', ' ').trim()

    private fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k).trim()

    private fun guessCategory(text: String): Int {
        val t = text.lowercase()
        fun has(vararg w: String) = w.any { t.contains(it) }
        return when {
            has("суп", "борщ", "щи ", "бульон", "солянк", "уха", "soup") -> 1
            has("салат", "salad") -> 3
            has("торт", "десерт", "пирожн", "мороженое", "кекс", "печенье", "cake", "dessert", "pudding") -> 6
            has("напит", "коктейл", "компот", "лимонад", "smoothie", "drink") -> 7
            has("заготов", "варень", "солень", "маринов", "консерв") -> 8
            has("пирог", "выпеч", "хлеб", "булоч", "пицца", "pie", "bread") -> 5
            has("блин", "омлет", "каша", "сырник", "яичниц", "оладь", "завтрак", "breakfast") -> 0
            has("закуск", "бутерброд", "starter", "side") -> 4
            else -> 2
        }
    }

    private fun parseIso(s: String): Int {
        val m = Regex("P(?:(\\d+)D)?T?(?:(\\d+)H)?(?:(\\d+)M)?", RegexOption.IGNORE_CASE).find(s.trim()) ?: return 0
        val d = m.groupValues[1].toIntOrNull() ?: 0
        val h = m.groupValues[2].toIntOrNull() ?: 0
        val mi = m.groupValues[3].toIntOrNull() ?: 0
        return d * 1440 + h * 60 + mi
    }

    private fun yieldOf(v: Any?): Int = when (v) {
        is Number -> v.toInt()
        is String -> Regex("\\d+").find(v)?.value?.toIntOrNull() ?: 0
        is JSONArray -> if (v.length() > 0) yieldOf(v.opt(0)) else 0
        else -> 0
    }

    private fun imageOf(v: Any?): String? = when (v) {
        is String -> v.ifBlank { null }
        is JSONArray -> if (v.length() > 0) imageOf(v.opt(0)) else null
        is JSONObject -> v.str("url").ifBlank { null }
        else -> null
    }

    private fun tempFrom(steps: List<String>): Int {
        val m = Regex("(\\d{2,3})\\s*(?:°|º|C\\b|градус)").find(steps.joinToString(" ")) ?: return 0
        val v = m.groupValues[1].toIntOrNull() ?: return 0
        return if (v in 60..300) v else 0
    }

    private val ingRe = Regex(
        "^\\s*(\\d+\\s*/\\s*\\d+|\\d+(?:[.,]\\d+)?)\\s*(кг|мл|стакан\\w*|штук\\w*|шт|гр|грамм\\w*|г|л|ст\\.?\\s?л\\.?|ч\\.?\\s?л\\.?)\\.?\\s+(.+)$",
        RegexOption.IGNORE_CASE
    )

    private fun parseIngredient(raw: String): Ingredient {
        val line = clean(raw)
        val m = ingRe.find(line) ?: return Ingredient(line, 0.0, "")
        val numS = m.groupValues[1].replace(" ", "")
        val num = if (numS.contains('/')) {
            val p = numS.split('/')
            (p[0].toDoubleOrNull() ?: 0.0) / (p[1].toDoubleOrNull() ?: 1.0)
        } else {
            numS.replace(',', '.').toDoubleOrNull() ?: 0.0
        }
        if (num <= 0.0 || num.isNaN() || num.isInfinite()) return Ingredient(line, 0.0, "")
        val u = m.groupValues[2].lowercase()
        val unit = when {
            u.startsWith("кг") -> "кг"
            u.startsWith("мл") -> "мл"
            u.startsWith("стак") -> "стакан"
            u.startsWith("шт") -> "шт"
            u.startsWith("гр") || u == "г" -> "г"
            u == "л" -> "л"
            u.startsWith("ст") -> "ст.л."
            u.startsWith("ч") -> "ч.л."
            else -> ""
        }
        return Ingredient(m.groupValues[3].trim(), num, unit)
    }

    private fun flattenSteps(n: Any?, out: MutableList<String>) {
        when (n) {
            is String -> n.split(Regex("\\r?\\n+")).map { clean(it) }.filter { it.isNotBlank() }.forEach { out.add(it) }
            is JSONArray -> for (i in 0 until n.length()) flattenSteps(n.opt(i), out)
            is JSONObject -> {
                val items = n.opt("itemListElement")
                if (items != null) flattenSteps(items, out)
                else flattenSteps(n.str("text").ifBlank { n.str("name") }, out)
            }
        }
    }

    private fun isRecipeType(t: Any?): Boolean = when (t) {
        is String -> t.equals("Recipe", ignoreCase = true) || t.endsWith("/Recipe", ignoreCase = true)
        is JSONArray -> (0 until t.length()).any { isRecipeType(t.opt(it)) }
        else -> false
    }

    private fun findRecipe(n: Any?): JSONObject? {
        when (n) {
            is JSONArray -> {
                for (i in 0 until n.length()) {
                    val r = findRecipe(n.opt(i))
                    if (r != null) return r
                }
            }
            is JSONObject -> {
                if (isRecipeType(n.opt("@type"))) return n
                val g = findRecipe(n.opt("@graph"))
                if (g != null) return g
                val me = findRecipe(n.opt("mainEntity"))
                if (me != null) return me
            }
        }
        return null
    }

    fun parseRecipe(html: String, url: String): ParsedRecipe? {
        val re = Regex(
            "<script[^>]*type=[\"']application/ld\\+json[\"'][^>]*>(.*?)</script>",
            setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)
        )
        for (m in re.findAll(html)) {
            val txt = m.groupValues[1].trim()
            val any = try {
                org.json.JSONTokener(txt).nextValue()
            } catch (e: Exception) {
                continue
            }
            val r = findRecipe(any) ?: continue
            val p = fromRecipeJson(r, url)
            if (p != null) return p
        }
        return parseMicrodata(html, url)
    }

    private fun parseMicrodata(html: String, url: String): ParsedRecipe? {
        return try {
            val doc = Jsoup.parse(html, url)
            val ingEls = doc.select("[itemprop=recipeIngredient], [itemprop=ingredients]")
            val stepEls = doc.select("[itemprop=recipeInstructions] [itemprop=text], [itemprop=recipeInstructions] li, [itemprop=recipeInstructions] p, [itemprop=recipeInstructions]")
            if (ingEls.isEmpty() && stepEls.isEmpty()) return null

            val title = doc.selectFirst("[itemtype*=Recipe] [itemprop=name]")?.text()?.trim()
                ?.ifBlank { null }
                ?: doc.selectFirst("h1")?.text()?.trim()?.ifBlank { null }
                ?: doc.selectFirst("meta[property=og:title]")?.attr("content")?.trim()?.ifBlank { null }
                ?: doc.title().trim()
            if (title.isBlank()) return null

            val ings = ingEls.map { it.text().trim() }.filter { it.isNotBlank() }.distinct().take(60)
                .map { parseIngredient(it) }

            val rawSteps = ArrayList<String>()
            val specificSteps = doc.select("[itemprop=recipeInstructions] [itemprop=text], [itemprop=recipeInstructions] li, [itemprop=recipeInstructions] p")
            val sourceSteps = if (specificSteps.isNotEmpty()) specificSteps else doc.select("[itemprop=recipeInstructions]")
            for (el in sourceSteps) {
                val t = el.text().trim()
                if (t.length >= 6 && t !in rawSteps) rawSteps.add(t.take(700))
            }
            if (ings.isEmpty() && rawSteps.isEmpty()) return null

            val img = doc.selectFirst("[itemtype*=Recipe] [itemprop=image]")?.let {
                it.attr("abs:src").ifBlank { it.attr("content") }
            }?.ifBlank { null } ?: extractOgImage(doc)

            val desc = doc.selectFirst("[itemtype*=Recipe] [itemprop=description]")?.text()?.trim()?.ifBlank { null }
                ?: doc.selectFirst("meta[property=og:description]")?.attr("content")?.trim()
                ?: ""

            val servStr = doc.selectFirst("[itemprop=recipeYield]")?.let {
                it.attr("content").ifBlank { it.text() }
            } ?: ""
            val serv = yieldOf(servStr).let { if (it in 1..99) it else 4 }

            val timeStr = doc.selectFirst("[itemprop=totalTime]")?.attr("content")?.ifBlank { null }
                ?: doc.selectFirst("[itemprop=cookTime]")?.attr("content") ?: ""
            val timeMin = parseIso(timeStr)

            ParsedRecipe(
                title = title,
                description = desc.take(300),
                servings = serv,
                timeMin = timeMin,
                tempC = tempFrom(rawSteps),
                ingredients = ings,
                steps = rawSteps.take(40),
                imageUrl = img,
                sourceUrl = url,
                category = guessCategory(title + " " + desc)
            )
        } catch (e: Exception) {
            null
        }
    }

    fun extractOgImage(doc: org.jsoup.nodes.Document): String? {
        return doc.selectFirst("meta[property=og:image]")?.attr("abs:content")?.ifBlank { null }
            ?: doc.selectFirst("meta[property=og:image]")?.attr("content")?.ifBlank { null }
            ?: doc.selectFirst("meta[name=twitter:image]")?.attr("content")?.ifBlank { null }
    }

    private fun fromRecipeJson(o: JSONObject, url: String): ParsedRecipe? {
        val title = clean(o.str("name"))
        if (title.isBlank()) return null
        val ingArr = o.optJSONArray("recipeIngredient") ?: o.optJSONArray("ingredients")
        val ings = ArrayList<Ingredient>()
        if (ingArr != null) {
            for (i in 0 until minOf(ingArr.length(), 60)) {
                val s = ingArr.optString(i)
                if (s.isNotBlank()) ings.add(parseIngredient(s))
            }
        }
        val steps = ArrayList<String>()
        flattenSteps(o.opt("recipeInstructions"), steps)
        val st = steps.take(40).map { it.take(700) }
        if (ings.isEmpty() && st.isEmpty()) return null
        var time = parseIso(o.str("totalTime"))
        if (time == 0) time = parseIso(o.str("cookTime")) + parseIso(o.str("prepTime"))
        var img = imageOf(o.opt("image"))
        if (img != null) {
            img = try {
                java.net.URL(java.net.URL(url), img).toString()
            } catch (e: Exception) {
                img
            }
        }
        val serv = yieldOf(o.opt("recipeYield")).let { if (it in 1..99) it else 4 }
        return ParsedRecipe(
            title = title,
            description = clean(o.str("description")).take(300),
            servings = serv,
            timeMin = time,
            tempC = tempFrom(st),
            ingredients = ings,
            steps = st,
            imageUrl = img,
            sourceUrl = url,
            category = guessCategory(title + " " + o.str("recipeCategory"))
        )
    }

    fun searchMeals(q: String): List<ParsedRecipe> {
        val en = translateCatalogQuery(q)
        if (en.isBlank()) return emptyList()
        val txt = httpGet("https://www.themealdb.com/api/json/v1/1/search.php?s=" + java.net.URLEncoder.encode(en, "UTF-8"))
        val arr = JSONObject(txt).optJSONArray("meals") ?: return emptyList()
        val out = ArrayList<ParsedRecipe>()
        for (i in 0 until arr.length()) {
            val m = arr.getJSONObject(i)
            val ings = ArrayList<Ingredient>()
            for (k in 1..20) {
                val name = m.str("strIngredient$k")
                if (name.isBlank()) continue
                val measure = m.str("strMeasure$k")
                ings.add(Ingredient(if (measure.isBlank()) name else "$name — $measure", 0.0, ""))
            }
            val instr = m.str("strInstructions")
            var lines = instr.split(Regex("\\r?\\n+")).map { it.trim() }
                .filter { it.isNotBlank() && !Regex("(?i)^(step\\s*)?\\d+[.)]?$").matches(it) }
            if (lines.size < 3) {
                lines = instr.split(Regex("(?<=[.!?])\\s+")).map { it.trim() }.filter { it.isNotBlank() }
            }
            val cat = m.str("strCategory")
            val category = when (cat.lowercase()) {
                "dessert" -> 6
                "breakfast" -> 0
                "starter", "side" -> 4
                else -> 2
            }
            val src = m.str("strSource").ifBlank { "https://www.themealdb.com/meal/" + m.str("idMeal") }
            out.add(
                ParsedRecipe(
                    title = m.str("strMeal"),
                    description = listOf(cat, m.str("strArea")).filter { it.isNotBlank() }.joinToString(", "),
                    servings = 4,
                    timeMin = 0,
                    tempC = tempFrom(lines),
                    ingredients = ings,
                    steps = lines.take(40),
                    imageUrl = m.str("strMealThumb").ifBlank { null },
                    sourceUrl = src,
                    category = category
                )
            )
        }
        return out
    }

    fun searchCatalogWithAi(ctx: Context, query: String): List<ParsedRecipe> {
        val prefs = ctx.getSharedPreferences("cookbook_prefs", Context.MODE_PRIVATE)
        val cfg = AiProviders.load(prefs)
        val sys = "Ты кулинарный каталог. Верни ТОЛЬКО JSON-массив из 3 разных подробных рецептов на русском языке по запросу пользователя, без markdown и пояснений. " +
            "Каждый объект массива содержит: title (строка), description (краткое описание), servings (целое), timeMin (целое, минуты), tempC (целое, 0 если не нужна), " +
            "category (0 завтраки, 1 супы, 2 основные блюда, 3 салаты, 4 закуски, 5 выпечка, 6 десерты, 7 напитки, 8 консервация), " +
            "ingredients (массив объектов name, amount число, unit одно из: г, кг, мл, л, шт, ст.л., ч.л., стакан, щепотка, по вкусу), " +
            "steps (массив строк)."
        val raw = AiClient.chatCfg(cfg, sys, listOf("user" to "Найди 3 вкусных рецепта по запросу: $query"), 4096, false)
        val a = raw.indexOf('[')
        val b = raw.lastIndexOf(']')
        if (a < 0 || b <= a) {
            val single = AiClient.parseRecipeJson(raw)
            return if (single != null) listOf(single.copy(sourceUrl = "Онлайн-каталог (ИИ)")) else emptyList()
        }
        val arr = JSONArray(raw.substring(a, b + 1))
        val out = ArrayList<ParsedRecipe>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val p = AiClient.parseRecipeJson(obj.toString())
            if (p != null) {
                out.add(p.copy(sourceUrl = "Онлайн-каталог (ИИ)"))
            }
        }
        return out
    }

    private fun downloadImage(ctx: Context, url: String): String? = try {
        val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 25000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        val f = MediaFiles.newFile(ctx, false)
        c.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        if (f.length() > 1000) f.absolutePath else {
            f.delete()
            null
        }
    } catch (e: Exception) {
        null
    }

    suspend fun addToBook(ctx: Context, store: CookbookStore, p: ParsedRecipe): String {
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val mediaList = ArrayList<MediaItem>()
        val u = p.imageUrl
        if (u != null) {
            val path = withContext(Dispatchers.IO) { downloadImage(ctx, u) }
            if (path != null) mediaList.add(MediaItem(UUID.randomUUID().toString(), path, false, id, now))
        }
        val r = Recipe(
            id = id,
            title = p.title,
            category = p.category,
            description = p.description,
            servings = p.servings,
            ingredients = p.ingredients,
            tempC = p.tempC,
            timeMin = p.timeMin,
            notes = "Источник: " + p.sourceUrl,
            secrets = "",
            steps = p.steps.map { Step(it) },
            favorite = false,
            lastViewed = 0L,
            createdAt = now
        )
        store.saveRecipe(r, mediaList)
        return id
    }
}

@Composable
fun WebScreen(store: CookbookStore, nav: NavHostController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var catalogQuery by remember { mutableStateOf("") }
    var link by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var statusMsg by remember { mutableStateOf("") }
    var linkError by remember { mutableStateOf("") }
    var catalogError by remember { mutableStateOf("") }
    var currentUrl by remember { mutableStateOf("") }
    var canBack by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf<List<ParsedRecipe>>(emptyList()) }
    var searched by remember { mutableStateOf(false) }
    val webHolder = remember { arrayOfNulls<android.webkit.WebView>(1) }

    val catalogChips = remember {
        listOf(
            "🍗 Курица" to "курица",
            "🍝 Паста" to "паста",
            "🍲 Супы" to "суп",
            "🥗 Салаты" to "салат",
            "🍰 Десерты" to "десерт",
            "🥞 Завтраки" to "завтрак",
            "🥩 Говядина" to "говядина",
            "🐟 Рыба" to "лосось",
            "🥧 Выпечка" to "пирог"
        )
    }

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_LONG).show()

    fun addParsed(p: ParsedRecipe) {
        if (busy) return
        scope.launch {
            busy = true
            statusMsg = "Сохраняю «${p.title}»…"
            try {
                val id = WebImport.addToBook(ctx, store, p)
                toast("Добавлено в книгу")
                nav.navigate("recipe/$id")
            } catch (e: Exception) {
                toast("Не удалось сохранить рецепт")
            }
            statusMsg = ""
            busy = false
        }
    }

    suspend fun parseHtmlWithFallback(html: String, url: String): ParsedRecipe? {
        val direct = WebImport.parseRecipe(html, url)
        if (direct != null) return direct

        statusMsg = "Разбираю текст страницы через ИИ…"
        val doc = withContext(Dispatchers.IO) { Jsoup.parse(html, url) }
        val ogImg = WebImport.extractOgImage(doc)
        doc.select("script, style, nav, footer, aside, noscript").remove()
        val text = doc.body().text().take(8000)
        if (text.length < 60) return null

        val prefs = ctx.getSharedPreferences("cookbook_prefs", Context.MODE_PRIVATE)
        val cfg = AiProviders.load(prefs)
        val aiRaw = withContext(Dispatchers.IO) {
            AiClient.chatCfg(cfg, AiClient.recipeJsonSystem(), listOf("user" to text), 4096, true)
        }
        return AiClient.parseRecipeJson(aiRaw)?.copy(
            sourceUrl = url,
            imageUrl = ogImg
        )
    }

    fun addFromUrl(raw: String, preloadedHtml: String? = null) {
        if (busy) return
        val url = WebImport.extractUrl(raw)
        if (url.isEmpty()) {
            linkError = "Вставьте корректную ссылку, начинающуюся с https://"
            toast(linkError)
            return
        }
        linkError = ""
        scope.launch {
            busy = true
            statusMsg = "Загружаю страницу…"
            try {
                val html = if (!preloadedHtml.isNullOrBlank() && preloadedHtml.length > 200) {
                    preloadedHtml
                } else {
                    withContext(Dispatchers.IO) { WebImport.fetchHtml(url) }
                }
                val p = parseHtmlWithFallback(html, url)
                if (p == null) {
                    linkError = "Не удалось найти рецепт на этой странице. Убедитесь, что ссылка ведёт на конкретный рецепт, или откройте её во вкладке «Поиск»."
                    toast("Рецепт на странице не найден")
                } else {
                    statusMsg = "Сохраняю рецепт…"
                    val id = WebImport.addToBook(ctx, store, p)
                    toast("Добавлено в книгу")
                    nav.navigate("recipe/$id")
                }
            } catch (e: Exception) {
                val msg = e.message ?: "нет связи"
                linkError = "Ошибка загрузки ($msg). Если сайт защищён от ботов, нажмите кнопку ниже, чтобы открыть его во встроенном поиске."
                toast("Ошибка: $msg")
            }
            statusMsg = ""
            busy = false
        }
    }

    fun addFromCurrentWebView() {
        val wv = webHolder[0]
        if (busy || wv == null || !currentUrl.startsWith("http")) return
        wv.evaluateJavascript("(function(){return document.documentElement.outerHTML;})()") { rawJson ->
            val html = try {
                if (rawJson != null && rawJson != "null") {
                    org.json.JSONTokener(rawJson).nextValue()?.toString()
                } else null
            } catch (e: Exception) {
                null
            }
            addFromUrl(currentUrl, preloadedHtml = html)
        }
    }

    LaunchedEffect(store.pendingSharedUrl) {
        val shared = store.pendingSharedUrl
        if (!shared.isNullOrBlank()) {
            store.pendingSharedUrl = null
            tab = 2
            link = shared
            addFromUrl(shared)
        }
    }

    fun searchCatalog(customQuery: String = catalogQuery, preferAi: Boolean = false) {
        val q = customQuery.trim()
        if (busy || q.isEmpty()) return
        catalogQuery = q
        catalogError = ""
        scope.launch {
            busy = true
            statusMsg = if (preferAi) "Ищу рецепты через ИИ…" else "Ищу рецепты в каталоге…"
            try {
                var found: List<ParsedRecipe> = emptyList()
                if (!preferAi) {
                    found = try {
                        withContext(Dispatchers.IO) { WebImport.searchMeals(q) }
                    } catch (e: Exception) {
                        emptyList()
                    }
                }
                if (found.isEmpty()) {
                    statusMsg = "Подбираю рецепты на русском через ИИ…"
                    found = withContext(Dispatchers.IO) { WebImport.searchCatalogWithAi(ctx, q) }
                }
                results = found
                searched = true
                if (found.isEmpty()) {
                    catalogError = "По запросу «$q» ничего не найдено. Попробуйте другое слово."
                }
            } catch (e: Exception) {
                catalogError = "Ошибка поиска: ${e.message ?: "проверьте интернет или настройки ИИ"}"
                searched = true
            }
            statusMsg = ""
            busy = false
        }
    }

    LaunchedEffect(tab) {
        if (tab == 1 && !searched && results.isEmpty() && !busy) {
            searchCatalog("курица")
        }
    }

    fun runWebSearch() {
        val q = query.trim()
        webHolder[0]?.loadUrl(
            "https://www.google.com/search?hl=ru&q=" + java.net.URLEncoder.encode(if (q.isEmpty()) "рецепты" else "рецепт $q", "UTF-8")
        )
    }

    BackHandler(enabled = tab == 0 && canBack) { webHolder[0]?.goBack() }
    DisposableEffect(Unit) { onDispose { webHolder[0]?.destroy() } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Рецепты из интернета") },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().imePadding()) {
            if (busy) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                if (statusMsg.isNotBlank()) {
                    Text(
                        statusMsg,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }
            }
            TabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.background) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("🔎 Поиск") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("📚 Каталог") })
                Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("🔗 Ссылка") })
            }

            if (tab == 0) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        query, { query = it },
                        placeholder = { Text("Например: борщ") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { runWebSearch() }),
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { runWebSearch() }) { Icon(Icons.Filled.Search, "Найти") }
                }
            }

            Box(if (tab == 0) Modifier.weight(1f).fillMaxWidth() else Modifier.size(0.dp)) {
                AndroidView(
                    factory = { c ->
                        android.webkit.WebView(c).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            webViewClient = object : android.webkit.WebViewClient() {
                                override fun onPageFinished(view: android.webkit.WebView?, url: String?) {
                                    currentUrl = url ?: ""
                                    canBack = view?.canGoBack() ?: false
                                }

                                override fun doUpdateVisitedHistory(view: android.webkit.WebView?, url: String?, isReload: Boolean) {
                                    currentUrl = url ?: ""
                                    canBack = view?.canGoBack() ?: false
                                }
                            }
                            webHolder[0] = this
                            loadUrl("https://www.google.com/search?hl=ru&q=" + java.net.URLEncoder.encode("рецепты", "UTF-8"))
                        }
                    },
                    update = { wv ->
                        wv.visibility = if (tab == 0) android.view.View.VISIBLE else android.view.View.GONE
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }

            if (tab == 0) {
                Button(
                    onClick = { addFromCurrentWebView() },
                    enabled = !busy && currentUrl.startsWith("http") && !currentUrl.contains("google."),
                    modifier = Modifier.fillMaxWidth().padding(12.dp).height(50.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Filled.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Добавить эту страницу в книгу")
                }
            }

            if (tab == 1) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        catalogQuery, { catalogQuery = it },
                        placeholder = { Text("Например: курица, борщ, паста…") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { searchCatalog() }),
                        trailingIcon = {
                            if (catalogQuery.isNotEmpty()) {
                                IconButton(onClick = { catalogQuery = "" }) { Icon(Icons.Filled.Close, "Очистить") }
                            }
                        },
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { searchCatalog() }, enabled = !busy && catalogQuery.isNotBlank()) {
                        Icon(Icons.Filled.Search, "Найти")
                    }
                }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    catalogChips.forEach { (label, qVal) ->
                        AssistChip(
                            onClick = { searchCatalog(qVal) },
                            enabled = !busy,
                            label = { Text(label) }
                        )
                    }
                }
                if (catalogError.isNotBlank()) {
                    Text(
                        catalogError,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }
                LazyColumn(
                    Modifier.weight(1f),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(results, key = { idx, p -> "${idx}_${p.title}" }) { _, p ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                        ) {
                            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (!p.imageUrl.isNullOrBlank()) {
                                    AsyncImage(
                                        model = p.imageUrl,
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.size(72.dp).clip(RoundedCornerShape(12.dp))
                                    )
                                } else {
                                    Box(
                                        Modifier
                                            .size(72.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(MaterialTheme.colorScheme.primaryContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(CATEGORIES.getOrNull(p.category)?.first ?: "🍽", fontSize = 28.sp)
                                    }
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(p.title, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    if (p.description.isNotBlank()) {
                                        Text(
                                            p.description,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                Spacer(Modifier.width(8.dp))
                                Button(
                                    onClick = { addParsed(p) },
                                    enabled = !busy,
                                    contentPadding = PaddingValues(horizontal = 12.dp)
                                ) {
                                    Text("В книгу")
                                }
                            }
                        }
                    }
                    if (searched && catalogQuery.isNotBlank() && !busy) {
                        item {
                            OutlinedButton(
                                onClick = { searchCatalog(catalogQuery, preferAi = true) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Filled.AutoAwesome, null, Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Подобрать ещё 3 рецепта на русском (ИИ)")
                            }
                        }
                    }
                }
            }

            if (tab == 2) {
                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        "Вставьте ссылку на страницу с рецептом — приложение заберёт название, продукты, шаги и фото.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        link,
                        { link = it; linkError = "" },
                        label = { Text("Ссылка на рецепт") },
                        placeholder = { Text("https://...") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = { addFromUrl(link) }),
                        trailingIcon = {
                            if (link.isNotEmpty()) {
                                IconButton(onClick = { link = ""; linkError = "" }) { Icon(Icons.Filled.Close, "Очистить") }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                val text = clip.getText()?.text?.trim() ?: ""
                                if (text.isNotEmpty()) {
                                    link = text
                                    linkError = ""
                                } else {
                                    toast("Буфер обмена пуст")
                                }
                            },
                            enabled = !busy,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.ContentPaste, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Вставить", maxLines = 1)
                        }
                        Button(
                            onClick = { addFromUrl(link) },
                            enabled = !busy && link.isNotBlank(),
                            modifier = Modifier.weight(1.4f),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Filled.Add, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Добавить в книгу", maxLines = 1)
                        }
                    }
                    if (linkError.isNotBlank()) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    linkError,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    style = MaterialTheme.typography.bodySmall
                                )
                                val cleanUrl = WebImport.extractUrl(link)
                                if (cleanUrl.isNotBlank()) {
                                    FilledTonalButton(
                                        onClick = {
                                            tab = 0
                                            webHolder[0]?.loadUrl(cleanUrl)
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("Открыть ссылку во встроенном поиске")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Added for HTML fetching
suspend fun fetchRecipeTextFromUrlHelper(url: String): String = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
    try {
        val html = WebImport.fetchHtml(url)
        val document = Jsoup.parse(html, url)
        document.select("script, style, nav, footer, aside").remove()
        return@withContext document.body().text()
    } catch (e: Exception) {
        return@withContext "Error: ${e.message}"
    }
}
