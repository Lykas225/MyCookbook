@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mycookbook.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

data class ScanPage(
    val id: String,
    val uri: Uri,
    val rotationDeg: Int = 0,
    val cropLeft: Float = 0f,
    val cropTop: Float = 0f,
    val cropRight: Float = 1f,
    val cropBottom: Float = 1f,
    val tempFile: File? = null
) {
    val isCropped: Boolean
        get() = cropLeft > 0.01f || cropTop > 0.01f || cropRight < 0.99f || cropBottom < 0.99f
}

@Composable
fun PageCropDialog(
    page: ScanPage,
    onApply: (ScanPage) -> Unit,
    onDismiss: () -> Unit
) {
    var rot by remember { mutableIntStateOf(page.rotationDeg) }
    var left by remember { mutableFloatStateOf(page.cropLeft) }
    var top by remember { mutableFloatStateOf(page.cropTop) }
    var right by remember { mutableFloatStateOf(page.cropRight) }
    var bottom by remember { mutableFloatStateOf(page.cropBottom) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("✂️ Обрезка и поворот") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "Обрежьте лишние поля, чтобы буквы стали крупнее — так рукописный и мелкий печатный текст читаются намного точнее.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black)
                ) {
                    AsyncImage(
                        model = page.uri,
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer { rotationZ = rot.toFloat() }
                    )
                    Canvas(Modifier.fillMaxSize()) {
                        val l = size.width * left
                        val t = size.height * top
                        val r = size.width * right
                        val b = size.height * bottom
                        val dim = Color(0x88000000)
                        drawRect(dim, Offset(0f, 0f), Size(size.width, t))
                        drawRect(dim, Offset(0f, b), Size(size.width, size.height - b))
                        drawRect(dim, Offset(0f, t), Size(l, b - t))
                        drawRect(dim, Offset(r, t), Size(size.width - r, b - t))
                        drawRect(
                            Color(0xFFFFD54F),
                            Offset(l, t),
                            Size((r - l).coerceAtLeast(1f), (b - t).coerceAtLeast(1f)),
                            style = Stroke(width = 3.dp.toPx())
                        )
                    }
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { rot = (rot + 90) % 360 },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Icon(Icons.Filled.RotateRight, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Повернуть 90°", fontSize = 12.sp, maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = { left = 0f; top = 0f; right = 1f; bottom = 1f; rot = 0 },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Text("Сбросить", fontSize = 12.sp, maxLines = 1)
                    }
                }

                Text("Сверху: ${(top * 100).toInt()}%  •  Снизу: ${((1f - bottom) * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
                Slider(value = top, onValueChange = { top = it.coerceAtMost(bottom - 0.15f) }, valueRange = 0f..0.8f)
                Slider(value = bottom, onValueChange = { bottom = it.coerceAtLeast(top + 0.15f) }, valueRange = 0.2f..1f)

                Text("Слева: ${(left * 100).toInt()}%  •  Справа: ${((1f - right) * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
                Slider(value = left, onValueChange = { left = it.coerceAtMost(right - 0.15f) }, valueRange = 0f..0.8f)
                Slider(value = right, onValueChange = { right = it.coerceAtLeast(left + 0.15f) }, valueRange = 0.2f..1f)
            }
        },
        confirmButton = {
            Button(onClick = {
                onApply(
                    page.copy(
                        rotationDeg = rot,
                        cropLeft = left,
                        cropTop = top,
                        cropRight = right,
                        cropBottom = bottom
                    )
                )
            }) {
                Text("Применить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}

@Composable
fun RecipeScannerScreen(store: CookbookStore, nav: NavHostController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    val prefs = remember { ctx.getSharedPreferences("cookbook_prefs", Context.MODE_PRIVATE) }

    var cfg by remember { mutableStateOf(AiProviders.load(prefs)) }
    var showSettings by remember { mutableStateOf(false) }

    val pages = remember { mutableStateListOf<ScanPage>() }
    var croppingIndex by remember { mutableStateOf<Int?>(null) }
    var pendingPhotoFile by remember { mutableStateOf<File?>(null) }

    var ocrMode by remember { mutableStateOf(OcrMode.HANDWRITING) }
    var enhanceInk by remember { mutableStateOf(true) }
    var attachOriginals by remember { mutableStateOf(false) }

    var recognizedText by remember { mutableStateOf("") }
    var lastEngineUsed by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var statusText by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf("") }

    val hasStrongKey = remember(cfg) { OcrEngine.hasStrongVisionKey(prefs) }

    DisposableEffect(Unit) {
        onDispose {
            pages.forEach { p ->
                val f = p.tempFile
                if (f != null && f.exists() && store.media.none { it.path == f.absolutePath }) {
                    f.delete()
                }
            }
        }
    }

    suspend fun recognizePageList(
        targetPages: List<ScanPage>,
        append: Boolean,
        forceEngine: String? = null
    ): OcrResult? {
        if (targetPages.isEmpty()) return null
        cfg = AiProviders.load(prefs)
        val collected = ArrayList<String>()
        var engineName = ""

        for ((idx, page) in targetPages.withIndex()) {
            val modeLabel = when (forceEngine) {
                "ocr_space" -> "через OCR.space (печатный)"
                "vision" -> "через Vision ИИ (рукопись)"
                else -> if (ocrMode == OcrMode.HANDWRITING) "рукописный текст" else "печатный текст"
            }
            statusText = if (targetPages.size > 1) {
                "Распознаю $modeLabel: стр. ${idx + 1} из ${targetPages.size}…"
            } else {
                "Распознаю $modeLabel…"
            }
            val spec = OcrPageSpec(
                uri = page.uri,
                rotationDeg = page.rotationDeg,
                cropLeft = page.cropLeft,
                cropTop = page.cropTop,
                cropRight = page.cropRight,
                cropBottom = page.cropBottom,
                enhanceInk = enhanceInk
            )
            val res = withContext(Dispatchers.IO) {
                OcrEngine.recognizePage(ctx, prefs, spec, ocrMode, forceEngine)
            }
            if (res.text.isNotBlank()) {
                collected.add(res.text)
                engineName = res.engineName
            }
        }

        if (collected.isEmpty()) return null
        val joined = collected.joinToString("\n\n")
        recognizedText = if (append && recognizedText.isNotBlank()) {
            recognizedText.trimEnd() + "\n\n" + joined
        } else {
            joined
        }
        lastEngineUsed = engineName
        return OcrResult(recognizedText, engineName)
    }

    fun runOcr(targetPages: List<ScanPage>, append: Boolean, forceEngine: String? = null) {
        if (busy || targetPages.isEmpty()) return
        errorText = ""
        scope.launch {
            busy = true
            try {
                val res = recognizePageList(targetPages, append, forceEngine)
                if (res == null || res.text.isBlank()) {
                    errorText = "Не удалось прочитать текст на фото. Попробуйте обрезать лишние поля, повернуть снимок или переключить режим (Рукописный / Печатный)."
                } else {
                    Toast.makeText(ctx, "Распознано (${res.engineName})! Проверьте текст.", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                val msg = e.message ?: "нет связи"
                errorText = "Ошибка распознавания: $msg. Попробуйте нажать «Другой движок» или добавьте бесплатный ключ Mistral AI в ⚙️."
            }
            statusText = ""
            busy = false
        }
    }

    val takePictureLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = pendingPhotoFile
        pendingPhotoFile = null
        if (f != null) {
            if (ok && f.exists() && f.length() > 0) {
                val newPage = ScanPage(UUID.randomUUID().toString(), Uri.fromFile(f), tempFile = f)
                pages.add(newPage)
                runOcr(listOf(newPage), append = pages.size > 1)
            } else {
                f.delete()
            }
        }
    }

    fun launchCamera() {
        try {
            val f = MediaFiles.newFile(ctx, false)
            pendingPhotoFile = f
            takePictureLauncher.launch(MediaFiles.uriFor(ctx, f))
        } catch (e: Exception) {
            Toast.makeText(ctx, "Не удалось открыть камеру", Toast.LENGTH_SHORT).show()
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) launchCamera()
        else Toast.makeText(ctx, "Нужен доступ к камере для съёмки рецепта", Toast.LENGTH_SHORT).show()
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        if (uris.isNotEmpty()) {
            val added = uris.map { ScanPage(UUID.randomUUID().toString(), it) }
            val hadBefore = pages.isNotEmpty()
            pages.addAll(added)
            runOcr(added, append = hadBefore)
        }
    }

    val dictateLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val spoken = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.trim()
            if (!spoken.isNullOrBlank()) {
                recognizedText = if (recognizedText.isBlank()) spoken else recognizedText.trimEnd() + "\n" + spoken
            }
        }
    }

    fun startDictation() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Продиктуйте рецепт или правку…")
            }
            dictateLauncher.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(ctx, "Голосовой ввод недоступен на устройстве", Toast.LENGTH_SHORT).show()
        }
    }

    suspend fun collectAttachedPhotos(): List<String> {
        val out = ArrayList<String>()
        if (!attachOriginals || pages.isEmpty()) return out
        statusText = "Прикрепляю фото оригинала…"
        for (p in pages) {
            val existingTemp = p.tempFile
            if (existingTemp != null && existingTemp.exists()) {
                out.add(existingTemp.absolutePath)
            } else {
                val copied = withContext(Dispatchers.IO) { MediaFiles.copyFrom(ctx, p.uri, false) }
                if (copied != null) out.add(copied)
            }
        }
        return out
    }

    fun saveRecipe(useAiStructuring: Boolean) {
        if (busy) return
        if (recognizedText.isBlank() && pages.isEmpty()) {
            Toast.makeText(ctx, "Сфотографируйте рецепт, надиктуйте или вставьте текст", Toast.LENGTH_SHORT).show()
            return
        }
        errorText = ""
        scope.launch {
            busy = true
            try {
                var sourceText = recognizedText.trim()
                if (sourceText.isEmpty() && pages.isNotEmpty()) {
                    sourceText = recognizePageList(pages.toList(), append = false)?.text?.trim() ?: ""
                }
                if (sourceText.isEmpty()) {
                    errorText = "Не удалось извлечь текст с фото. Попробуйте обрезать фото или нажать «Другой движок»."
                    statusText = ""
                    busy = false
                    return@launch
                }

                val srcLabel = if (ocrMode == OcrMode.HANDWRITING) "Оцифрован (рукопись)" else "Оцифрован с фото"
                var parsed: ParsedRecipe? = null

                if (useAiStructuring) {
                    statusText = "Раскладываю на ингредиенты, граммовки и шаги…"
                    try {
                        val raw = withContext(Dispatchers.IO) {
                            AiClient.chatCfgSmart(
                                prefs = prefs,
                                system = AiClient.recipeJsonSystem(),
                                msgs = listOf("user" to sourceText),
                                maxTokens = 4096,
                                json = true
                            )
                        }
                        parsed = AiClient.parseRecipeJson(raw)
                    } catch (e: Exception) {
                        // Автоматический безопасный переход на локальный парсер, чтобы рецепт не пропал
                        parsed = null
                    }
                }

                val usedLocalFallback = parsed == null
                val finalParsed = (parsed ?: OcrEngine.parseRecipeTextLocally(sourceText, srcLabel))
                    .copy(sourceUrl = srcLabel)

                val mediaPaths = collectAttachedPhotos()
                val id = WebImport.addToBook(ctx, store, finalParsed, extraMediaPaths = mediaPaths)
                Toast.makeText(
                    ctx,
                    if (usedLocalFallback && useAiStructuring) "Рецепт «${finalParsed.title}» сохранён (быстрый разбор — можно поправить в редакторе)"
                    else "Рецепт «${finalParsed.title}» сохранён!",
                    Toast.LENGTH_LONG
                ).show()
                nav.navigate("recipe/$id")
            } catch (e: Exception) {
                errorText = "Ошибка сохранения: ${e.message ?: "не удалось сохранить"}"
            }
            statusText = ""
            busy = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Оцифровка рецепта") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад")
                    }
                },
                actions = {
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Filled.Settings, "Настройки ИИ")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(
            modifier = Modifier
                .padding(pad)
                .fillMaxSize()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (busy) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                if (statusText.isNotBlank()) {
                    Text(
                        statusText,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Выбор типа исходника: Рукописный vs Печатный
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    "Что оцифровываем?",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = ocrMode == OcrMode.HANDWRITING,
                        onClick = {
                            ocrMode = OcrMode.HANDWRITING
                            enhanceInk = true
                        },
                        enabled = !busy,
                        label = { Text("✍️ Рукописный почерк") }
                    )
                    FilterChip(
                        selected = ocrMode == OcrMode.PRINTED,
                        onClick = { ocrMode = OcrMode.PRINTED },
                        enabled = !busy,
                        label = { Text("📖 Печатный / книга") }
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FilterChip(
                        selected = enhanceInk,
                        onClick = { enhanceInk = !enhanceInk },
                        enabled = !busy,
                        leadingIcon = { Icon(Icons.Filled.Tune, null, Modifier.size(16.dp)) },
                        label = { Text(if (enhanceInk) "Усилить контраст чернил ✓" else "Усилить контраст чернил", fontSize = 12.sp) }
                    )
                }
            }

            if (ocrMode == OcrMode.HANDWRITING && !hasStrongKey) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("💡", fontSize = 18.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Печатный текст читается точно без ключа. Для сложного рукописного почерка без VPN рекомендуем добавить бесплатный ключ Mistral AI (console.mistral.ai) в настройках ⚙️ сверху.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Кнопки съёмки и выбора фото (поддержка нескольких страниц)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                        if (granted) launchCamera()
                        else permissionLauncher.launch(Manifest.permission.CAMERA)
                    },
                    enabled = !busy,
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp)
                ) {
                    Icon(Icons.Filled.CameraAlt, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (pages.isEmpty()) "Сфотографировать" else "+ Ещё страница", fontSize = 13.sp, maxLines = 1)
                }
                FilledTonalButton(
                    onClick = { galleryLauncher.launch("image/*") },
                    enabled = !busy,
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp)
                ) {
                    Icon(Icons.Filled.PhotoLibrary, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Из галереи", fontSize = 13.sp, maxLines = 1)
                }
            }

            // Лента добавленных страниц с обрезкой, поворотом и сменой движка
            if (pages.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Страницы (${pages.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(
                        onClick = { runOcr(pages.toList(), append = false) },
                        enabled = !busy,
                        contentPadding = PaddingValues(horizontal = 6.dp)
                    ) {
                        Icon(Icons.Filled.Refresh, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Заново", fontSize = 12.sp)
                    }
                    TextButton(
                        onClick = {
                            val alt = if (lastEngineUsed.contains("OCR.space", ignoreCase = true)) "vision" else "ocr_space"
                            runOcr(pages.toList(), append = false, forceEngine = alt)
                        },
                        enabled = !busy,
                        contentPadding = PaddingValues(horizontal = 6.dp)
                    ) {
                        Icon(Icons.Filled.SwapHoriz, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Другой движок", fontSize = 12.sp)
                    }
                }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    pages.forEachIndexed { idx, page ->
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                            modifier = Modifier.width(136.dp)
                        ) {
                            Column {
                                Box(
                                    Modifier
                                        .fillMaxWidth()
                                        .height(132.dp)
                                        .clickable(enabled = !busy) { croppingIndex = idx }
                                ) {
                                    AsyncImage(
                                        model = page.uri,
                                        contentDescription = "Страница ${idx + 1}",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .graphicsLayer { rotationZ = page.rotationDeg.toFloat() }
                                    )
                                    Text(
                                        if (page.isCropped) "Стр. ${idx + 1} ✂️" else "Стр. ${idx + 1}",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier
                                            .align(Alignment.TopStart)
                                            .padding(6.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0x99000000))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                    IconButton(
                                        onClick = {
                                            page.tempFile?.let { if (it.exists()) it.delete() }
                                            pages.removeAt(idx)
                                        },
                                        enabled = !busy,
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(4.dp)
                                            .size(26.dp)
                                            .background(Color(0x99000000), CircleShape)
                                    ) {
                                        Icon(Icons.Filled.Close, "Удалить", tint = Color.White, modifier = Modifier.size(15.dp))
                                    }
                                }
                                Row(
                                    Modifier.fillMaxWidth().padding(horizontal = 2.dp),
                                    horizontalArrangement = Arrangement.SpaceEvenly,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(
                                        onClick = { croppingIndex = idx },
                                        enabled = !busy,
                                        modifier = Modifier.size(34.dp)
                                    ) {
                                        Icon(Icons.Filled.Crop, "Обрезать", modifier = Modifier.size(18.dp))
                                    }
                                    IconButton(
                                        onClick = {
                                            pages[idx] = page.copy(rotationDeg = (page.rotationDeg + 90) % 360)
                                        },
                                        enabled = !busy,
                                        modifier = Modifier.size(34.dp)
                                    ) {
                                        Icon(Icons.Filled.RotateRight, "Повернуть", modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Показываем, какой движок распознал текст
            if (lastEngineUsed.isNotBlank() && recognizedText.isNotBlank()) {
                Text(
                    "✅ Распознано: $lastEngineUsed",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // Ошибка с кнопками повтора / смены движка
            if (errorText.isNotBlank()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(errorText, color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodySmall)
                        if (pages.isNotEmpty()) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilledTonalButton(
                                    onClick = { runOcr(pages.toList(), append = false, forceEngine = "ocr_space") },
                                    enabled = !busy,
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 8.dp)
                                ) {
                                    Text("OCR.space", fontSize = 12.sp, maxLines = 1)
                                }
                                FilledTonalButton(
                                    onClick = { runOcr(pages.toList(), append = false, forceEngine = "vision") },
                                    enabled = !busy,
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 8.dp)
                                ) {
                                    Text("Vision ИИ", fontSize = 12.sp, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }

            // Быстрые инструменты текста: надиктовать голосом или вставить из буфера
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Текст рецепта",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                OutlinedButton(
                    onClick = { startDictation() },
                    enabled = !busy,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Filled.Mic, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Надиктовать", fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = {
                        val txt = clip.getText()?.text?.trim().orEmpty()
                        if (txt.isNotEmpty()) {
                            recognizedText = if (recognizedText.isBlank()) txt else recognizedText.trimEnd() + "\n" + txt
                        } else {
                            Toast.makeText(ctx, "Буфер обмена пуст", Toast.LENGTH_SHORT).show()
                        }
                    },
                    enabled = !busy,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Filled.ContentPaste, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Вставить", fontSize = 12.sp)
                }
            }

            OutlinedTextField(
                value = recognizedText,
                onValueChange = { recognizedText = it },
                placeholder = { Text("Здесь появится распознанный текст — можно сразу поправить цифры или слова") },
                trailingIcon = {
                    if (recognizedText.isNotEmpty() && !busy) {
                        IconButton(onClick = { recognizedText = ""; lastEngineUsed = "" }) {
                            Icon(Icons.Filled.Close, "Очистить")
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                minLines = 7,
                maxLines = 18,
                shape = RoundedCornerShape(14.dp)
            )

            if (pages.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = attachOriginals,
                        onCheckedChange = { attachOriginals = it },
                        enabled = !busy
                    )
                    Text(
                        "Прикрепить фото оригинала записи к рецепту",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            Button(
                onClick = { saveRecipe(useAiStructuring = true) },
                enabled = (recognizedText.isNotBlank() || pages.isNotEmpty()) && !busy,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Filled.AutoAwesome, null)
                Spacer(Modifier.width(8.dp))
                Text(
                    when {
                        busy -> "Обрабатываю…"
                        recognizedText.isBlank() && pages.isNotEmpty() -> "Распознать и сохранить в книгу"
                        else -> "Оформить и сохранить в книгу"
                    },
                    fontSize = 16.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (recognizedText.isNotBlank()) {
                OutlinedButton(
                    onClick = { saveRecipe(useAiStructuring = false) },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(46.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Filled.Check, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Сохранить сразу без ИИ (быстро)")
                }
            }

            Spacer(Modifier.height(16.dp))
        }
    }

    val cropIdx = croppingIndex
    if (cropIdx != null && cropIdx in pages.indices) {
        PageCropDialog(
            page = pages[cropIdx],
            onApply = { updated ->
                pages[cropIdx] = updated
                croppingIndex = null
                runOcr(pages.toList(), append = false)
            },
            onDismiss = { croppingIndex = null }
        )
    }

    if (showSettings) {
        AiSettingsDialog(
            cfg = cfg,
            onSave = {
                cfg = it
                AiProviders.save(prefs, it)
                showSettings = false
            },
            onDismiss = { showSettings = false }
        )
    }
}
