@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mycookbook.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun RecipeScannerScreen(store: CookbookStore, nav: NavHostController) {
    val ctx = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("cookbook_prefs", Context.MODE_PRIVATE) }

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    var cameraActive by remember { mutableStateOf(false) }
    var liveText by remember { mutableStateOf("") }
    var recognizedText by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
        if (granted) cameraActive = true
        else Toast.makeText(ctx, "Нужен доступ к камере для сканирования", Toast.LENGTH_SHORT).show()
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            try {
                val image = InputImage.fromFilePath(ctx, uri)
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                recognizer.process(image)
                    .addOnSuccessListener { visionText ->
                        if (visionText.text.isNotBlank()) {
                            recognizedText = visionText.text
                            Toast.makeText(ctx, "Текст распознан", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(ctx, "Текст на фото не найден", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .addOnFailureListener {
                        Toast.makeText(ctx, "Ошибка распознавания фото", Toast.LENGTH_SHORT).show()
                    }
            } catch (e: Exception) {
                Toast.makeText(ctx, "Не удалось открыть фото", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun saveWithAi() {
        val rawText = recognizedText.trim()
        if (busy || rawText.isEmpty()) return
        scope.launch {
            busy = true
            try {
                val cfg = AiProviders.load(prefs)
                val raw = withContext(Dispatchers.IO) {
                    AiClient.chatCfg(cfg, AiClient.recipeJsonSystem(), listOf("user" to rawText), 4096, true)
                }
                val parsed = AiClient.parseRecipeJson(raw)
                if (parsed == null) {
                    Toast.makeText(ctx, "Не удалось разобрать рецепт. Проверьте текст.", Toast.LENGTH_LONG).show()
                } else {
                    val id = WebImport.addToBook(ctx, store, parsed.copy(sourceUrl = "Оцифрованный рецепт"))
                    Toast.makeText(ctx, "Рецепт «${parsed.title}» сохранён!", Toast.LENGTH_SHORT).show()
                    nav.navigate("recipe/$id")
                }
            } catch (e: Exception) {
                Toast.makeText(ctx, "Ошибка ИИ: ${e.message ?: "нет связи"}", Toast.LENGTH_LONG).show()
            }
            busy = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Оцифровка рецепта") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(
            modifier = Modifier
                .padding(pad)
                .fillMaxSize()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())

            Text(
                "Отсканируйте рецепт камерой, выберите фото из галереи или вставьте текст — ИИ разложит его на ингредиенты и шаги.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(
                    onClick = {
                        if (hasCameraPermission) cameraActive = !cameraActive
                        else permissionLauncher.launch(Manifest.permission.CAMERA)
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.CameraAlt, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (cameraActive) "Выкл. камеру" else "Камера", maxLines = 1)
                }
                FilledTonalButton(
                    onClick = { galleryLauncher.launch("image/*") },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.PhotoLibrary, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Из галереи", maxLines = 1)
                }
            }

            if (cameraActive && hasCameraPermission) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .clip(RoundedCornerShape(16.dp))
                ) {
                    val cameraProviderFuture = remember { ProcessCameraProvider.getInstance(ctx) }
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { c ->
                            val previewView = PreviewView(c)
                            val executor = ContextCompat.getMainExecutor(c)
                            cameraProviderFuture.addListener({
                                val cameraProvider = cameraProviderFuture.get()
                                val preview = Preview.Builder().build().also {
                                    it.setSurfaceProvider(previewView.surfaceProvider)
                                }
                                val imageAnalyzer = ImageAnalysis.Builder()
                                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                    .build()
                                    .also {
                                        it.setAnalyzer(executor, TextAnalyzer { found -> liveText = found })
                                    }
                                try {
                                    cameraProvider.unbindAll()
                                    cameraProvider.bindToLifecycle(
                                        lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageAnalyzer
                                    )
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }, executor)
                            previewView
                        }
                    )
                    Button(
                        onClick = {
                            if (liveText.isNotBlank()) {
                                recognizedText = liveText
                                cameraActive = false
                                Toast.makeText(ctx, "Текст захвачен", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(ctx, "Наведите камеру на текст рецепта", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("Захватить текст")
                    }
                }
            }

            OutlinedTextField(
                value = recognizedText,
                onValueChange = { recognizedText = it },
                label = { Text("Текст рецепта (можно поправить вручную)") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 6,
                maxLines = 14,
                shape = RoundedCornerShape(14.dp)
            )

            Button(
                onClick = { saveWithAi() },
                enabled = recognizedText.isNotBlank() && !busy,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Filled.AutoAwesome, null)
                Spacer(Modifier.width(8.dp))
                Text(if (busy) "Оформляю рецепт…" else "Оформить и сохранить в книгу", fontSize = 16.sp)
            }
        }
    }
}

class TextAnalyzer(private val onTextFound: (String) -> Unit) : ImageAnalysis.Analyzer {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    @androidx.annotation.OptIn(androidx.camera.core.ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage != null) {
            val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    if (visionText.text.isNotBlank()) {
                        onTextFound(visionText.text)
                    }
                }
                .addOnCompleteListener {
                    imageProxy.close()
                }
        } else {
            imageProxy.close()
        }
    }
}
