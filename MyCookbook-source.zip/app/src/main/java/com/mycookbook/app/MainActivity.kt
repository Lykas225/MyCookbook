@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

import androidx.compose.foundation.Canvas
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.ContentDrawScope
import androidx.compose.animation.core.tween
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size


/** Стол, кожаная обложка и стопка страниц справа. */
private fun DrawScope.drawBook(dark: Boolean) {
    val w = size.width
    val h = size.height
    val top = if (dark) Color(0xFF2A1A10) else Color(0xFF6E3F25)
    val bottom = if (dark) Color(0xFF170D07) else Color(0xFF4A2616)
    drawRect(Brush.verticalGradient(listOf(top, bottom)))
    val left = 10.dp.toPx()
    val step = 2.dp.toPx()
    for (i in 4 downTo 0) {
        val right = w - 16.dp.toPx() + (i + 1) * step
        val c = if (i % 2 == 0) Color(0xFFEADFC4) else Color(0xFFD3C4A0)
        drawRect(c, Offset(left, 0f), Size(right - left, h))
        drawLine(Color(0x44000000), Offset(right, 0f), Offset(right, h), 1f)
    }
    drawRect(
        Brush.horizontalGradient(listOf(Color(0x77000000), Color.Transparent), 0f, left),
        Offset(0f, 0f), Size(left, h)
    )
    val dash = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))
    drawLine(Color(0xAAF0CF85), Offset(4.dp.toPx(), 0f), Offset(4.dp.toPx(), h), 1.5f, pathEffect = dash)
    drawLine(Color(0x88F0CF85), Offset(w - 3.dp.toPx(), 0f), Offset(w - 3.dp.toPx(), h), 1.5f, pathEffect = dash)
}

/** Линовка и тень от корешка на самой странице. */
private fun DrawScope.drawPageDecor(lineColor: Color) {
    val step = 26.dp.toPx()
    var yy = step
    while (yy < size.height) {
        drawLine(lineColor, Offset(0f, yy), Offset(size.width, yy), 1f)
        yy += step
    }
    drawRect(
        Brush.horizontalGradient(listOf(Color(0x55000000), Color.Transparent), 0f, 22.dp.toPx()),
        Offset(0f, 0f), Size(22.dp.toPx(), size.height)
    )
}

/** Загибающийся лист: правая часть отгибается назад вокруг линии сгиба. */
private fun ContentDrawScope.drawCurl(p: Float, under: Color, back: Color, lineColor: Color) {
    val w = size.width
    val h = size.height
    val xf = w * (1f - p)
    // следующий лист под загибом
    drawRect(under, Offset(xf, 0f), Size(w - xf, h))
    val shadowW = 36.dp.toPx()
    drawRect(
        Brush.horizontalGradient(listOf(Color(0x66000000), Color.Transparent), xf, xf + shadowW),
        Offset(xf, 0f), Size(minOf(shadowW, w - xf), h)
    )
    if (xf <= 0f) return
    // ещё не перевёрнутая часть страницы
    clipRect(0f, 0f, xf, h) {
        this@drawCurl.drawContent()
        drawPageDecor(lineColor)
    }
    // тень от поднятого листа
    val castW = minOf(48.dp.toPx(), xf)
    drawRect(
        Brush.horizontalGradient(listOf(Color.Transparent, Color(0x66000000)), xf - castW, xf),
        Offset(xf - castW, 0f), Size(castW, h)
    )
    // обратная сторона загнутого листа
    val free = 2f * xf - w
    val l = maxOf(0f, free)
    drawRect(back, Offset(l, 0f), Size(xf - l, h))
    drawRect(
        Brush.horizontalGradient(
            0f to Color(0x77000000), 0.18f to Color(0x11000000), 0.65f to Color(0x22FFFFFF), 1f to Color(0x55000000),
            startX = free, endX = xf
        ),
        Offset(l, 0f), Size(xf - l, h)
    )
    // «цилиндр» у самого сгиба
    val bendW = minOf(26.dp.toPx(), xf - l)
    drawRect(
        Brush.horizontalGradient(listOf(Color(0x00FFFFFF), Color(0x66FFFFFF), Color(0x33000000)), xf - bendW, xf),
        Offset(xf - bendW, 0f), Size(bendW, h)
    )
    if (free > 0f) {
        drawLine(Color(0xAAFFFFFF), Offset(free, 0f), Offset(free, h), 2f)
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val crash = File(filesDir, "crash.txt")
        val initial = try {
            if (crash.exists()) crash.readText() else null
        } catch (e: Exception) {
            null
        }
        setContent {
            var report by remember { mutableStateOf(initial) }
            val r = report
            if (r != null) {
                CrashScreen(r) {
                    crash.delete()
                    report = null
                }
            } else {
                CookbookRoot()
            }
        }
    }
}

@Composable
fun CrashScreen(text: String, onContinue: () -> Unit) {
    val clip = LocalClipboardManager.current
    MaterialTheme {
        Column(
            Modifier.fillMaxSize().background(Color.White).statusBarsPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("В прошлый раз приложение закрылось с ошибкой", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Нажмите «Скопировать» и отправьте текст разработчику или сделайте скриншот.", color = Color.DarkGray)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { clip.setText(androidx.compose.ui.text.AnnotatedString(text)) }) { Text("Скопировать") }
                OutlinedButton(onClick = onContinue) { Text("Продолжить") }
            }
            Box(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                Text(text, color = Color.Black, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun CookbookRoot() {
    val vm: MainVm = viewModel()
    val store = vm.store
    CookbookTheme(store.wallpaper) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            MainScaffold(store, vm.timer)
        }
    }
}

@Composable
fun MainScaffold(store: CookbookStore, timer: TimerState) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route ?: "home"
    val dark = store.wallpaper == 0
    val scope = rememberCoroutineScope()
    val curl = remember { Animatable(0f) }
    var flipping by remember { mutableStateOf(false) }

    val tabs = listOf(
        Triple("home", "Главная", Icons.Filled.Home),
        Triple("recipes?cat=-1", "Рецепты", Icons.Filled.MenuBook),
        Triple("plan", "План", Icons.Filled.CalendarMonth),
        Triple("archive?tab=0", "Архив", Icons.Filled.PhotoLibrary),
        Triple("tools", "Ещё", Icons.Filled.Apps)
    )
    val ctx = LocalContext.current
    val activity = ctx as ComponentActivity
    var found by remember { mutableStateOf<UpdateInfo?>(null) }
    var dismissed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        found = withContext(Dispatchers.IO) {
            try {
                Updater.check(ctx)
            } catch (e: Exception) {
                null
            }
        }
    }
    val showBar = tabs.any { route.startsWith(it.first.substringBefore('?')) }

    val lightStatusIcons = dark || route.startsWith("home")
    val lightNavIcons = dark || showBar
    DisposableEffect(lightStatusIcons, lightNavIcons) {
        val statusStyle = if (lightStatusIcons) {
            SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        } else {
            SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
        }
        val navStyle = if (lightNavIcons) {
            SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        } else {
            SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
        }
        activity.enableEdgeToEdge(statusBarStyle = statusStyle, navigationBarStyle = navStyle)
        onDispose { }
    }

    // Листание: страница отгибается и уходит, потом ложится новая
    fun goTab(r: String) {
        if (flipping) return
        if (route.startsWith(r.substringBefore('?'))) return
        scope.launch {
            flipping = true
            curl.snapTo(0f)
            curl.animateTo(1f, tween(480, easing = FastOutSlowInEasing))
            nav.navigate(r) {
                popUpTo("home")
                launchSingleTop = true
            }
            curl.animateTo(0f, tween(480, easing = FastOutSlowInEasing))
            flipping = false
        }
    }

    val leather = if (dark) Color(0xFF1F130C) else Color(0xFF5B3420)
    val gold = Color(0xFFF0CF85)
    val creamDim = Color(0xCCEBDDBF)

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (showBar) {
                NavigationBar(containerColor = leather) {
                    tabs.forEach { (r, label, icon) ->
                        val base = r.substringBefore('?')
                        NavigationBarItem(
                            selected = route.startsWith(base),
                            onClick = { goTab(r) },
                            icon = { Icon(icon, label) },
                            label = { Text(label, maxLines = 1, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = gold,
                                selectedTextColor = gold,
                                unselectedIconColor = creamDim,
                                unselectedTextColor = creamDim,
                                indicatorColor = Color(0x33FFFFFF)
                            )
                        )
                    }
                }
            }
        }
    ) { pad ->
        val upd = found
        if (upd != null && !dismissed) {
            AlertDialog(
                onDismissRequest = { dismissed = true },
                title = { Text("Доступно обновление") },
                text = { Text("Вышла новая версия приложения (${upd.code}). Установить сейчас?") },
                confirmButton = {
                    TextButton(onClick = { dismissed = true; nav.navigate("update") }) { Text("Обновить") }
                },
                dismissButton = { TextButton(onClick = { dismissed = true }) { Text("Позже") } }
            )
        }
        val pageColor = MaterialTheme.colorScheme.background
        val under = Color(0x33000000).compositeOver(pageColor)
        val back = if (dark) Color(0xFF3C2A1D) else Color(0xFFF1E5C9)
        val lineColor = if (dark) Color(0x0DFFFFFF) else Color(0x125A3A1F)
        val density = LocalDensity.current

        BoxWithConstraints(Modifier.fillMaxSize()) {
            val w = constraints.maxWidth.toFloat()
            val h = constraints.maxHeight.toFloat()
            val sideStart = with(density) { 10.dp.toPx() }
            val pageW = w - with(density) { 26.dp.toPx() }

            Canvas(Modifier.fillMaxSize()) { drawBook(dark) }

            Box(Modifier.fillMaxSize().padding(start = 10.dp, end = 16.dp)) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .drawWithContent {
                            val p = curl.value
                            if (p <= 0.001f) {
                                drawContent()
                                drawPageDecor(lineColor)
                            } else {
                                drawCurl(p, under, back, lineColor)
                            }
                        }
                        .background(pageColor)
                ) {
                    NavHost(
                        navController = nav,
                        startDestination = "home",
                        modifier = Modifier.padding(bottom = pad.calculateBottomPadding())
                    ) {
                        composable("home") { HomeScreen(store, nav) }
                        composable(
                            "recipes?cat={cat}",
                            arguments = listOf(navArgument("cat") { type = NavType.IntType; defaultValue = -1 })
                        ) { e -> RecipesScreen(store, nav, e.arguments?.getInt("cat") ?: -1) }
                        composable("plan") { PlanScreen(store, nav) }
                        composable(
                            "archive?tab={tab}",
                            arguments = listOf(navArgument("tab") { type = NavType.IntType; defaultValue = 0 })
                        ) { e -> ArchiveScreen(store, e.arguments?.getInt("tab") ?: 0) }
                        composable("tools") { ToolsScreen(nav) }
                        composable("recipe/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                            DetailScreen(store, e.arguments?.getString("id") ?: "", nav)
                        }
                        composable("edit/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                            EditorScreen(store, e.arguments?.getString("id") ?: "new", nav)
                        }
                        composable("cook/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                            CookScreen(store, timer, e.arguments?.getString("id") ?: "", nav)
                        }
                        composable("timer") { TimerScreen(timer, nav) }
                        composable("calc") { CalcScreen(store, nav) }
                        composable("web") { WebScreen(store, nav) }
                        composable("update") { UpdateScreen(nav) }
                        composable("backup") { BackupScreen(store, nav) }
                    composable("shopping") { ShoppingScreen(store, nav) }
                        composable("ai") { AiScreen(store, nav, "") }
                        composable("ai/{rid}", arguments = listOf(navArgument("rid") { type = NavType.StringType })) { e ->
                            AiScreen(store, nav, e.arguments?.getString("rid") ?: "")
                        }
                    }

                    if (timer.active && !route.startsWith("cook") && !route.startsWith("timer")) {
                        Row(
                            Modifier
                                .align(Alignment.BottomStart)
                                .padding(start = 12.dp, bottom = 12.dp + pad.calculateBottomPadding())
                                .clip(RoundedCornerShape(24.dp))
                                .background(if (timer.finished) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                                .clickable { nav.navigate("timer") }
                                .padding(start = 12.dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Timer, null, tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(
                                if (timer.finished) "Время вышло!" else formatClock(timer.remainingSec),
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(onClick = { timer.dismiss() }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Filled.Close, "Остановить", tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }

            val hideChef = flipping || route.startsWith("ai") || route.startsWith("edit") ||
                route.startsWith("web") || route.startsWith("cook")
            if (!hideChef) {
                val bottomPx = with(density) { pad.calculateBottomPadding().toPx() }
                DraggableChef(w, h - bottomPx) { nav.navigate("ai") }
            }

            // помощник тянет страницу за свободный край
            if (flipping) {
                val xf = pageW * (1f - curl.value)
                val edge = maxOf(0f, 2f * xf - pageW)
                val ratW = with(density) { 90.dp.toPx() }
                val ratH = with(density) { 140.dp.toPx() }
                ChefMascot(
                    Modifier
                        .offset { IntOffset((sideStart + edge - ratW * 0.85f).toInt(), (h * 0.45f - ratH / 2f).toInt()) }
                        .size(width = 90.dp, height = 140.dp),
                    ChefAction.PULL,
                    curl.value * 8f,
                    false
                )
            }
        }
    }
}
