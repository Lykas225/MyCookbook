@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CookbookRoot() }
    }
}

@Composable
fun CookbookRoot() {
    val vm: MainVm = viewModel()
    val store = vm.store
    val dark = store.wallpaper == 0
    val activity = LocalContext.current as ComponentActivity
    DisposableEffect(dark) {
        val style = if (dark) {
            SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        } else {
            SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
        }
        activity.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
        onDispose { }
    }
    CookbookTheme(store.wallpaper) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            MainScaffold(store, vm.timer)
        }
    }
}

@Composable
fun MainScaffold(store: CookbookStore, timer: TimerState) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route ?: "home"

    val tabs = listOf(
        Triple("home", "Главная", Icons.Filled.Home),
        Triple("recipes?cat=-1", "Рецепты", Icons.Filled.MenuBook),
        Triple("plan", "План", Icons.Filled.CalendarMonth),
        Triple("archive?tab=0", "Архив", Icons.Filled.PhotoLibrary),
        Triple("tools", "Ещё", Icons.Filled.Apps)
    )
    val showBar = tabs.any { route.startsWith(it.first.substringBefore('?')) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (showBar) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    tabs.forEach { (r, label, icon) ->
                        val base = r.substringBefore('?')
                        NavigationBarItem(
                            selected = route.startsWith(base),
                            onClick = {
                                nav.navigate(r) {
                                    popUpTo("home")
                                    launchSingleTop = true
                                }
                            },
                            icon = { Icon(icon, label) },
                            label = { Text(label, maxLines = 1, fontSize = 11.sp) }
                        )
                    }
                }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize()) {
            NavHost(
                navController = nav,
                startDestination = "home",
                modifier = Modifier.padding(bottom = pad.calculateBottomPadding())
            ) {
                composable("home") { HomeScreen(store, nav) }
                composable(
                    "recipes?cat={cat}",
                    arguments = listOf(navArgument("cat") { type = NavType.IntType; defaultValue = -1 })
                ) { e -> RecipesScreen(store, nav, e.arguments?.getInt("cat") ?: -1) }
                composable("plan") { PlanScreen(store, nav) }
                composable(
                    "archive?tab={tab}",
                    arguments = listOf(navArgument("tab") { type = NavType.IntType; defaultValue = 0 })
                ) { e -> ArchiveScreen(store, e.arguments?.getInt("tab") ?: 0) }
                composable("tools") { ToolsScreen(nav) }
                composable("recipe/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                    DetailScreen(store, e.arguments?.getString("id") ?: "", nav)
                }
                composable("edit/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                    EditorScreen(store, e.arguments?.getString("id") ?: "new", nav)
                }
                composable("cook/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                    CookScreen(store, timer, e.arguments?.getString("id") ?: "", nav)
                }
                composable("timer") { TimerScreen(timer, nav) }
                composable("calc") { CalcScreen(store, nav) }
                composable("web") { WebScreen(store, nav) }
                composable("ai") { AiScreen(store, nav, "") }
                composable("ai/{rid}", arguments = listOf(navArgument("rid") { type = NavType.StringType })) { e ->
                    AiScreen(store, nav, e.arguments?.getString("rid") ?: "")
                }
            }

            if (timer.active && !route.startsWith("cook") && !route.startsWith("timer")) {
                Row(
                    Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 12.dp, bottom = 12.dp + pad.calculateBottomPadding())
                        .clip(RoundedCornerShape(24.dp))
                        .background(if (timer.finished) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                        .clickable { nav.navigate("timer") }
                        .padding(start = 12.dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Timer, null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (timer.finished) "Время вышло!" else formatClock(timer.remainingSec),
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = { timer.dismiss() }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.Close, "Остановить", tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}
