@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CookbookRoot() }
    }
}

@Composable
fun CookbookRoot() {
    val vm: MainVm = viewModel()
    val store = vm.store
    CookbookTheme(store.wallpaper) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            MainScaffold(store, vm.timer)
        }
    }
}

@Composable
fun MainScaffold(store: CookbookStore, timer: TimerState) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route ?: "home"
    val dark = store.wallpaper == 0
    val scope = rememberCoroutineScope()
    val flip = remember { Animatable(0f) }
    var flipping by remember { mutableStateOf(false) }

    val tabs = listOf(
        Triple("home", "Главная", Icons.Filled.Home),
        Triple("recipes?cat=-1", "Рецепты", Icons.Filled.MenuBook),
        Triple("plan", "План", Icons.Filled.CalendarMonth),
        Triple("archive?tab=0", "Архив", Icons.Filled.PhotoLibrary),
        Triple("tools", "Ещё", Icons.Filled.Apps)
    )
    val ctx = LocalContext.current
    val activity = ctx as ComponentActivity
    var found by remember { mutableStateOf<UpdateInfo?>(null) }
    var dismissed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        found = withContext(Dispatchers.IO) {
            try {
                Updater.check(ctx)
            } catch (e: Exception) {
                null
            }
        }
    }
    val showBar = tabs.any { route.startsWith(it.first.substringBefore('?')) }

    val lightStatusIcons = dark || route.startsWith("home")
    val lightNavIcons = dark || showBar
    DisposableEffect(lightStatusIcons, lightNavIcons) {
        val statusStyle = if (lightStatusIcons) {
            SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        } else {
            SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
        }
        val navStyle = if (lightNavIcons) {
            SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        } else {
            SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
        }
        activity.enableEdgeToEdge(statusBarStyle = statusStyle, navigationBarStyle = navStyle)
        onDispose { }
    }

    // Листание страницы: старая страница уходит вокруг корешка, потом ложится новая
    fun goTab(r: String) {
        if (flipping) return
        if (route.startsWith(r.substringBefore('?'))) return
        scope.launch {
            flipping = true
            flip.snapTo(0f)
            flip.animateTo(-90f, tween(380, easing = FastOutLinearInEasing))
            nav.navigate(r) {
                popUpTo("home")
                launchSingleTop = true
            }
            flip.snapTo(90f)
            flip.animateTo(0f, tween(380, easing = LinearOutSlowInEasing))
            flipping = false
        }
    }

    val leather = if (dark) Color(0xFF1F130C) else Color(0xFF5B3420)
    val gold = Color(0xFFF0CF85)
    val creamDim = Color(0xCCEBDDBF)

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (showBar) {
                NavigationBar(containerColor = leather) {
                    tabs.forEach { (r, label, icon) ->
                        val base = r.substringBefore('?')
                        NavigationBarItem(
                            selected = route.startsWith(base),
                            onClick = { goTab(r) },
                            icon = { Icon(icon, label) },
                            label = { Text(label, maxLines = 1, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = gold,
                                selectedTextColor = gold,
                                unselectedIconColor = creamDim,
                                unselectedTextColor = creamDim,
                                indicatorColor = Color(0x33FFFFFF)
                            )
                        )
                    }
                }
            }
        }
    ) { pad ->
        val upd = found
        if (upd != null && !dismissed) {
            AlertDialog(
                onDismissRequest = { dismissed = true },
                title = { Text("Доступно обновление") },
                text = { Text("Вышла новая версия приложения (${upd.code}). Установить сейчас?") },
                confirmButton = {
                    TextButton(onClick = { dismissed = true; nav.navigate("update") }) { Text("Обновить") }
                },
                dismissButton = { TextButton(onClick = { dismissed = true }) { Text("Позже") } }
            )
        }
        val pageColor = MaterialTheme.colorScheme.background
        val under = Color(0x44000000).compositeOver(pageColor)
        val lineColor = if (dark) Color(0x0DFFFFFF) else Color(0x125A3A1F)
        val density = LocalDensity.current

        BoxWithConstraints(Modifier.fillMaxSize().background(under)) {
            val w = constraints.maxWidth.toFloat()
            val h = constraints.maxHeight.toFloat()

            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        rotationY = flip.value
                        transformOrigin = TransformOrigin(0f, 0.5f)
                        cameraDistance = 14f * density.density
                    }
                    .background(pageColor)
                    .drawWithContent {
                        drawContent()
                        // линовка страницы
                        val step = 26.dp.toPx()
                        var yy = step
                        while (yy < size.height) {
                            drawLine(lineColor, Offset(0f, yy), Offset(size.width, yy), 1f)
                            yy += step
                        }
                        // корешок слева
                        drawRect(
                            Brush.horizontalGradient(listOf(Color(0x55000000), Color.Transparent), 0f, 16.dp.toPx()),
                            Offset(0f, 0f),
                            Size(16.dp.toPx(), size.height)
                        )
                        // торец страниц справа
                        for (i in 0..2) {
                            val x = size.width - (1 + i * 2).dp.toPx()
                            drawLine(Color(0x33000000), Offset(x, 0f), Offset(x, size.height), 1f)
                        }
                    }
            ) {
                NavHost(
                    navController = nav,
                    startDestination = "home",
                    modifier = Modifier.padding(bottom = pad.calculateBottomPadding())
                ) {
                    composable("home") { HomeScreen(store, nav) }
                    composable(
                        "recipes?cat={cat}",
                        arguments = listOf(navArgument("cat") { type = NavType.IntType; defaultValue = -1 })
                    ) { e -> RecipesScreen(store, nav, e.arguments?.getInt("cat") ?: -1) }
                    composable("plan") { PlanScreen(store, nav) }
                    composable(
                        "archive?tab={tab}",
                        arguments = listOf(navArgument("tab") { type = NavType.IntType; defaultValue = 0 })
                    ) { e -> ArchiveScreen(store, e.arguments?.getInt("tab") ?: 0) }
                    composable("tools") { ToolsScreen(nav) }
                    composable("recipe/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                        DetailScreen(store, e.arguments?.getString("id") ?: "", nav)
                    }
                    composable("edit/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                        EditorScreen(store, e.arguments?.getString("id") ?: "new", nav)
                    }
                    composable("cook/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                        CookScreen(store, timer, e.arguments?.getString("id") ?: "", nav)
                    }
                    composable("timer") { TimerScreen(timer, nav) }
                    composable("calc") { CalcScreen(store, nav) }
                    composable("web") { WebScreen(store, nav) }
                    composable("update") { UpdateScreen(nav) }
                    composable("backup") { BackupScreen(store, nav) }
                    composable("ai") { AiScreen(store, nav, "") }
                    composable("ai/{rid}", arguments = listOf(navArgument("rid") { type = NavType.StringType })) { e ->
                        AiScreen(store, nav, e.arguments?.getString("rid") ?: "")
                    }
                }

                if (timer.active && !route.startsWith("cook") && !route.startsWith("timer")) {
                    Row(
                        Modifier
                            .align(Alignment.BottomStart)
                            .padding(start = 12.dp, bottom = 12.dp + pad.calculateBottomPadding())
                            .clip(RoundedCornerShape(24.dp))
                            .background(if (timer.finished) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                            .clickable { nav.navigate("timer") }
                            .padding(start = 12.dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Timer, null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            if (timer.finished) "Время вышло!" else formatClock(timer.remainingSec),
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = { timer.dismiss() }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Filled.Close, "Остановить", tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }
                }

                if (flipping) {
                    Box(
                        Modifier.fillMaxSize().background(
                            Color.Black.copy(alpha = (kotlin.math.abs(flip.value) / 90f * 0.5f).coerceIn(0f, 1f))
                        )
                    )
                }
            }

            // помощник тянет страницу за край
            if (flipping) {
                val theta = Math.toRadians(kotlin.math.abs(flip.value).toDouble())
                val edgeX = (w * Math.cos(theta)).toFloat()
                val ratW = with(density) { 90.dp.toPx() }
                val ratH = with(density) { 140.dp.toPx() }
                ChefMascot(
                    Modifier
                        .offset { IntOffset((edgeX - ratW * 0.85f).toInt(), (h * 0.45f - ratH / 2f).toInt()) }
                        .size(width = 90.dp, height = 140.dp),
                    ChefAction.PULL,
                    flip.value * 0.12f,
                    false
                )
            }
        }
    }
}
