@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.drawscope.Stroke

@Composable
fun HomeScreen(store: CookbookStore, nav: NavHostController) {
    var query by remember { mutableStateOf("") }
    var viewer by remember { mutableStateOf<MediaItem?>(null) }
    val bg = MaterialTheme.colorScheme.background

    val favorites = store.recipes.filter { it.favorite }
    val recent = store.recipes.filter { it.lastViewed > 0 }.sortedByDescending { it.lastViewed }.take(10)
    val latestMedia = store.media.filter { File(it.path).exists() }.sortedByDescending { it.addedAt }.take(12)
    val q = query.trim().lowercase()
    val results = if (q.isEmpty()) emptyList() else store.recipes.filter { r ->
        r.title.lowercase().contains(q) ||
            r.description.lowercase().contains(q) ||
            r.ingredients.any { it.name.lowercase().contains(q) } ||
            (CATEGORIES.getOrNull(r.category)?.second?.lowercase()?.contains(q) == true)
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
    val areaW = constraints.maxWidth.toFloat()
    val areaH = constraints.maxHeight.toFloat()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(bottomStart = 22.dp, bottomEnd = 22.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF7A4528), Color(0xFF4A2616))))
            ) {
                Image(
                    painter = painterResource(if (store.wallpaper == 0) R.drawable.wall_dark else R.drawable.wall_light),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    alpha = 0.16f,
                    modifier = Modifier.fillMaxSize()
                )
                Canvas(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp)) {
                    drawRoundRect(
                        Color(0xFFF0CF85),
                        cornerRadius = CornerRadius(14.dp.toPx()),
                        style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(16f, 10f)))
                    )
                }
                Canvas(Modifier.align(Alignment.TopStart).padding(start = 34.dp).size(width = 22.dp, height = 62.dp)) {
                    val p = Path()
                    p.moveTo(0f, 0f)
                    p.lineTo(size.width, 0f)
                    p.lineTo(size.width, size.height)
                    p.lineTo(size.width / 2f, size.height * 0.78f)
                    p.lineTo(0f, size.height)
                    p.close()
                    drawPath(p, Color(0xFFB3261E))
                }
                Column(
                    Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 28.dp, vertical = 18.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("🍳", fontSize = 28.sp)
                    Text(
                        "Моя кулинарная книга",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFF0CF85),
                        textAlign = TextAlign.Center
                    )
                    Text("Рецепты, заметки и секреты", color = Color(0xFFEBDDBF), style = MaterialTheme.typography.bodyMedium)
                }
                IconButton(
                    onClick = { store.chooseWallpaper(if (store.wallpaper == 0) 1 else 0) },
                    modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(end = 6.dp, top = 6.dp)
                ) {
                    Icon(Icons.Filled.Palette, "Сменить тему", tint = Color(0xFFF0CF85))
                }
            }
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Поиск блюд и рецептов") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, null) }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            )
        }
        item {
            Button(
                onClick = { nav.navigate("edit/new") },
                modifier = Modifier.fillMaxWidth().padding(16.dp).height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Filled.Add, null)
                Spacer(Modifier.width(8.dp))
                Text("Добавить рецепт", fontSize = 16.sp)
            }
        }

        item {
            OutlinedButton(
                onClick = { nav.navigate("web") },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(48.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Filled.Search, null)
                Spacer(Modifier.width(8.dp))
                Text("Найти рецепт в интернете")
            }
        }

        if (q.isNotEmpty()) {
            if (results.isEmpty()) {
                item { HintText("Ничего не найдено") }
            }
            items(results, key = { it.id }) { r ->
                RecipeRow(store, r, Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) { nav.navigate("recipe/${r.id}") }
            }
        } else {
            item { SectionTitle("❤️ Мои любимые блюда") }
            item {
                if (favorites.isEmpty()) {
                    HintText("Нажмите сердечко в рецепте — он появится здесь")
                } else {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(favorites, key = { it.id }) { r ->
                            RecipeTile(store, r) { nav.navigate("recipe/${r.id}") }
                        }
                    }
                }
            }

            item { SectionTitle("🕘 Последние просмотренные") }
            item {
                if (recent.isEmpty()) {
                    HintText("Здесь появятся рецепты, которые вы открывали")
                } else {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(recent, key = { it.id }) { r ->
                            RecipeTile(store, r) { nav.navigate("recipe/${r.id}") }
                        }
                    }
                }
            }

            item { SectionTitle("🍴 Категории блюд") }
            item {
                Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    CATEGORIES.indices.chunked(2).forEach { pair ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            pair.forEach { i ->
                                val count = store.recipes.count { it.category == i }
                                Card(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(14.dp))
                                        .clickable { nav.navigate("recipes?cat=$i") },
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                                ) {
                                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text(CATEGORIES[i].first, fontSize = 26.sp)
                                        Spacer(Modifier.width(10.dp))
                                        Column {
                                            Text(CATEGORIES[i].second, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text("$count", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }

            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    SectionTitle("📷 Недавние фото и видео", Modifier.weight(1f))
                    TextButton(onClick = { nav.navigate("archive?tab=0") }) { Text("Все") }
                }
            }
            item {
                if (latestMedia.isEmpty()) {
                    HintText("Добавьте фото или видео блюд в разделе «Архив»")
                } else {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(latestMedia, key = { it.id }) { m ->
                            MediaThumb(m.path, m.isVideo, Modifier.size(110.dp)) { viewer = m }
                        }
                    }
                }
            }
        }
    }
    DraggableChef(areaW, areaH) { nav.navigate("ai") }
    }

    viewer?.let { MediaViewerDialog(it, store) { viewer = null } }
}
