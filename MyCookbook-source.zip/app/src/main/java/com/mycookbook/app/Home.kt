@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import kotlinx.coroutines.*
import java.io.File

@Composable
fun HomeScreen(store: CookbookStore, timer: TimerState, nav: NavHostController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("cookbook_prefs", Context.MODE_PRIVATE) }

    var query by remember { mutableStateOf("") }
    var viewer by remember { mutableStateOf<MediaItem?>(null) }

    // Голосовой помощник Рататуй прямо на главном экране
    var handsFree by remember { mutableStateOf(prefs.getBoolean("ratatouille_hands_free", false)) }
    var voiceMode by remember { mutableStateOf(VoiceMode.OFF) }
    var lastHeard by remember { mutableStateOf("") }
    var lastReply by remember { mutableStateOf("") }
    var showVoiceHelp by remember { mutableStateOf(false) }
    var aiBusy by remember { mutableStateOf(false) }

    val voiceHolder = remember { arrayOfNulls<VoiceAssistant>(1) }

    fun replyVoice(text: String, keepDialog: Boolean = false) {
        lastReply = text
        voiceHolder[0]?.speak(text, keepDialog = keepDialog)
    }

    fun handleHomeCommand(cmd: VoiceCommand) {
        val va = voiceHolder[0] ?: return
        scope.launch {
            when (cmd) {
                is VoiceCommand.CookRecipe -> {
                    val found = findBestRecipeByVoice(store.recipes, cmd.query)
                    if (found != null) {
                        replyVoice("Открываю готовку: «${found.title}»!")
                        nav.navigate("cook/${found.id}")
                    } else {
                        query = cmd.query
                        replyVoice("Рецепт «${cmd.query}» в книге не нашёл. Можете спросить его у меня или найти в интернете.")
                    }
                }
                is VoiceCommand.FindRecipe -> {
                    val qLow = cmd.query.lowercase().replace('ё', 'е')
                    val matches = store.recipes.filter {
                        it.title.lowercase().replace('ё', 'е').contains(qLow)
                    }
                    val best = matches.firstOrNull() ?: findBestRecipeByVoice(store.recipes, cmd.query)
                    if (matches.size > 1) {
                        query = cmd.query
                        val top = matches.take(3).joinToString(", ") { it.title }
                        replyVoice("Нашёл ${matches.size} рецептов: $top. Показал их на экране.")
                    } else if (best != null) {
                        replyVoice("Открываю рецепт «${best.title}».")
                        nav.navigate("recipe/${best.id}")
                    } else {
                        query = cmd.query
                        replyVoice("По запросу «${cmd.query}» в книге ничего не нашёл.")
                    }
                }
                is VoiceCommand.OpenCategory -> {
                    val catName = CATEGORIES.getOrNull(cmd.categoryIndex)?.second ?: "Рецепты"
                    replyVoice("Открываю раздел «$catName».")
                    nav.navigate("recipes?cat=${cmd.categoryIndex}")
                }
                is VoiceCommand.TimerStart -> {
                    if (cmd.seconds > 0) {
                        val started = timer.start(cmd.seconds, cmd.label)
                        if (started == null) {
                            replyVoice("Уже запущено максимум 10 таймеров. Сначала остановите один из них.")
                        } else {
                            replyVoice("Запустил ${started.label} на ${formatDurationRu(cmd.seconds)}.")
                        }
                    } else {
                        val paused = timer.findTimer(preferPaused = true)
                        if (paused != null && !paused.running && !paused.finished) {
                            timer.resume(paused.id)
                            replyVoice("Продолжил ${paused.label}.")
                        } else {
                            replyVoice("Уточните время, например: поставь таймер на 10 минут.")
                        }
                    }
                }
                is VoiceCommand.TimerAdd -> {
                    val target = timer.findTimer(number = cmd.number, query = cmd.query)
                    if (target == null) {
                        replyVoice("Нет активных таймеров.")
                    } else {
                        val upd = timer.addTime(target.id, cmd.deltaSeconds)
                        if (upd != null) {
                            replyVoice("Добавил ${formatDurationRu(cmd.deltaSeconds)} к ${upd.label}. Осталось ${formatDurationRu(upd.remainingSec)}.")
                        }
                    }
                }
                is VoiceCommand.TimerPause -> {
                    if (cmd.all) {
                        val n = timer.pauseAll()
                        replyVoice(if (n > 0) "Поставил на паузу таймеров: $n." else "Нет идущих таймеров.")
                    } else {
                        val target = timer.findTimer(number = cmd.number, query = cmd.query)
                        if (target == null) replyVoice("Активных таймеров нет.")
                        else {
                            timer.pause(target.id)
                            replyVoice("${target.label} на паузе.")
                        }
                    }
                }
                is VoiceCommand.TimerResume -> {
                    if (cmd.all) {
                        val n = timer.resumeAll()
                        replyVoice(if (n > 0) "Продолжил таймеров: $n." else "Нет таймеров на паузе.")
                    } else {
                        val target = timer.findTimer(number = cmd.number, query = cmd.query, preferPaused = true)
                        if (target == null) replyVoice("Нет таймеров на паузе.")
                        else {
                            timer.resume(target.id)
                            replyVoice("Продолжил ${target.label}.")
                        }
                    }
                }
                is VoiceCommand.TimerStop -> {
                    if (cmd.all) {
                        val n = timer.dismissAll()
                        replyVoice(if (n > 0) "Остановил все таймеры." else "Активных таймеров нет.")
                    } else {
                        val target = timer.findTimer(number = cmd.number, query = cmd.query, preferFinished = true)
                        if (target == null) replyVoice("Активных таймеров нет.")
                        else {
                            timer.dismiss(target.id)
                            replyVoice("Остановил ${target.label}.")
                        }
                    }
                }
                is VoiceCommand.TimerStatus -> {
                    if (timer.timers.isEmpty()) {
                        replyVoice("Сейчас нет запущенных таймеров.")
                    } else if (cmd.number != null || !cmd.query.isNullOrBlank()) {
                        val target = timer.findTimer(number = cmd.number, query = cmd.query)
                        if (target == null) replyVoice("Такой таймер не найден.")
                        else if (target.finished) replyVoice("${target.label} уже закончился!")
                        else replyVoice("${target.label}: осталось ${formatDurationRu(target.remainingSec)}.")
                    } else {
                        val summary = timer.timers.joinToString(". ") { t ->
                            if (t.finished) "${t.label} уже готов"
                            else "${t.label} — осталось ${formatDurationRu(t.remainingSec)}"
                        }
                        replyVoice("Активных таймеров ${timer.timers.size}. $summary.")
                    }
                }
                is VoiceCommand.AddToShopping -> {
                    store.addShop(cmd.item, 0.0, "")
                    replyVoice("Добавил ${cmd.item} в список покупок.")
                }
                is VoiceCommand.OpenShopping -> {
                    replyVoice("Открываю список покупок.")
                    nav.navigate("shopping")
                }
                is VoiceCommand.OpenPlan -> {
                    replyVoice("Открываю план питания.")
                    nav.navigate("plan")
                }
                is VoiceCommand.AskTodayPlan -> {
                    val todayStr = java.time.LocalDate.now().toString()
                    val meals = (0..2).mapNotNull { sl ->
                        store.plan["$todayStr|$sl"]?.let { rid -> store.recipe(rid)?.title }
                            ?.let { t -> "${MEALS[sl].substringAfter(' ')}: $t" }
                    }
                    replyVoice(
                        if (meals.isEmpty()) "На сегодня в плане блюд пока нет."
                        else "Сегодня в плане: ${meals.joinToString(". ")}."
                    )
                }
                is VoiceCommand.OpenTimers -> {
                    replyVoice("Открываю таймеры.")
                    nav.navigate("timer")
                }
                is VoiceCommand.OpenFridge -> {
                    replyVoice("Открываю холодильник.")
                    nav.navigate("fridge")
                }
                is VoiceCommand.OpenScanner -> {
                    replyVoice("Открываю оцифровку рецепта.")
                    nav.navigate("scanner")
                }
                is VoiceCommand.OpenCalc -> {
                    replyVoice("Открываю калькулятор порций.")
                    nav.navigate("calc")
                }
                is VoiceCommand.OpenAi -> {
                    replyVoice("Открываю чат с помощником.")
                    nav.navigate("ai")
                }
                is VoiceCommand.OpenWeb -> {
                    replyVoice("Открываю поиск в интернете.")
                    nav.navigate("web")
                }
                is VoiceCommand.StopSpeaking -> {
                    va.stopSpeaking()
                }
                is VoiceCommand.ShowHelp -> {
                    showVoiceHelp = true
                    replyVoice("Скажите: готовь борщ, покажи мясо или рыбу, поставь таймер на 10 минут, добавь в покупки молоко, или задайте любой вопрос о готовке.")
                }
                is VoiceCommand.Sleep -> {
                    handsFree = false
                    prefs.edit().putBoolean("ratatouille_hands_free", false).apply()
                }
                is VoiceCommand.AskAi -> {
                    if (aiBusy) return@launch
                    aiBusy = true
                    lastReply = "Думаю над ответом…"
                    va.speak("Секунду, подумаю…")
                    try {
                        val cfg = AiProviders.load(prefs)
                        val sys = "Ты — дружелюбный кулинарный помощник-мышонок Рататуй на кухне в приложении MyCookbook. " +
                            "Ответь коротко (1–3 предложения) по-русски простыми словами для озвучки вслух, без списков и символов форматирования."
                        val ans = withContext(Dispatchers.IO) {
                            AiClient.chatCfg(cfg, sys, listOf("user" to cmd.question), maxTokens = 350)
                        }
                        val clean = ans.replace(Regex("[*_#`]+"), "").trim()
                        replyVoice(clean.ifBlank { "Не расслышал, повторите пожалуйста." })
                    } catch (e: Exception) {
                        replyVoice("Не удалось связаться с ИИ, проверьте интернет.")
                    }
                    aiBusy = false
                }
                else -> {
                    replyVoice("Сначала откройте рецепт, например скажите: «Рататуй, готовь борщ», или попросите поставить таймер.")
                }
            }
        }
    }

    val voiceAssistant = remember {
        VoiceAssistant(
            context = ctx,
            onModeChange = { m ->
                voiceMode = m
                if (m == VoiceMode.OFF) handsFree = false
            },
            onHeardText = { t -> lastHeard = t },
            onCommand = { cmd -> handleHomeCommand(cmd) }
        ).also { voiceHolder[0] = it }
    }

    DisposableEffect(Unit) {
        timer.onTimerFinished = { t ->
            val msg = timer.announceText(t)
            lastReply = msg
            voiceAssistant.speak(msg, keepDialog = handsFree)
        }
        onDispose {
            timer.onTimerFinished = null
            voiceAssistant.destroy()
        }
    }

    LaunchedEffect(Unit) {
        if (handsFree) {
            val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (granted) {
                voiceAssistant.setHandsFree(true)
            } else {
                handsFree = false
            }
        }
    }

    var pendingVoiceAction by remember { mutableStateOf<String?>(null) }
    val audioPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
            if (pendingVoiceAction == "handsfree") {
                handsFree = true
                prefs.edit().putBoolean("ratatouille_hands_free", true).apply()
                voiceAssistant.setHandsFree(true)
                replyVoice("Рататуй на связи! Позовите меня по имени «Рататуй» или «Реми», и я помогу на кухне.")
            } else {
                voiceAssistant.startSingleCommand()
            }
        } else {
            Toast.makeText(ctx, "Нужен доступ к микрофону для помощника Рататуй", Toast.LENGTH_SHORT).show()
        }
        pendingVoiceAction = null
    }

    fun triggerVoice(action: String) {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (granted) {
            if (action == "handsfree") {
                val next = !handsFree
                handsFree = next
                prefs.edit().putBoolean("ratatouille_hands_free", next).apply()
                voiceAssistant.setHandsFree(next)
                if (next) {
                    replyVoice("Рататуй на связи! Позовите меня по имени «Рататуй» или «Реми», и я помогу на кухне.")
                } else {
                    voiceAssistant.stopSpeaking()
                }
            } else {
                voiceAssistant.startSingleCommand()
            }
        } else {
            pendingVoiceAction = action
            audioPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    val favorites = store.recipes.filter { it.favorite }
    val recent = store.recipes.filter { it.lastViewed > 0 }.sortedByDescending { it.lastViewed }.take(10)
    val latestMedia = store.media.filter { File(it.path).exists() }.sortedByDescending { it.addedAt }.take(12)
    val q = query.trim().lowercase()
    val results = if (q.isEmpty()) emptyList() else store.recipes.filter { r ->
        r.title.lowercase().contains(q) ||
            r.description.lowercase().contains(q) ||
            r.ingredients.any { it.name.lowercase().contains(q) } ||
            (CATEGORIES.getOrNull(r.category)?.second?.lowercase()?.contains(q) == true)
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(bottomStart = 22.dp, bottomEnd = 22.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF7A4528), Color(0xFF4A2616))))
            ) {
                Image(
                    painter = painterResource(if (store.wallpaper == 0) R.drawable.wall_dark else R.drawable.wall_light),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    alpha = 0.16f,
                    modifier = Modifier.fillMaxSize()
                )
                Canvas(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp)) {
                    drawRoundRect(
                        Color(0xFFF0CF85),
                        cornerRadius = CornerRadius(14.dp.toPx()),
                        style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(16f, 10f)))
                    )
                }
                Canvas(Modifier.align(Alignment.TopStart).padding(start = 34.dp).size(width = 22.dp, height = 62.dp)) {
                    val p = Path()
                    p.moveTo(0f, 0f)
                    p.lineTo(size.width, 0f)
                    p.lineTo(size.width, size.height)
                    p.lineTo(size.width / 2f, size.height * 0.78f)
                    p.lineTo(0f, size.height)
                    p.close()
                    drawPath(p, Color(0xFFB3261E))
                }
                Column(
                    Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 28.dp, vertical = 18.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("🍳", fontSize = 28.sp)
                    Text(
                        "Моя кулинарная книга",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFF0CF85),
                        textAlign = TextAlign.Center
                    )
                    Text("Рецепты, заметки и секреты", color = Color(0xFFEBDDBF), style = MaterialTheme.typography.bodyMedium)
                }
                IconButton(
                    onClick = { store.chooseWallpaper(if (store.wallpaper == 0) 1 else 0) },
                    modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(end = 6.dp, top = 6.dp)
                ) {
                    Icon(Icons.Filled.Palette, "Сменить тему", tint = Color(0xFFF0CF85))
                }
            }
        }

        // Карточка голосового помощника Рататуй на главном экране
        item {
            val cardBg = when (voiceMode) {
                VoiceMode.LISTENING_COMMAND -> MaterialTheme.colorScheme.errorContainer
                VoiceMode.WAITING_WAKE -> MaterialTheme.colorScheme.primaryContainer
                VoiceMode.SPEAKING -> MaterialTheme.colorScheme.secondaryContainer
                VoiceMode.OFF -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
            }
            val cardFg = when (voiceMode) {
                VoiceMode.LISTENING_COMMAND -> MaterialTheme.colorScheme.onErrorContainer
                VoiceMode.WAITING_WAKE -> MaterialTheme.colorScheme.onPrimaryContainer
                VoiceMode.SPEAKING -> MaterialTheme.colorScheme.onSecondaryContainer
                VoiceMode.OFF -> MaterialTheme.colorScheme.onPrimaryContainer
            }
            val titleTxt = when {
                aiBusy -> "🐭 Рататуй думает…"
                voiceMode == VoiceMode.LISTENING_COMMAND -> "🎤 Рататуй слушает команду…"
                voiceMode == VoiceMode.WAITING_WAKE -> "👂 Жду «Рататуй» / «Реми»"
                voiceMode == VoiceMode.SPEAKING -> "🔊 Рататуй говорит…"
                else -> "🐭 Позвать Рататуя на кухню"
            }
            val subTxt = when {
                lastHeard.isNotBlank() && voiceMode == VoiceMode.LISTENING_COMMAND -> "«$lastHeard»"
                voiceMode == VoiceMode.WAITING_WAKE -> "В фоне игнорирую разговоры. Скажите «Рататуй, готовь борщ» или «таймер 10 мин»"
                voiceMode == VoiceMode.SPEAKING -> "Нажмите, чтобы остановить озвучку"
                else -> "Нажмите и скажите команду или включите «Без рук»"
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, top = 12.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .clickable {
                        if (voiceMode == VoiceMode.SPEAKING) voiceAssistant.stopSpeaking()
                        else triggerVoice("single")
                    },
                colors = CardDefaults.cardColors(containerColor = cardBg),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f))
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            if (handsFree) Icons.Filled.RecordVoiceOver else Icons.Filled.Mic,
                            null,
                            tint = if (voiceMode == VoiceMode.LISTENING_COMMAND) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(titleTxt, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = cardFg)
                            Text(subTxt, style = MaterialTheme.typography.bodySmall, color = cardFg.copy(alpha = 0.85f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        IconButton(onClick = { showVoiceHelp = true }, modifier = Modifier.size(34.dp)) {
                            Icon(Icons.Filled.HelpOutline, "Команды Рататуя", tint = cardFg, modifier = Modifier.size(20.dp))
                        }
                        FilterChip(
                            selected = handsFree,
                            onClick = { triggerVoice("handsfree") },
                            label = { Text(if (handsFree) "Без рук ✓" else "Без рук", fontSize = 11.sp) }
                        )
                    }
                    if (lastReply.isNotBlank()) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.65f))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "🐭 $lastReply",
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { lastReply = "" }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Filled.Close, "Скрыть", modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Поиск блюд и продуктов") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, null) }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            )
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { nav.navigate("edit/new") },
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp)
                ) {
                    Icon(Icons.Filled.Add, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Новый рецепт", fontSize = 14.sp, maxLines = 1)
                }
                FilledTonalButton(
                    onClick = { nav.navigate("scanner") },
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp)
                ) {
                    Icon(Icons.Filled.CameraAlt, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Оцифровать", fontSize = 14.sp, maxLines = 1)
                }
            }
        }
        item {
            val quick = listOf(
                Triple("❄️", "Холодильник", "fridge"),
                Triple("⏱", "Таймеры (${timer.timers.size}/10)", "timer"),
                Triple("🌐", "Из интернета", "web"),
                Triple("🤖", "ИИ-помощник", "ai")
            )
            Column(
                Modifier.padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 6.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                quick.chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        pair.forEach { (emoji, label, route) ->
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { nav.navigate(route) },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(emoji, fontSize = 22.sp)
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        label,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (q.isNotEmpty()) {
            if (results.isEmpty()) {
                item { HintText("Ничего не найдено") }
            }
            items(results, key = { it.id }) { r ->
                RecipeRow(store, r, Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) { nav.navigate("recipe/${r.id}") }
            }
        } else {
            item { SectionTitle("❤️ Мои любимые блюда") }
            item {
                if (favorites.isEmpty()) {
                    HintText("Нажмите сердечко в рецепте — он появится здесь")
                } else {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(favorites, key = { it.id }) { r ->
                            RecipeTile(store, r) { nav.navigate("recipe/${r.id}") }
                        }
                    }
                }
            }

            item { SectionTitle("🕘 Последние просмотренные") }
            item {
                if (recent.isEmpty()) {
                    HintText("Здесь появятся рецепты, которые вы открывали")
                } else {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(recent, key = { it.id }) { r ->
                            RecipeTile(store, r) { nav.navigate("recipe/${r.id}") }
                        }
                    }
                }
            }

            item { SectionTitle("🍴 Разделы рецептов") }
            item {
                Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    CATEGORY_DISPLAY_ORDER.chunked(2).forEach { pair ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            pair.forEach { i ->
                                val count = store.recipes.count { it.category == i }
                                Card(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(14.dp))
                                        .clickable { nav.navigate("recipes?cat=$i") },
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                                ) {
                                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text(CATEGORIES[i].first, fontSize = 26.sp)
                                        Spacer(Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                CATEGORIES[i].second,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text("$count", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }

            item { SectionTitle("🌍 Кухни мира") }
            item {
                val cuisines = store.recipes.map { it.cuisine }.filter { it.isNotBlank() }.distinct().sorted()
                if (cuisines.isEmpty()) {
                    HintText("Здесь появятся кухни разных стран")
                } else {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(cuisines) { c ->
                            AssistChip(onClick = { store.cuisineFilter = c; nav.navigate("recipes?cat=-1") }, label = { Text(c) })
                        }
                    }
                }
            }

            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    SectionTitle("📷 Недавние фото и видео", Modifier.weight(1f))
                    TextButton(onClick = { nav.navigate("archive?tab=0") }) { Text("Все") }
                }
            }
            item {
                if (latestMedia.isEmpty()) {
                    HintText("Добавьте фото или видео блюд в разделе «Архив»")
                } else {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(latestMedia, key = { it.id }) { m ->
                            MediaThumb(m.path, m.isVideo, Modifier.size(110.dp)) { viewer = m }
                        }
                    }
                }
            }
        }
    }
    }

    if (showVoiceHelp) RatatouilleHelpDialog { showVoiceHelp = false }
    viewer?.let { MediaViewerDialog(it, store) { viewer = null } }
}
