@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.navigation.NavHostController
import java.io.File

@Composable
fun HomeScreen(store: CookbookStore, timer: TimerState, nav: NavHostController) {
    val voiceHub = LocalVoiceHub.current
    var query by remember { mutableStateOf("") }
    var viewer by remember { mutableStateOf<MediaItem?>(null) }

    val favorites = store.recipes.filter { it.favorite }
    val recent = store.recipes.filter { it.lastViewed > 0 }.sortedByDescending { it.lastViewed }.take(10)
    val latestMedia = store.media.filter { File(it.path).exists() }.sortedByDescending { it.addedAt }.take(12)
    val q = query.trim().lowercase()
    val results = if (q.isEmpty()) emptyList() else store.recipes.filter { r ->
        r.title.lowercase().contains(q) ||
            r.description.lowercase().contains(q) ||
            r.ingredients.any { it.name.lowercase().contains(q) } ||
            (CATEGORIES.getOrNull(r.category)?.second?.lowercase()?.contains(q) == true)
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(bottomStart = 22.dp, bottomEnd = 22.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF7A4528), Color(0xFF4A2616))))
            ) {
                Image(
                    painter = painterResource(if (store.wallpaper == 0) R.drawable.wall_dark else R.drawable.wall_light),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    alpha = 0.16f,
                    modifier = Modifier.fillMaxSize()
                )
                Canvas(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp)) {
                    drawRoundRect(
                        Color(0xFFF0CF85),
                        cornerRadius = CornerRadius(14.dp.toPx()),
                        style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(16f, 10f)))
                    )
                }
                Canvas(Modifier.align(Alignment.TopStart).padding(start = 34.dp).size(width = 22.dp, height = 62.dp)) {
                    val p = Path()
                    p.moveTo(0f, 0f)
                    p.lineTo(size.width, 0f)
                    p.lineTo(size.width, size.height)
                    p.lineTo(size.width / 2f, size.height * 0.78f)
                    p.lineTo(0f, size.height)
                    p.close()
                    drawPath(p, Color(0xFFB3261E))
                }
                Column(
                    Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 28.dp, vertical = 18.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("🍳", fontSize = 28.sp)
                    Text(
                        "Моя кулинарная книга",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFF0CF85),
                        textAlign = TextAlign.Center
                    )
                    Text("Рецепты, заметки и секреты", color = Color(0xFFEBDDBF), style = MaterialTheme.typography.bodyMedium)
                }
                IconButton(
                    onClick = { store.chooseWallpaper(if (store.wallpaper == 0) 1 else 0) },
                    modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(end = 6.dp, top = 6.dp)
                ) {
                    Icon(Icons.Filled.Palette, "Сменить тему", tint = Color(0xFFF0CF85))
                }
            }
        }

        // Карточка глобального голосового помощника Рататуй на главном экране
        item {
            val cardBg = when (voiceHub.voiceMode) {
                VoiceMode.LISTENING_COMMAND -> MaterialTheme.colorScheme.errorContainer
                VoiceMode.WAITING_WAKE -> MaterialTheme.colorScheme.primaryContainer
                VoiceMode.SPEAKING -> MaterialTheme.colorScheme.secondaryContainer
                VoiceMode.OFF -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
            }
            val cardFg = when (voiceHub.voiceMode) {
                VoiceMode.LISTENING_COMMAND -> MaterialTheme.colorScheme.onErrorContainer
                VoiceMode.WAITING_WAKE -> MaterialTheme.colorScheme.onPrimaryContainer
                VoiceMode.SPEAKING -> MaterialTheme.colorScheme.onSecondaryContainer
                VoiceMode.OFF -> MaterialTheme.colorScheme.onPrimaryContainer
            }
            val titleTxt = when {
                voiceHub.aiBusy -> "🐭 Рататуй думает…"
                voiceHub.voiceMode == VoiceMode.LISTENING_COMMAND -> "🎤 Рататуй слушает команду…"
                voiceHub.voiceMode == VoiceMode.WAITING_WAKE -> "👂 Жду «Рататуй» / «Реми»"
                voiceHub.voiceMode == VoiceMode.SPEAKING -> "🔊 Рататуй говорит…"
                else -> "🐭 Позвать Рататуя на кухню"
            }
            val subTxt = when {
                voiceHub.lastHeard.isNotBlank() && voiceHub.voiceMode == VoiceMode.LISTENING_COMMAND -> "«${voiceHub.lastHeard}»"
                voiceHub.voiceMode == VoiceMode.WAITING_WAKE -> "Работает на всех страницах. Скажите «Рататуй, готовь борщ» или «таймер 10 мин»"
                voiceHub.voiceMode == VoiceMode.SPEAKING -> "Нажмите, чтобы остановить озвучку"
                else -> "Нажмите или включите «Без рук» — работает во всех разделах"
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, top = 12.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .clickable {
                        if (voiceHub.voiceMode == VoiceMode.SPEAKING) voiceHub.stopSpeaking()
                        else voiceHub.triggerVoice("single")
                    },
                colors = CardDefaults.cardColors(containerColor = cardBg),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f))
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            if (voiceHub.handsFree) Icons.Filled.RecordVoiceOver else Icons.Filled.Mic,
                            null,
                            tint = if (voiceHub.voiceMode == VoiceMode.LISTENING_COMMAND) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(titleTxt, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = cardFg)
                            Text(subTxt, style = MaterialTheme.typography.bodySmall, color = cardFg.copy(alpha = 0.85f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        IconButton(onClick = { voiceHub.openHelp() }, modifier = Modifier.size(34.dp)) {
                            Icon(Icons.Filled.HelpOutline, "Команды Рататуя", tint = cardFg, modifier = Modifier.size(20.dp))
                        }
                        FilterChip(
                            selected = voiceHub.handsFree,
                            onClick = { voiceHub.triggerVoice("handsfree") },
                            label = { Text(if (voiceHub.handsFree) "Без рук ✓" else "Без рук", fontSize = 11.sp) }
                        )
                    }
                    if (voiceHub.lastReply.isNotBlank()) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.65f))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "🐭 ${voiceHub.lastReply}",
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { voiceHub.clearReply() }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Filled.Close, "Скрыть", modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Поиск блюд и продуктов") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, null) }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            )
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { nav.navigate("edit/new") },
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp)
                ) {
                    Icon(Icons.Filled.Add, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Новый рецепт", fontSize = 14.sp, maxLines = 1)
                }
                FilledTonalButton(
                    onClick = { nav.navigate("scanner") },
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp)
                ) {
                    Icon(Icons.Filled.CameraAlt, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Оцифровать", fontSize = 14.sp, maxLines = 1)
                }
            }
        }
        item {
            val quick = listOf(
                Triple("❄️", "Холодильник", "fridge"),
                Triple("⏱", "Таймеры (${timer.timers.size}/10)", "timer"),
                Triple("🌐", "Из интернета", "web"),
                Triple("🤖", "ИИ-помощник", "ai")
            )
            Column(
                Modifier.padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 6.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                quick.chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        pair.forEach { (emoji, label, route) ->
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { nav.navigate(route) },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(emoji, fontSize = 22.sp)
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        label,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (q.isNotEmpty()) {
            if (results.isEmpty()) {
                item { HintText("Ничего не найдено") }
            }
            items(results, key = { it.id }) { r ->
                RecipeRow(store, r, Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) { nav.navigate("recipe/${r.id}") }
            }
        } else {
            item { SectionTitle("❤️ Мои любимые блюда") }
            item {
                if (favorites.isEmpty()) {
                    HintText("Нажмите сердечко в рецепте — он появится здесь")
                } else {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(favorites, key = { it.id }) { r ->
                            RecipeTile(store, r) { nav.navigate("recipe/${r.id}") }
                        }
                    }
                }
            }

            item { SectionTitle("🕘 Последние просмотренные") }
            item {
                if (recent.isEmpty()) {
                    HintText("Здесь появятся рецепты, которые вы открывали")
                } else {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(recent, key = { it.id }) { r ->
                            RecipeTile(store, r) { nav.navigate("recipe/${r.id}") }
                        }
                    }
                }
            }

            item { SectionTitle("🍴 Разделы книги") }
            item {
                Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    CATEGORIES.indices.chunked(2).forEach { pair ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            pair.forEach { i ->
                                val count = store.recipes.count { it.category == i }
                                val hint = CATEGORY_HINTS[i] ?: ""
                                Card(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(14.dp))
                                        .clickable { nav.navigate("recipes?cat=$i&sub=") },
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                                ) {
                                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text(CATEGORIES[i].first, fontSize = 26.sp)
                                        Spacer(Modifier.width(10.dp))
                                        Column(Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    CATEGORIES[i].second,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    modifier = Modifier.weight(1f, fill = false)
                                                )
                                                Spacer(Modifier.width(4.dp))
                                                Text(
                                                    "($count)",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                            }
                                            if (hint.isNotBlank()) {
                                                Text(
                                                    hint,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }

            item { SectionTitle("🌍 Кухни мира") }
            item {
                val cuisines = store.recipes.map { it.cuisine }.filter { it.isNotBlank() }.distinct().sorted()
                if (cuisines.isEmpty()) {
                    HintText("Здесь появятся кухни разных стран")
                } else {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(cuisines) { c ->
                            AssistChip(onClick = { store.cuisineFilter = c; nav.navigate("recipes?cat=-1") }, label = { Text(c) })
                        }
                    }
                }
            }

            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    SectionTitle("📷 Недавние фото и видео", Modifier.weight(1f))
                    TextButton(onClick = { nav.navigate("archive?tab=0") }) { Text("Все") }
                }
            }
            item {
                if (latestMedia.isEmpty()) {
                    HintText("Добавьте фото или видео блюд в разделе «Архив»")
                } else {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(latestMedia, key = { it.id }) { m ->
                            MediaThumb(m.path, m.isVideo, Modifier.size(110.dp)) { viewer = m }
                        }
                    }
                }
            }
        }
    }
    }

    viewer?.let { MediaViewerDialog(it, store) { viewer = null } }
}
