@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

object AiClient {
    fun call(
        key: String, model: String, system: String, msgs: List<Pair<String, String>>,
        maxTokens: Int = 4096, json: Boolean = false
    ): String {
        val body = JSONObject()
        val sysParts = JSONArray()
        sysParts.put(JSONObject().put("text", system))
        body.put("systemInstruction", JSONObject().put("parts", sysParts))
        val contents = JSONArray()
        msgs.forEach { (r, t) ->
            val parts = JSONArray()
            parts.put(JSONObject().put("text", t))
            contents.put(JSONObject().put("role", if (r == "assistant") "model" else "user").put("parts", parts))
        }
        body.put("contents", contents)
        val gc = JSONObject()
        gc.put("maxOutputTokens", maxTokens)
        if (json) gc.put("responseMimeType", "application/json")
        body.put("generationConfig", gc)

        val c = java.net.URL(
            "https://generativelanguage.googleapis.com/v1beta/models/" + model.trim() + ":generateContent"
        ).openConnection() as java.net.HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 20000
        c.readTimeout = 90000
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("x-goog-api-key", key.trim())
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.use { String(it.readBytes(), Charsets.UTF_8) } ?: ""
        if (code !in 200..299) {
            val msg = try {
                JSONObject(text).getJSONObject("error").getString("message")
            } catch (e: Exception) {
                text.take(200)
            }
            throw Exception("$code: $msg")
        }
        val cand = JSONObject(text).optJSONArray("candidates")
        val parts = cand?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                if (!part.optBoolean("thought", false)) sb.append(part.optString("text"))
            }
        }
        val out = sb.toString().trim()
        if (out.isEmpty()) throw Exception("пустой ответ (возможно, сработал фильтр безопасности)")
        return out
    }

    fun recipeJsonSystem(): String =
        "Преобразуй присланный текст в рецепт. Верни ТОЛЬКО один JSON-объект без пояснений и без markdown. " +
            "Поля: title (строка), description (строка), servings (целое), timeMin (целое, минуты), tempC (целое, 0 если не нужна), " +
            "category (целое: 0 завтраки, 1 супы, 2 основные блюда, 3 салаты, 4 закуски, 5 выпечка, 6 десерты, 7 напитки, 8 заготовки), " +
            "ingredients (массив объектов name, amount число, unit одно из: г, кг, мл, л, шт, ст.л., ч.л., стакан, щепотка, по вкусу), " +
            "steps (массив строк), secrets (строка с советами или пустая)."

    fun parseRecipeJson(raw: String): ParsedRecipe? {
        val a = raw.indexOf('{')
        val b = raw.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        val o = try {
            JSONObject(raw.substring(a, b + 1))
        } catch (e: Exception) {
            return null
        }
        val title = o.optString("title").trim()
        if (title.isEmpty()) return null
        val ings = ArrayList<Ingredient>()
        val ia = o.optJSONArray("ingredients")
        if (ia != null) {
            for (i in 0 until ia.length()) {
                val x = ia.optJSONObject(i) ?: continue
                val unit = x.optString("unit").trim().let { if (it in UNITS) it else "" }
                ings.add(Ingredient(x.optString("name").trim(), x.optDouble("amount", 0.0).let { if (it.isNaN()) 0.0 else it }, unit))
            }
        }
        val steps = ArrayList<String>()
        val sa = o.optJSONArray("steps")
        if (sa != null) {
            for (i in 0 until sa.length()) {
                val s = sa.optString(i).trim()
                if (s.isNotEmpty()) steps.add(s)
            }
        }
        if (ings.isEmpty() && steps.isEmpty()) return null
        return ParsedRecipe(
            title = title,
            description = o.optString("description").trim(),
            servings = o.optInt("servings", 4).let { if (it in 1..99) it else 4 },
            timeMin = o.optInt("timeMin", 0).coerceAtLeast(0),
            tempC = o.optInt("tempC", 0).coerceAtLeast(0),
            ingredients = ings,
            steps = steps,
            imageUrl = null,
            sourceUrl = "ИИ-помощник",
            category = o.optInt("category", 2).coerceIn(0, CATEGORIES.size - 1)
        )
    }
}

@Composable
fun AiScreen(store: CookbookStore, nav: NavHostController, rid: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("cookbook_prefs", Context.MODE_PRIVATE) }
    var key by remember { mutableStateOf(prefs.getString("gemini_key", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("gemini_model", "gemini-flash-latest") ?: "gemini-flash-latest") }
    var showSettings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf<Pair<String, String>>() }
    val listState = rememberLazyListState()

    val recipe = if (rid.isNotEmpty()) store.recipe(rid) else null
    val system = remember(rid) {
        var s = "Ты — дружелюбный кулинарный помощник в приложении «MyCookbook». Отвечай по-русски, кратко и по делу. " +
            "Указывай граммовки, время и температуру, предлагай замены продуктов и полезные хитрости. " +
            "Если просят рецепт, оформи: название, ингредиенты с количеством, шаги по пунктам."
        val r = if (rid.isNotEmpty()) store.recipe(rid) else null
        if (r != null) {
            s += "\n\nПользователь сейчас смотрит свой рецепт «${r.title}». Порций: ${r.servings}. Ингредиенты: " +
                r.ingredients.joinToString("; ") { it.name + " " + ingredientLine(it, 1.0) } +
                ". Шаги: " + r.steps.mapIndexed { i, st -> "${i + 1}) ${st.text}" }.joinToString(" ") +
                (if (r.notes.isNotBlank()) ". Заметки: ${r.notes}" else "")
        }
        s
    }

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_LONG).show()

    fun send(text: String) {
        val t = text.trim()
        if (busy || t.isEmpty()) return
        if (key.isBlank()) {
            showSettings = true
            return
        }
        messages.add("user" to t)
        input = ""
        scope.launch {
            busy = true
            try {
                val history = messages.toList().takeLast(20).dropWhile { it.first != "user" }
                val reply = withContext(Dispatchers.IO) { AiClient.call(key, model, system, history) }
                messages.add("assistant" to reply)
            } catch (e: Exception) {
                messages.removeAt(messages.lastIndex)
                input = t
                toast("Ошибка ИИ: " + (e.message ?: "нет связи"))
            }
            busy = false
        }
    }

    fun toBook(text: String) {
        if (busy) return
        if (key.isBlank()) {
            showSettings = true
            return
        }
        scope.launch {
            busy = true
            try {
                val raw = withContext(Dispatchers.IO) {
                    AiClient.call(key, model, AiClient.recipeJsonSystem(), listOf("user" to text), 4096, true)
                }
                val p = AiClient.parseRecipeJson(raw)
                if (p == null) {
                    toast("Не удалось оформить рецепт. Попробуйте попросить ИИ написать рецепт полностью.")
                } else {
                    val id = WebImport.addToBook(ctx, store, p)
                    toast("Добавлено в книгу")
                    nav.navigate("recipe/$id")
                }
            } catch (e: Exception) {
                toast("Ошибка ИИ: " + (e.message ?: "нет связи"))
            }
            busy = false
        }
    }

    LaunchedEffect(messages.size, busy) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (recipe != null) "ИИ: " + recipe.title else "ИИ-помощник", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } },
                actions = { IconButton(onClick = { showSettings = true }) { Icon(Icons.Filled.Settings, "Настройки ИИ") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().imePadding()) {
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(),
                state = listState,
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (messages.isEmpty()) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("🤖 Спросите про блюдо, замену продуктов или меню.", style = MaterialTheme.typography.titleMedium)
                            if (key.isBlank()) {
                                Text(
                                    "Чтобы помощник заработал, добавьте бесплатный ключ Gemini API (значок шестерёнки сверху).",
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            val ideas = if (recipe != null) listOf(
                                "Чем можно заменить ингредиенты в этом рецепте?",
                                "Как сделать это блюдо менее калорийным?",
                                "Предложи, с чем подать это блюдо",
                                "Подскажи секреты, чтобы получилось вкуснее"
                            ) else listOf(
                                "Что приготовить из курицы, риса и лука?",
                                "Чем заменить сливки?",
                                "Составь меню на неделю",
                                "Как исправить пересоленный суп?"
                            )
                            ideas.forEach { idea ->
                                AssistChip(onClick = { send(idea) }, label = { Text(idea) })
                            }
                        }
                    }
                }
                items(messages.size) { i ->
                    val (role, text) = messages[i]
                    val mine = role == "user"
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
                        Box(
                            Modifier
                                .widthIn(max = 320.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                                .padding(12.dp)
                        ) {
                            Text(text, color = if (mine) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface)
                        }
                        if (!mine) {
                            TextButton(onClick = { toBook(text) }, enabled = !busy) {
                                Icon(Icons.Filled.Add, null, Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Сохранить как рецепт")
                            }
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    placeholder = { Text("Спросите помощника…") },
                    maxLines = 4,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { send(input) }, enabled = !busy && input.isNotBlank()) {
                    Icon(Icons.AutoMirrored.Filled.Send, "Отправить", tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }

    if (showSettings) {
        var k by remember { mutableStateOf(key) }
        var m by remember { mutableStateOf(model) }
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("Настройки ИИ") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Бесплатный ключ создаётся на сайте aistudio.google.com (кнопка Get API key). Он хранится только на этом телефоне.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        k, { k = it },
                        label = { Text("Ключ Gemini API") },
                        singleLine = true,
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        m, { m = it },
                        label = { Text("Модель") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    key = k.trim()
                    model = m.trim().ifBlank { "gemini-flash-latest" }
                    prefs.edit().putString("gemini_key", key).putString("gemini_model", model).apply()
                    showSettings = false
                }) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Отмена") } }
        )
    }
}
