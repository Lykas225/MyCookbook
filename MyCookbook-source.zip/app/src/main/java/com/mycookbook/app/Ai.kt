@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

data class AiConfig(val provider: String, val key: String, val model: String, val baseUrl: String)

class AiProviderInfo(
    val id: String, val title: String, val baseUrl: String, val model: String, val hint: String
)

object AiProviders {
    val list = listOf(
        AiProviderInfo("auto", "⚡ Авто (без VPN, лучший выбор)", "", "", "Сначала использует встроенный ключ без VPN (Mistral / OpenRouter), затем остальные ключи сборки, а если их нет — бесплатные серверы без ключа."),
        AiProviderInfo("mistral", "🇷🇺 Mistral AI (без VPN, текст + фото)", "https://api.mistral.ai/v1", "mistral-small-latest", "Работает в РФ без VPN! Быстрый, понимает фото холодильника. Бесплатный ключ без карты: console.mistral.ai → API Keys."),
        AiProviderInfo("openrouter", "🇷🇺 OpenRouter (без VPN, :free)", "https://openrouter.ai/api/v1", "meta-llama/llama-3.3-70b-instruct:free", "Работает в РФ без VPN. Бесплатный ключ: openrouter.ai/keys. Бесплатные модели помечены :free."),
        AiProviderInfo("pollinations_fast", "🆓 Pollinations Быстрый (без ключа)", "https://text.pollinations.ai/openai", "openai-fast", "Бесплатный сервер без регистрации и ключа. Быстрая облегчённая модель."),
        AiProviderInfo("pollinations_mistral", "🆓 Pollinations Mistral (без ключа)", "https://text.pollinations.ai/openai", "mistral", "Запасной бесплатный сервер без ключа и регистрации."),
        AiProviderInfo("groq_fast", "⚡ Groq Мгновенный (нужен VPN)", "https://api.groq.com/openai/v1", "llama-3.1-8b-instant", "Ответ за ~0.5 сек (в РФ нужен VPN). Бесплатный ключ: console.groq.com."),
        AiProviderInfo("cerebras", "⚡ Cerebras 70B (нужен VPN)", "https://api.cerebras.ai/v1", "llama-3.3-70b", "Рекордная скорость (в РФ нужен VPN). Бесплатный ключ: cloud.cerebras.ai."),
        AiProviderInfo("groq", "⚡ Groq 70B (нужен VPN)", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile", "Быстрый и умный (в РФ нужен VPN). Бесплатный ключ: console.groq.com."),
        AiProviderInfo("gemini", "📷 Google Gemini Flash (нужен VPN)", "", "gemini-flash-latest", "Текст + фото холодильника (в РФ нужен VPN). Бесплатный ключ: aistudio.google.com."),
        AiProviderInfo("sambanova", "⚡ SambaNova 70B (нужен VPN)", "https://api.sambanova.ai/v1", "Meta-Llama-3.3-70B-Instruct", "Быстрый бесплатный API: cloud.sambanova.ai."),
        AiProviderInfo("custom", "Свой сервер (OpenAI-совместимый)", "", "", "Любой сервис с адресом вида …/v1: свой прокси, Ollama, LM Studio.")
    )

    fun isKeyless(id: String): Boolean = id == "auto" || id.startsWith("pollinations")

    fun info(id: String): AiProviderInfo = list.firstOrNull { it.id == id } ?: list[0]

    fun loadFor(p: android.content.SharedPreferences, id: String): AiConfig {
        val inf = info(id)
        val legacyKey = if (id == "gemini") (p.getString("gemini_key", "") ?: "") else ""
        val legacyModel = if (id == "gemini") p.getString("gemini_model", null) else null
        val key = p.getString("ai_key_" + id, null) ?: legacyKey
        val model = p.getString("ai_model_" + id, null) ?: legacyModel ?: inf.model
        val base = p.getString("ai_base_" + id, null) ?: inf.baseUrl
        return AiConfig(id, key, model, base)
    }

    fun load(p: android.content.SharedPreferences): AiConfig {
        val id = p.getString("ai_provider", null)
            ?: if (!p.getString("gemini_key", "").isNullOrBlank()) "gemini" else "auto"
        return loadFor(p, id)
    }

    fun savedKey(p: android.content.SharedPreferences?, id: String): String {
        if (p == null) return ""
        val k = p.getString("ai_key_" + id, null)?.trim()
        if (!k.isNullOrBlank()) return k
        if (id == "gemini") return p.getString("gemini_key", "")?.trim() ?: ""
        return ""
    }

    fun effectiveKey(p: android.content.SharedPreferences?, id: String): String {
        val user = savedKey(p, id)
        if (user.isNotBlank()) return user
        return when (id) {
            "mistral" -> BuildConfig.MISTRAL_KEY
            "openrouter" -> BuildConfig.OPENROUTER_KEY
            "groq", "groq_fast" -> BuildConfig.GROQ_KEY
            "gemini" -> BuildConfig.GEMINI_KEY
            "cerebras" -> BuildConfig.CEREBRAS_KEY
            "sambanova" -> BuildConfig.SAMBANOVA_KEY
            else -> ""
        }
    }

    fun save(p: android.content.SharedPreferences, c: AiConfig) {
        p.edit()
            .putString("ai_provider", c.provider)
            .putString("ai_key_" + c.provider, c.key)
            .putString("ai_model_" + c.provider, c.model)
            .putString("ai_base_" + c.provider, c.baseUrl)
            .apply()
    }
}

object AiClient {
    /** POST с защитой от «unexpected end of stream»: без keep-alive, фиксированная длина, повторы. */
    internal fun post(url: String, headers: Map<String, String>, body: String): Pair<Int, String> {
        val bytes = body.toByteArray(Charsets.UTF_8)
        var last: Exception? = null
        for (attempt in 0..2) {
            try {
                val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.useCaches = false
                c.connectTimeout = 12000
                c.readTimeout = 45000
                c.setFixedLengthStreamingMode(bytes.size)
                c.setRequestProperty("Connection", "close")
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
                c.outputStream.use { it.write(bytes) }
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val text = stream?.use { String(it.readBytes(), Charsets.UTF_8) } ?: ""
                c.disconnect()
                if ((code == 503 || code == 500) && attempt < 2) {
                    Thread.sleep(1200)
                    continue
                }
                return code to text
            } catch (e: java.io.IOException) {
                last = e
                Thread.sleep(700)
            }
        }
        throw Exception("нет связи с сервером ИИ (" + (last?.message ?: "") + ")")
    }

    fun call(
        key: String, model: String, system: String, msgs: List<Pair<String, String>>,
        maxTokens: Int = 4096, json: Boolean = false
    ): String {
        val body = JSONObject()
        val sysParts = JSONArray()
        sysParts.put(JSONObject().put("text", system))
        body.put("systemInstruction", JSONObject().put("parts", sysParts))
        val contents = JSONArray()
        msgs.forEach { (r, t) ->
            val parts = JSONArray()
            parts.put(JSONObject().put("text", t))
            contents.put(JSONObject().put("role", if (r == "assistant") "model" else "user").put("parts", parts))
        }
        body.put("contents", contents)
        val gc = JSONObject()
        gc.put("maxOutputTokens", maxTokens)
        if (json) gc.put("responseMimeType", "application/json")
        body.put("generationConfig", gc)

        val (code, text) = post(
            "https://generativelanguage.googleapis.com/v1beta/models/" + model.trim() + ":generateContent",
            mapOf("x-goog-api-key" to key.trim()),
            body.toString()
        )
        if (code !in 200..299) {
            val msg = try {
                JSONObject(text).getJSONObject("error").getString("message")
            } catch (e: Exception) {
                text.take(200)
            }
            throw Exception("$code: $msg")
        }
        val cand = JSONObject(text).optJSONArray("candidates")
        val parts = cand?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                if (!part.optBoolean("thought", false)) sb.append(part.optString("text"))
            }
        }
        val out = sb.toString().trim()
        if (out.isEmpty()) throw Exception("пустой ответ (возможно, сработал фильтр безопасности)")
        return out
    }

    /** Бесплатные общие серверы без ключа с авто-переключением (сначала самая быстрая модель). */
    fun callFree(system: String, msgs: List<Pair<String, String>>): String {
        val arr = JSONArray()
        arr.put(JSONObject().put("role", "system").put("content", system))
        msgs.forEach { (r, t) -> arr.put(JSONObject().put("role", if (r == "assistant") "assistant" else "user").put("content", t)) }
        val freeModels = listOf("openai-fast", "mistral", "openai")
        var lastErr = "сервер занят"
        for (m in freeModels) {
            try {
                val body = JSONObject()
                body.put("model", m)
                body.put("messages", arr)
                val (code, text) = post("https://text.pollinations.ai/openai", emptyMap(), body.toString())
                if (code !in 200..299) {
                    lastErr = "код $code"
                    continue
                }
                val out = try {
                    JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
                } catch (e: Exception) {
                    ""
                }
                if (out.isNotEmpty()) return out
                lastErr = "пустой ответ"
            } catch (e: Exception) {
                lastErr = e.message ?: "ошибка сети"
            }
        }
        throw Exception("бесплатные серверы сейчас перегружены ($lastErr). Добавьте бесплатный ключ Groq/Cerebras в настройках (шестерёнка)")
    }

    /** Ключ пользователя → встроенный ключ сборки → бесплатный сервер без ключа. */
    fun chat(
        userKey: String, model: String, system: String, msgs: List<Pair<String, String>>,
        maxTokens: Int = 4096, json: Boolean = false
    ): String {
        val k = userKey.trim().ifBlank { BuildConfig.GEMINI_KEY }
        return if (k.isNotBlank()) call(k, model, system, msgs, maxTokens, json) else callFree(system, msgs)
    }

    /** Любой OpenAI-совместимый сервис: .../chat/completions */
    fun openAi(c: AiConfig, system: String, msgs: List<Pair<String, String>>, maxTokens: Int): String {
        val base = c.baseUrl.trim().trimEnd('/')
        if (base.isBlank()) throw Exception("укажите адрес сервера в настройках")
        if (c.model.isBlank()) throw Exception("укажите модель в настройках")
        val arr = JSONArray()
        arr.put(JSONObject().put("role", "system").put("content", system))
        msgs.forEach { (r, t) ->
            arr.put(JSONObject().put("role", if (r == "assistant") "assistant" else "user").put("content", t))
        }
        val body = JSONObject()
        body.put("model", c.model.trim())
        body.put("messages", arr)
        body.put("max_tokens", maxTokens)
        val headers = HashMap<String, String>()
        if (c.key.isNotBlank()) headers["Authorization"] = "Bearer " + c.key.trim()
        if (base.contains("openrouter.ai")) {
            headers["HTTP-Referer"] = "https://github.com/MyCookbook"
            headers["X-Title"] = "MyCookbook"
        }
        val (code, text) = post(base + "/chat/completions", headers, body.toString())
        if (code !in 200..299) {
            val msg = try {
                JSONObject(text).getJSONObject("error").getString("message")
            } catch (e: Exception) {
                text.take(200)
            }
            throw Exception("$code: $msg")
        }
        val out = try {
            JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
        } catch (e: Exception) {
            ""
        }
        if (out.isEmpty()) throw Exception("пустой ответ сервера")
        return out
    }

    fun chatCfg(
        c: AiConfig, system: String, msgs: List<Pair<String, String>>,
        maxTokens: Int = 4096, json: Boolean = false
    ): String = when (c.provider) {
        "auto" -> {
            val attempts = ArrayList<() -> String>()
            if (BuildConfig.MISTRAL_KEY.isNotBlank()) {
                attempts.add {
                    openAi(
                        AiConfig("mistral", BuildConfig.MISTRAL_KEY, "mistral-small-latest", "https://api.mistral.ai/v1"),
                        system, msgs, maxTokens
                    )
                }
            }
            if (BuildConfig.OPENROUTER_KEY.isNotBlank()) {
                attempts.add {
                    openAi(
                        AiConfig("openrouter", BuildConfig.OPENROUTER_KEY, "meta-llama/llama-3.3-70b-instruct:free", "https://openrouter.ai/api/v1"),
                        system, msgs, maxTokens
                    )
                }
            }
            if (BuildConfig.CEREBRAS_KEY.isNotBlank()) {
                attempts.add {
                    openAi(
                        AiConfig("cerebras", BuildConfig.CEREBRAS_KEY, "llama-3.3-70b", "https://api.cerebras.ai/v1"),
                        system, msgs, maxTokens
                    )
                }
            }
            if (BuildConfig.GROQ_KEY.isNotBlank()) {
                attempts.add {
                    openAi(
                        AiConfig("groq", BuildConfig.GROQ_KEY, "llama-3.3-70b-versatile", "https://api.groq.com/openai/v1"),
                        system, msgs, maxTokens
                    )
                }
            }
            if (BuildConfig.GEMINI_KEY.isNotBlank()) {
                attempts.add { call(BuildConfig.GEMINI_KEY, "gemini-flash-latest", system, msgs, maxTokens, json) }
            }
            if (BuildConfig.SAMBANOVA_KEY.isNotBlank()) {
                attempts.add {
                    openAi(
                        AiConfig("sambanova", BuildConfig.SAMBANOVA_KEY, "Meta-Llama-3.3-70B-Instruct", "https://api.sambanova.ai/v1"),
                        system, msgs, maxTokens
                    )
                }
            }
            attempts.add { callFree(system, msgs) }
            var lastEx: Exception? = null
            var result: String? = null
            for (fn in attempts) {
                try {
                    result = fn()
                    break
                } catch (e: Exception) {
                    lastEx = e
                }
            }
            result ?: throw (lastEx ?: Exception("нет связи с сервером ИИ"))
        }
        "gemini" -> {
            if (c.key.isBlank()) throw Exception("введите бесплатный ключ Gemini в настройках (шестерёнка)")
            call(c.key, c.model.ifBlank { "gemini-flash-latest" }, system, msgs, maxTokens, json)
        }
        "pollinations_fast", "pollinations_mistral", "pollinations" -> {
            try {
                openAi(c, system, msgs, maxTokens)
            } catch (e: Exception) {
                callFree(system, msgs)
            }
        }
        else -> openAi(c, system, msgs, maxTokens)
    }

    fun chatCfgSmart(
        prefs: android.content.SharedPreferences,
        system: String,
        msgs: List<Pair<String, String>>,
        maxTokens: Int = 4096,
        json: Boolean = false
    ): String {
        val c = AiProviders.load(prefs)
        if (c.provider != "auto") {
            return try {
                chatCfg(c, system, msgs, maxTokens, json)
            } catch (e: Exception) {
                chatCfg(AiConfig("auto", "", "", ""), system, msgs, maxTokens, json)
            }
        }
        val attempts = ArrayList<() -> String>()
        val mk = AiProviders.effectiveKey(prefs, "mistral")
        if (mk.isNotBlank()) {
            attempts.add {
                openAi(AiConfig("mistral", mk, "mistral-small-latest", "https://api.mistral.ai/v1"), system, msgs, maxTokens)
            }
        }
        val ork = AiProviders.effectiveKey(prefs, "openrouter")
        if (ork.isNotBlank()) {
            attempts.add {
                openAi(AiConfig("openrouter", ork, "meta-llama/llama-3.3-70b-instruct:free", "https://openrouter.ai/api/v1"), system, msgs, maxTokens)
            }
        }
        val ck = AiProviders.effectiveKey(prefs, "cerebras")
        if (ck.isNotBlank()) {
            attempts.add {
                openAi(AiConfig("cerebras", ck, "llama-3.3-70b", "https://api.cerebras.ai/v1"), system, msgs, maxTokens)
            }
        }
        val gk = AiProviders.effectiveKey(prefs, "groq")
        if (gk.isNotBlank()) {
            attempts.add {
                openAi(AiConfig("groq", gk, "llama-3.3-70b-versatile", "https://api.groq.com/openai/v1"), system, msgs, maxTokens)
            }
        }
        val gemk = AiProviders.effectiveKey(prefs, "gemini")
        if (gemk.isNotBlank()) {
            attempts.add { call(gemk, "gemini-flash-latest", system, msgs, maxTokens, json) }
        }
        val sk = AiProviders.effectiveKey(prefs, "sambanova")
        if (sk.isNotBlank()) {
            attempts.add {
                openAi(AiConfig("sambanova", sk, "Meta-Llama-3.3-70B-Instruct", "https://api.sambanova.ai/v1"), system, msgs, maxTokens)
            }
        }
        attempts.add { callFree(system, msgs) }
        var lastEx: Exception? = null
        for (fn in attempts) {
            try {
                val res = fn()
                if (res.isNotBlank()) return res
            } catch (e: Exception) {
                lastEx = e
            }
        }
        throw (lastEx ?: Exception("нет связи с сервером ИИ"))
    }


    fun loadPreparedBitmap(
        ctx: Context,
        uri: android.net.Uri,
        maxDim: Int = 1600,
        extraRotationDeg: Int = 0,
        cropLeft: Float = 0f,
        cropTop: Float = 0f,
        cropRight: Float = 1f,
        cropBottom: Float = 1f,
        enhanceInk: Boolean = false
    ): android.graphics.Bitmap {
        val exifDeg = try {
            ctx.contentResolver.openInputStream(uri)?.use { stream ->
                val exif = android.media.ExifInterface(stream)
                when (exif.getAttributeInt(
                    android.media.ExifInterface.TAG_ORIENTATION,
                    android.media.ExifInterface.ORIENTATION_NORMAL
                )) {
                    android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90
                    android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180
                    android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270
                    else -> 0
                }
            } ?: 0
        } catch (e: Exception) {
            0
        }

        // Read bounds first to avoid OutOfMemoryError on high-MP phone camera photos
        val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use {
            android.graphics.BitmapFactory.decodeStream(it, null, bounds)
        }
        val cropFracW = (cropRight - cropLeft).coerceIn(0.15f, 1f)
        val cropFracH = (cropBottom - cropTop).coerceIn(0.15f, 1f)
        val needMax = (maxDim / minOf(cropFracW, cropFracH)).toInt().coerceAtMost(3200)
        var sample = 1
        val maxSide = maxOf(bounds.outWidth, bounds.outHeight)
        if (maxSide > 0) {
            while ((maxSide / sample) > needMax * 2) {
                sample *= 2
            }
        }
        val decodeOpts = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
        val decoded = ctx.contentResolver.openInputStream(uri)?.use {
            android.graphics.BitmapFactory.decodeStream(it, null, decodeOpts)
        } ?: throw Exception("не удалось прочитать изображение")

        val totalRot = ((exifDeg + extraRotationDeg) % 360 + 360) % 360
        val rotated = if (totalRot != 0) {
            val mat = android.graphics.Matrix().apply { postRotate(totalRot.toFloat()) }
            val rBmp = android.graphics.Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, mat, true)
            if (rBmp !== decoded) decoded.recycle()
            rBmp
        } else decoded

        // Apply normalized crop if user cropped the page
        val cl = cropLeft.coerceIn(0f, 0.9f)
        val ct = cropTop.coerceIn(0f, 0.9f)
        val cr = cropRight.coerceIn(cl + 0.1f, 1f)
        val cb = cropBottom.coerceIn(ct + 0.1f, 1f)
        val cropped = if (cl > 0.005f || ct > 0.005f || cr < 0.995f || cb < 0.995f) {
            val x = (rotated.width * cl).toInt().coerceIn(0, rotated.width - 1)
            val y = (rotated.height * ct).toInt().coerceIn(0, rotated.height - 1)
            val cw = (rotated.width * (cr - cl)).toInt().coerceIn(1, rotated.width - x)
            val ch = (rotated.height * (cb - ct)).toInt().coerceIn(1, rotated.height - y)
            val cBmp = android.graphics.Bitmap.createBitmap(rotated, x, y, cw, ch)
            if (cBmp !== rotated) rotated.recycle()
            cBmp
        } else rotated

        val w = cropped.width
        val h = cropped.height
        val scale = minOf(1f, maxDim.toFloat() / maxOf(w, h).coerceAtLeast(1))
        val scaled = if (scale < 1f) {
            val sBmp = android.graphics.Bitmap.createScaledBitmap(
                cropped,
                (w * scale).toInt().coerceAtLeast(1),
                (h * scale).toInt().coerceAtLeast(1),
                true
            )
            if (sBmp !== cropped) cropped.recycle()
            sBmp
        } else cropped

        if (!enhanceInk) return scaled

        // Contrast & clarity boost for paper/handwriting (makes pen ink dark & paper light)
        val out = android.graphics.Bitmap.createBitmap(
            scaled.width, scaled.height, android.graphics.Bitmap.Config.ARGB_8888
        )
        val canvas = android.graphics.Canvas(out)
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        val contrast = 1.38f
        val translate = (-0.5f * contrast + 0.5f) * 255f + 12f
        val cm = android.graphics.ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, translate,
                0f, contrast, 0f, 0f, translate,
                0f, 0f, contrast, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )
        )
        // Slight desaturation helps separate faint blue/pencil ink from yellow/lined paper
        val sat = android.graphics.ColorMatrix().apply { setSaturation(0.25f) }
        cm.postConcat(sat)
        paint.colorFilter = android.graphics.ColorMatrixColorFilter(cm)
        canvas.drawBitmap(scaled, 0f, 0f, paint)
        scaled.recycle()
        return out
    }

    fun compressBitmapToBase64(
        bmp: android.graphics.Bitmap,
        initialQuality: Int = 86,
        maxBytes: Int = 880 * 1024
    ): String {
        var q = initialQuality.coerceIn(55, 95)
        var bytes = ByteArray(0)
        while (true) {
            val baos = java.io.ByteArrayOutputStream()
            bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, q, baos)
            bytes = baos.toByteArray()
            if (bytes.size <= maxBytes || q <= 55) break
            q -= 10
        }
        return android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
    }

    fun encodeBitmapToBase64(
        ctx: Context,
        uri: android.net.Uri,
        maxDim: Int = 1024,
        quality: Int = 78,
        extraRotationDeg: Int = 0
    ): String {
        val bmp = loadPreparedBitmap(ctx, uri, maxDim = maxDim, extraRotationDeg = extraRotationDeg)
        return try {
            compressBitmapToBase64(bmp, initialQuality = quality, maxBytes = 880 * 1024)
        } finally {
            bmp.recycle()
        }
    }

    fun isVisionRefusal(text: String): Boolean {
        val low = text.lowercase().trim()
        if (low.length < 4) return true
        val refusalMarkers = listOf(
            "я не могу просматривать",
            "не могу просматривать изображ",
            "не могу увидеть изображ",
            "не вижу изображ",
            "не имею доступа к изображ",
            "не могу обработать изображ",
            "я текстовая модель",
            "как текстовая модель",
            "i cannot see",
            "i can't see",
            "i cannot view",
            "i can't view",
            "cannot process images",
            "unable to view",
            "please provide the text",
            "sorry, i can't assist",
            "i'm sorry, i cannot"
        )
        return refusalMarkers.any { low.contains(it) }
    }

    fun callVisionGemini(
        key: String,
        model: String,
        system: String,
        prompt: String,
        imageBase64: String,
        maxTokens: Int = 3072,
        temperature: Double = 0.1
    ): String {
        val body = JSONObject()
        val sysParts = JSONArray()
        sysParts.put(JSONObject().put("text", system))
        body.put("systemInstruction", JSONObject().put("parts", sysParts))
        val parts = JSONArray()
        parts.put(JSONObject().put("text", prompt))
        parts.put(
            JSONObject().put(
                "inlineData",
                JSONObject().put("mimeType", "image/jpeg").put("data", imageBase64)
            )
        )
        val contents = JSONArray()
        contents.put(JSONObject().put("role", "user").put("parts", parts))
        body.put("contents", contents)
        body.put(
            "generationConfig",
            JSONObject()
                .put("maxOutputTokens", maxTokens)
                .put("temperature", temperature)
        )

        val (code, text) = post(
            "https://generativelanguage.googleapis.com/v1beta/models/" + model.trim() + ":generateContent",
            mapOf("x-goog-api-key" to key.trim()),
            body.toString()
        )
        if (code !in 200..299) {
            val msg = try {
                JSONObject(text).getJSONObject("error").getString("message")
            } catch (e: Exception) {
                text.take(200)
            }
            throw Exception("$code: $msg")
        }
        val cand = JSONObject(text).optJSONArray("candidates")
        val resParts = cand?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (resParts != null) {
            for (i in 0 until resParts.length()) {
                val part = resParts.getJSONObject(i)
                if (!part.optBoolean("thought", false)) sb.append(part.optString("text"))
            }
        }
        val out = sb.toString().trim()
        if (out.isEmpty() || isVisionRefusal(out)) throw Exception("ИИ не смог прочитать изображение")
        return out
    }

    fun openAiVision(
        c: AiConfig,
        system: String,
        prompt: String,
        imageBase64: String,
        maxTokens: Int = 3072,
        temperature: Double = 0.1
    ): String {
        val base = c.baseUrl.trim().trimEnd('/')
        if (base.isBlank()) throw Exception("укажите адрес сервера в настройках")
        if (c.model.isBlank()) throw Exception("укажите модель в настройках")
        val arr = JSONArray()
        arr.put(JSONObject().put("role", "system").put("content", system))
        val userContent = JSONArray()
        userContent.put(JSONObject().put("type", "text").put("text", prompt))
        userContent.put(
            JSONObject()
                .put("type", "image_url")
                .put(
                    "image_url",
                    JSONObject()
                        .put("url", "data:image/jpeg;base64,$imageBase64")
                        .put("detail", "high")
                )
        )
        arr.put(JSONObject().put("role", "user").put("content", userContent))
        val body = JSONObject()
        body.put("model", c.model.trim())
        body.put("messages", arr)
        body.put("max_tokens", maxTokens)
        body.put("temperature", temperature)
        val headers = HashMap<String, String>()
        if (c.key.isNotBlank()) headers["Authorization"] = "Bearer " + c.key.trim()
        if (base.contains("openrouter.ai")) {
            headers["HTTP-Referer"] = "https://github.com/MyCookbook"
            headers["X-Title"] = "MyCookbook"
        }
        val (code, text) = post(base + "/chat/completions", headers, body.toString())
        if (code !in 200..299) {
            val msg = try {
                JSONObject(text).getJSONObject("error").getString("message")
            } catch (e: Exception) {
                text.take(200)
            }
            throw Exception("$code: $msg")
        }
        val out = try {
            JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
        } catch (e: Exception) {
            ""
        }
        if (out.isEmpty() || isVisionRefusal(out)) throw Exception("модель не распознала изображение")
        return out
    }

    private fun callAutoVision(
        system: String,
        prompt: String,
        imageBase64: String,
        maxTokens: Int,
        prefs: android.content.SharedPreferences? = null
    ): String {
        val attempts = ArrayList<() -> String>()
        val mistralKey = AiProviders.effectiveKey(prefs, "mistral")
        if (mistralKey.isNotBlank()) {
            attempts.add {
                openAiVision(
                    AiConfig("mistral", mistralKey, "mistral-small-latest", "https://api.mistral.ai/v1"),
                    system, prompt, imageBase64, maxTokens
                )
            }
            attempts.add {
                openAiVision(
                    AiConfig("mistral", mistralKey, "pixtral-12b-2409", "https://api.mistral.ai/v1"),
                    system, prompt, imageBase64, maxTokens
                )
            }
        }
        val openRouterKey = AiProviders.effectiveKey(prefs, "openrouter")
        if (openRouterKey.isNotBlank()) {
            attempts.add {
                openAiVision(
                    AiConfig("openrouter", openRouterKey, "qwen/qwen2.5-vl-72b-instruct:free", "https://openrouter.ai/api/v1"),
                    system, prompt, imageBase64, maxTokens
                )
            }
            attempts.add {
                openAiVision(
                    AiConfig("openrouter", openRouterKey, "google/gemma-3-27b-it:free", "https://openrouter.ai/api/v1"),
                    system, prompt, imageBase64, maxTokens
                )
            }
            attempts.add {
                openAiVision(
                    AiConfig("openrouter", openRouterKey, "mistralai/mistral-small-3.1-24b-instruct:free", "https://openrouter.ai/api/v1"),
                    system, prompt, imageBase64, maxTokens
                )
            }
        }
        val geminiKey = AiProviders.effectiveKey(prefs, "gemini")
        if (geminiKey.isNotBlank()) {
            attempts.add {
                callVisionGemini(geminiKey, "gemini-flash-latest", system, prompt, imageBase64, maxTokens)
            }
        }
        val groqKey = AiProviders.effectiveKey(prefs, "groq")
        if (groqKey.isNotBlank()) {
            attempts.add {
                openAiVision(
                    AiConfig("groq", groqKey, "meta-llama/llama-4-scout-17b-16e-instruct", "https://api.groq.com/openai/v1"),
                    system, prompt, imageBase64, maxTokens
                )
            }
        }
        attempts.add {
            openAiVision(
                AiConfig("pollinations", "", "openai", "https://text.pollinations.ai/openai"),
                system, prompt, imageBase64, maxTokens
            )
        }
        attempts.add {
            openAiVision(
                AiConfig("pollinations_fast", "", "openai-fast", "https://text.pollinations.ai/openai"),
                system, prompt, imageBase64, maxTokens
            )
        }
        var lastEx: Exception? = null
        for (fn in attempts) {
            try {
                val res = fn()
                if (res.isNotBlank() && !isVisionRefusal(res)) return res
            } catch (e: Exception) {
                lastEx = e
            }
        }
        throw (lastEx ?: Exception("не удалось распознать фото"))
    }

    fun chatWithImageCfg(
        c: AiConfig,
        system: String,
        prompt: String,
        imageBase64: String,
        maxTokens: Int = 3072,
        prefs: android.content.SharedPreferences? = null
    ): String = when (c.provider) {
        "auto" -> callAutoVision(system, prompt, imageBase64, maxTokens, prefs)
        "mistral" -> {
            val k = c.key.ifBlank { AiProviders.effectiveKey(prefs, "mistral") }
            if (k.isBlank()) {
                callAutoVision(system, prompt, imageBase64, maxTokens, prefs)
            } else {
                try {
                    openAiVision(c.copy(key = k), system, prompt, imageBase64, maxTokens)
                } catch (e: Exception) {
                    try {
                        openAiVision(c.copy(key = k, model = "pixtral-12b-2409"), system, prompt, imageBase64, maxTokens)
                    } catch (e2: Exception) {
                        callAutoVision(system, prompt, imageBase64, maxTokens, prefs)
                    }
                }
            }
        }
        "gemini" -> {
            val k = c.key.ifBlank { AiProviders.effectiveKey(prefs, "gemini") }
            if (k.isBlank()) throw Exception("введите ключ Gemini в настройках (шестерёнка)")
            callVisionGemini(k, c.model.ifBlank { "gemini-flash-latest" }, system, prompt, imageBase64, maxTokens)
        }
        "openrouter" -> {
            val k = c.key.ifBlank { AiProviders.effectiveKey(prefs, "openrouter") }
            val candidates = listOf(
                if (c.model.contains("llama-3.3") || c.model.contains("llama-3.1")) "qwen/qwen2.5-vl-72b-instruct:free" else c.model,
                "qwen/qwen2.5-vl-72b-instruct:free",
                "google/gemma-3-27b-it:free",
                "mistralai/mistral-small-3.1-24b-instruct:free"
            ).distinct()
            var lastErr: Exception? = null
            var ok: String? = null
            if (k.isNotBlank()) {
                for (m in candidates) {
                    try {
                        ok = openAiVision(c.copy(key = k, model = m), system, prompt, imageBase64, maxTokens)
                        break
                    } catch (e: Exception) {
                        lastErr = e
                    }
                }
            }
            ok ?: try {
                callAutoVision(system, prompt, imageBase64, maxTokens, prefs)
            } catch (e: Exception) {
                throw (lastErr ?: e)
            }
        }
        "groq", "groq_fast" -> {
            val k = c.key.ifBlank { AiProviders.effectiveKey(prefs, "groq") }
            if (k.isBlank()) {
                callAutoVision(system, prompt, imageBase64, maxTokens, prefs)
            } else {
                try {
                    openAiVision(
                        c.copy(key = k, model = "meta-llama/llama-4-scout-17b-16e-instruct"),
                        system, prompt, imageBase64, maxTokens
                    )
                } catch (e: Exception) {
                    callAutoVision(system, prompt, imageBase64, maxTokens, prefs)
                }
            }
        }
        "cerebras", "sambanova", "pollinations_mistral" -> {
            callAutoVision(system, prompt, imageBase64, maxTokens, prefs)
        }
        "pollinations_fast", "pollinations" -> {
            try {
                openAiVision(AiConfig("pollinations", "", "openai", "https://text.pollinations.ai/openai"), system, prompt, imageBase64, maxTokens)
            } catch (e: Exception) {
                openAiVision(AiConfig("pollinations_fast", "", "openai-fast", "https://text.pollinations.ai/openai"), system, prompt, imageBase64, maxTokens)
            }
        }
        else -> openAiVision(c, system, prompt, imageBase64, maxTokens)
    }

    fun ocrHandwritingSystem(handwriting: Boolean): String = if (handwriting) {
        "Ты — профессиональный эксперт по расшифровке РУКОПИСНЫХ кулинарных рецептов на русском языке (тетради, блокноты, бабушкины записки, листки). " +
            "Твоя задача — максимально точно и бережно переписать весь текст рецепта с фотографии.\n" +
            "Правила:\n" +
            "1. Внимательно читай рукописный курсив, слитные буквы, помарки и записи на полях.\n" +
            "2. Сохраняй все точные цифры, дроби (1/2, 0,5, 1,5) и меры (г, кг, мл, л, шт, ст.л., ч.л., стакан, щепотка, по вкусу).\n" +
            "3. Расшифровывай сокращения понятно (например: ст.л., ч.л., шт., мин, °C).\n" +
            "4. Если отдельные буквы смазаны, восстанавливай слово по кулинарному смыслу, НЕ придумывая лишних продуктов.\n" +
            "5. Верни ТОЛЬКО аккуратно структурированный текст рецепта на русском (Название, Ингредиенты, Приготовление, Советы/Заметки), без своих вступлений вроде «Вот текст с фото»."
    } else {
        "Ты — точный OCR-сканер кулинарных рецептов на русском языке (книги, журналы, распечатки, скриншоты). " +
            "Перепиши весь текст рецепта с изображения точно, сохраняя все числа, пропорции, ингредиенты, шаги и температуру. " +
            "Верни ТОЛЬКО текст рецепта без лишних комментариев и вступлений."
    }

    fun recipeJsonSystem(): String =
        "Преобразуй присланный текст в структурированный рецепт на русском языке. Верни ТОЛЬКО один JSON-объект без пояснений и без markdown. " +
            "Поля: title (строка), description (строка), servings (целое, по умолчанию 4), timeMin (целое, минуты, 0 если не указано), tempC (целое, °C, 0 если не нужна), " +
            "category (целое: 0 завтраки, 1 супы, 2 основные блюда, 3 салаты, 4 закуски, 5 выпечка, 6 десерты, 7 напитки, 8 консервация), " +
            "ingredients (массив объектов name, amount число, unit одно из: г, кг, мл, л, шт, ст.л., ч.л., стакан, щепотка, по вкусу), " +
            "steps (массив строк с понятными шагами), secrets (строка с советами/заметками автора или пустая)."

    fun parseRecipeJson(raw: String): ParsedRecipe? {
        val cleaned = raw
            .replace(Regex("```(?:json)?", RegexOption.IGNORE_CASE), "")
            .replace("```", "")
            .trim()
        val a = cleaned.indexOf('{')
        val b = cleaned.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        val o = try {
            JSONObject(cleaned.substring(a, b + 1))
        } catch (e: Exception) {
            return null
        }
        val title = o.optString("title").trim()
        if (title.isEmpty()) return null
        val ings = ArrayList<Ingredient>()
        val ia = o.optJSONArray("ingredients")
        if (ia != null) {
            for (i in 0 until ia.length()) {
                val elem = ia.opt(i) ?: continue
                if (elem is String) {
                    val s = elem.trim()
                    if (s.isNotEmpty()) ings.add(Ingredient(s, 0.0, ""))
                } else if (elem is JSONObject) {
                    val name = elem.optString("name").trim()
                    if (name.isEmpty()) continue
                    val rawAmt = elem.opt("amount")
                    val amt = when (rawAmt) {
                        is Number -> rawAmt.toDouble().let { if (it.isNaN() || it.isInfinite()) 0.0 else it }
                        is String -> parseNum(rawAmt)
                        else -> 0.0
                    }
                    val rawUnit = elem.optString("unit").trim().lowercase()
                    val unit = when {
                        rawUnit in UNITS -> rawUnit
                        rawUnit == "гр" || rawUnit == "гр." || rawUnit == "г." -> "г"
                        rawUnit == "кг." -> "кг"
                        rawUnit == "мл." -> "мл"
                        rawUnit == "л." -> "л"
                        rawUnit == "шт." -> "шт"
                        rawUnit.startsWith("ст") && rawUnit.contains("л") -> "ст.л."
                        rawUnit.startsWith("ч") && rawUnit.contains("л") -> "ч.л."
                        rawUnit.startsWith("стак") -> "стакан"
                        rawUnit.startsWith("щеп") -> "щепотка"
                        rawUnit.contains("вкус") -> "по вкусу"
                        else -> ""
                    }
                    ings.add(Ingredient(name, amt, unit))
                }
            }
        }
        val steps = ArrayList<String>()
        val sa = o.optJSONArray("steps")
        if (sa != null) {
            for (i in 0 until sa.length()) {
                val elem = sa.opt(i) ?: continue
                val s = when (elem) {
                    is String -> elem.trim()
                    is JSONObject -> elem.optString("text").ifBlank { elem.optString("step") }.trim()
                    else -> ""
                }
                if (s.isNotEmpty()) steps.add(s)
            }
        }
        if (ings.isEmpty() && steps.isEmpty()) return null
        return ParsedRecipe(
            title = title,
            description = o.optString("description").trim(),
            servings = o.optInt("servings", 4).let { if (it in 1..99) it else 4 },
            timeMin = o.optInt("timeMin", 0).coerceAtLeast(0),
            tempC = o.optInt("tempC", 0).coerceAtLeast(0),
            ingredients = ings,
            steps = steps,
            imageUrl = null,
            sourceUrl = "ИИ-помощник",
            category = o.optInt("category", 2).coerceIn(0, CATEGORIES.size - 1),
            secrets = o.optString("secrets").trim()
        )
    }
}

data class AiAction(
    val type: String,
    val date: String = "",
    val slot: Int = 1,
    val recipeId: String = "",
    val name: String = "",
    val amount: Double = 0.0,
    val unit: String = "",
    val servings: Int = 0
)

data class Msg(
    val role: String,
    val text: String,
    val raw: String,
    val actions: List<AiAction> = emptyList(),
    val planDone: Boolean = false,
    val shopDone: Boolean = false
)

object AiActions {
    private val re = Regex("<actions>(.*?)</actions>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))

    fun extract(raw: String): Pair<String, List<AiAction>> {
        val m = re.find(raw)
        if (m == null) {
            val idx = raw.indexOf("<actions>", ignoreCase = true)
            return (if (idx >= 0) raw.substring(0, idx) else raw).trim() to emptyList()
        }
        val clean = raw.replace(re, "").trim()
        val body = m.groupValues[1].trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val out = ArrayList<AiAction>()
        try {
            val arr = JSONArray(body)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val amount = o.optDouble("amount", 0.0)
                out.add(
                    AiAction(
                        type = o.optString("type"),
                        date = o.optString("date"),
                        slot = o.optInt("slot", 1),
                        recipeId = o.optString("recipeId"),
                        name = o.optString("name"),
                        amount = if (amount.isNaN()) 0.0 else amount,
                        unit = o.optString("unit"),
                        servings = o.optInt("servings", 0)
                    )
                )
            }
        } catch (e: Exception) {
        }
        return clean to out
    }

    fun systemPrompt(store: CookbookStore, rid: String): String {
        val today = java.time.LocalDate.now()
        val ru = Locale("ru")
        val monday = today.with(java.time.DayOfWeek.MONDAY)
        val week = (0..6).joinToString(", ") {
            val d = monday.plusDays(it.toLong())
            d.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, ru) + " " + d
        }
        val todayName = today.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, ru)
        val catalog = if (rid.isNotEmpty()) {
            ""
        } else {
            val picked = (store.recipes.filter { !it.id.startsWith("world-") } +
                store.recipes.filter { it.favorite } +
                store.recipes).distinctBy { it.id }.take(90)
            picked.joinToString("; ") { it.id + ":" + it.title }
        }
        var s = "Ты — весёлый, дружелюбный кулинарный помощник-мышонок по имени Рататуй в приложении «MyCookbook». " +
            "Отвечай по-русски, коротко и по делу, можно с лёгким юмором. " +
            "Указывай граммовки, время и температуру, предлагай замены продуктов.\n\n" +
            "Сегодня: " + today + " (" + todayName + "). Текущая неделя: " + week + ".\n\n" +
            "Каталог рецептов пользователя (id | название | кухня | категория):\n" + catalog + "\n\n" +
            "ДЕЙСТВИЯ. Если пользователь просит составить меню или рацион, запланировать блюда, что-то приготовить в определённый день или купить продукты, " +
            "ответь обычным текстом, а в самом конце добавь блок действий строго в таком виде:\n" +
            "<actions>\n[{\"type\":\"plan\",\"date\":\"ГГГГ-ММ-ДД\",\"slot\":1,\"recipeId\":\"id из каталога\"}]\n</actions>\n" +
            "Типы действий:\n" +
            "- plan: добавить блюдо в план питания. slot: 0 завтрак, 1 обед, 2 ужин. recipeId — только из каталога выше.\n" +
            "- shop: добавить продукт в список покупок: {\"type\":\"shop\",\"name\":\"курица\",\"amount\":500,\"unit\":\"г\"} (unit: г, кг, мл, л, шт, ст.л., ч.л.).\n" +
            "- shop_recipe: добавить все продукты рецепта из каталога: {\"type\":\"shop_recipe\",\"recipeId\":\"id\",\"servings\":4}.\n" +
            "- open: показать рецепт: {\"type\":\"open\",\"recipeId\":\"id\"}.\n" +
            "Правила: для меню на неделю распределяй разные блюда из каталога по дням (завтрак — из завтраков, обед — супы и основные, ужин — основные и салаты) и используй даты текущей недели. " +
            "Если подходящего блюда в каталоге нет, предложи его текстом и добавь нужные продукты действиями shop. " +
            "Внутри блока только JSON без пояснений. Если действий не нужно, блок не добавляй."
        val r = if (rid.isNotEmpty()) store.recipe(rid) else null
        if (r != null) {
            s += "\n\nПользователь сейчас смотрит свой рецепт «" + r.title + "» (id " + r.id + "). Порций: " + r.servings + ". Ингредиенты: " +
                r.ingredients.joinToString("; ") { it.name + " " + ingredientLine(it, 1.0) } +
                ". Шаги: " + r.steps.mapIndexed { i, st -> (i + 1).toString() + ") " + st.text }.joinToString(" ") +
                (if (r.notes.isNotBlank()) ". Заметки: " + r.notes else "")
        }
        return s
    }
}

@Composable
fun AiScreen(store: CookbookStore, nav: NavHostController, rid: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("cookbook_prefs", Context.MODE_PRIVATE) }
    var cfg by remember { mutableStateOf(AiProviders.load(prefs)) }
    var showSettings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf<Msg>() }
    val listState = rememberLazyListState()
    var phraseIdx by remember { mutableIntStateOf(0) }
    val phrases = remember {
        listOf(
            "Взбиваю мысли венчиком…",
            "Жонглирую яйцами…",
            "Листаю вашу книгу рецептов…",
            "Пробую соус на соль…",
            "Ищу, куда спрятался базилик…",
            "Разогреваю нейроны на среднем огне…"
        )
    }
    val recipe = if (rid.isNotEmpty()) store.recipe(rid) else null

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_LONG).show()

    fun send(text: String) {
        val t = text.trim()
        if (busy || t.isEmpty()) return
        messages.add(Msg("user", t, t))
        input = ""
        scope.launch {
            busy = true
            try {
                val system = AiActions.systemPrompt(store, rid)
                val history = messages.toList().takeLast(20).dropWhile { it.role != "user" }.map { it.role to it.raw }
                val reply = withContext(Dispatchers.IO) { AiClient.chatCfg(cfg, system, history) }
                val (clean, acts) = AiActions.extract(reply)
                messages.add(Msg("assistant", clean, reply, acts))
            } catch (e: Exception) {
                messages.removeAt(messages.lastIndex)
                input = t
                toast("Ошибка ИИ: " + (e.message ?: "нет связи"))
            }
            busy = false
        }
    }

    fun toBook(text: String) {
        if (busy) return
        scope.launch {
            busy = true
            try {
                val raw = withContext(Dispatchers.IO) {
                    AiClient.chatCfg(cfg, AiClient.recipeJsonSystem(), listOf("user" to text), 4096, true)
                }
                val p = AiClient.parseRecipeJson(raw)
                if (p == null) {
                    toast("Не удалось оформить рецепт. Попробуйте попросить ИИ написать рецепт полностью.")
                } else {
                    val id = WebImport.addToBook(ctx, store, p)
                    toast("Добавлено в книгу")
                    nav.navigate("recipe/$id")
                }
            } catch (e: Exception) {
                toast("Ошибка ИИ: " + (e.message ?: "нет связи"))
            }
            busy = false
        }
    }

    fun applyPlan(i: Int) {
        val m = messages[i]
        var n = 0
        for (a in m.actions) {
            if (a.type != "plan") continue
            val r = store.recipe(a.recipeId)
            val d = try {
                java.time.LocalDate.parse(a.date)
            } catch (e: Exception) {
                null
            }
            if (r != null && d != null && a.slot in 0..2) {
                store.setPlan(d.toString(), a.slot, r.id)
                n++
            }
        }
        messages[i] = m.copy(planDone = true)
        toast(if (n > 0) "В план питания добавлено блюд: $n" else "Не нашёл подходящих блюд в книге")
    }

    fun applyShop(i: Int) {
        val m = messages[i]
        var n = 0
        for (a in m.actions) {
            if (a.type == "shop" && a.name.isNotBlank()) {
                store.addShop(a.name, a.amount, a.unit)
                n++
            } else if (a.type == "shop_recipe") {
                val r = store.recipe(a.recipeId)
                if (r != null) {
                    store.addShopRecipe(r, if (a.servings > 0) a.servings else r.servings)
                    n++
                }
            }
        }
        messages[i] = m.copy(shopDone = true)
        toast(if (n > 0) "В список покупок добавлено: $n" else "Нечего добавлять")
    }

    LaunchedEffect(busy) {
        while (busy) {
            delay(1700)
            phraseIdx++
        }
    }
    LaunchedEffect(messages.size, busy) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (recipe != null) "ИИ: " + recipe.title else "ИИ-помощник", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } },
                actions = {
                    IconButton(onClick = { nav.navigate("shopping") }) { Icon(Icons.Filled.ShoppingCart, "Список покупок") }
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Filled.Settings, "Настройки ИИ") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().imePadding()) {
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                LiveChef(Modifier.size(width = 64.dp, height = 100.dp), busy = busy, cheer = messages.size)
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(10.dp)
                ) {
                    Text(
                        if (busy) phrases[phraseIdx % phrases.size]
                        else "Привет! Я Рататуй. Скажите, что приготовить, и я запланирую блюда и составлю список покупок!",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(),
                state = listState,
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (messages.isEmpty()) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (cfg.provider == "auto") {
                                Text(
                                    "Помощник работает без настройки. Для более быстрых и стабильных ответов добавьте свой бесплатный ключ (значок шестерёнки).",
                                    color = MaterialTheme.colorScheme.primary,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            val ideas = if (recipe != null) listOf(
                                "Чем можно заменить ингредиенты в этом рецепте?",
                                "Запланируй это блюдо на субботу и добавь продукты в список покупок",
                                "Предложи, с чем подать это блюдо"
                            ) else listOf(
                                "Составь меню на неделю из моей книги и запланируй его",
                                "Хочу приготовить паэлью в субботу, добавь в план и в список покупок",
                                "Что купить для борща?",
                                "Чем заменить сливки?"
                            )
                            ideas.forEach { idea ->
                                AssistChip(onClick = { send(idea) }, label = { Text(idea) })
                            }
                        }
                    }
                }
                items(messages.size) { i ->
                    val m = messages[i]
                    val mine = m.role == "user"
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
                        Box(
                            Modifier
                                .widthIn(max = 320.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                                .padding(12.dp)
                        ) {
                            Text(m.text, color = if (mine) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface)
                        }
                        if (!mine) {
                            val planCount = m.actions.count { it.type == "plan" }
                            val shopCount = m.actions.count { it.type == "shop" || it.type == "shop_recipe" }
                            val open = m.actions.firstOrNull { it.type == "open" && store.recipe(it.recipeId) != null }
                            if (planCount > 0 || shopCount > 0 || open != null) {
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    if (planCount > 0) {
                                        FilledTonalButton(onClick = { applyPlan(i) }, enabled = !m.planDone, contentPadding = PaddingValues(horizontal = 12.dp)) {
                                            Text(if (m.planDone) "✅ В плане" else "📅 В план ($planCount)")
                                        }
                                    }
                                    if (shopCount > 0) {
                                        FilledTonalButton(onClick = { applyShop(i) }, enabled = !m.shopDone, contentPadding = PaddingValues(horizontal = 12.dp)) {
                                            Text(if (m.shopDone) "✅ В списке" else "🛒 В список ($shopCount)")
                                        }
                                    }
                                    if (open != null) {
                                        OutlinedButton(onClick = { nav.navigate("recipe/" + open.recipeId) }, contentPadding = PaddingValues(horizontal = 12.dp)) {
                                            Text("📖 Открыть рецепт")
                                        }
                                    }
                                }
                            }
                            TextButton(onClick = { toBook(m.text) }, enabled = !busy) {
                                Icon(Icons.Filled.Add, null, Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Сохранить как рецепт")
                            }
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    placeholder = { Text("Что приготовить?") },
                    maxLines = 4,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { send(input) }, enabled = !busy && input.isNotBlank()) {
                    Icon(Icons.AutoMirrored.Filled.Send, "Отправить", tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }

    if (showSettings) {
        AiSettingsDialog(
            cfg = cfg,
            onSave = {
                cfg = it
                AiProviders.save(prefs, it)
                showSettings = false
            },
            onDismiss = { showSettings = false }
        )
    }
}

@Composable
fun AiSettingsDialog(cfg: AiConfig, onSave: (AiConfig) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = ctx.getSharedPreferences("cookbook_prefs", Context.MODE_PRIVATE)
    var prov by remember { mutableStateOf(cfg.provider) }
    var key by remember { mutableStateOf(cfg.key) }
    var model by remember { mutableStateOf(cfg.model) }
    var base by remember { mutableStateOf(cfg.baseUrl) }
    var open by remember { mutableStateOf(false) }
    var testing by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf("") }
    val inf = AiProviders.info(prov)

    val builtIn = remember {
        listOfNotNull(
            if (BuildConfig.MISTRAL_KEY.isNotBlank()) "Mistral (без VPN)" else null,
            if (BuildConfig.OPENROUTER_KEY.isNotBlank()) "OpenRouter (без VPN)" else null,
            if (BuildConfig.CEREBRAS_KEY.isNotBlank()) "Cerebras" else null,
            if (BuildConfig.GROQ_KEY.isNotBlank()) "Groq" else null,
            if (BuildConfig.GEMINI_KEY.isNotBlank()) "Gemini" else null,
            if (BuildConfig.SAMBANOVA_KEY.isNotBlank()) "SambaNova" else null
        )
    }

    fun pick(id: String) {
        val c = AiProviders.loadFor(prefs, id)
        prov = id
        key = c.key
        model = c.model
        base = c.baseUrl
        testResult = ""
    }

    fun currentCfg(): AiConfig =
        AiConfig(prov, key.trim(), model.trim().ifBlank { inf.model }, base.trim().ifBlank { inf.baseUrl })

    fun runSpeedTest() {
        if (testing) return
        scope.launch {
            testing = true
            testResult = "Проверяю скорость…"
            val t0 = System.currentTimeMillis()
            try {
                val ans = withContext(Dispatchers.IO) {
                    AiClient.chatCfg(
                        currentCfg(),
                        "Ответь одним словом по-русски.",
                        listOf("user" to "Скажи: Готово"),
                        maxTokens = 32
                    )
                }
                val sec = (System.currentTimeMillis() - t0) / 1000.0
                testResult = String.format(Locale.US, "✅ Ответ за %.1f сек: %s", sec, ans.take(40))
            } catch (e: Exception) {
                testResult = "❌ " + (e.message ?: "нет связи")
            }
            testing = false
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Настройки ИИ") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box {
                    OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(inf.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                        AiProviders.list.forEach { p ->
                            DropdownMenuItem(text = { Text(p.title) }, onClick = { open = false; pick(p.id) })
                        }
                    }
                }
                Text(inf.hint, style = MaterialTheme.typography.bodySmall)
                if (prov == "auto") {
                    Text(
                        if (builtIn.isNotEmpty()) "В сборку вшиты ключи: " + builtIn.joinToString(", ")
                        else "Сейчас работают бесплатные серверы без ключа. Для быстрой работы без VPN добавьте бесплатный ключ Mistral AI (console.mistral.ai) здесь или в Secrets на GitHub (MISTRAL_KEY).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                if (!AiProviders.isKeyless(prov)) {
                    OutlinedTextField(
                        key, { key = it },
                        label = { Text(if (prov == "custom") "Ключ (если нужен)" else "Бесплатный ключ API") },
                        singleLine = true,
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (prov != "auto") {
                    OutlinedTextField(model, { model = it }, label = { Text("Модель") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                if (prov != "auto" && prov != "gemini" && !prov.startsWith("pollinations")) {
                    OutlinedTextField(base, { base = it }, label = { Text("Адрес сервера (…/v1)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                FilledTonalButton(
                    onClick = { runSpeedTest() },
                    enabled = !testing,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (testing) "Проверяю…" else "⚡ Проверить скорость")
                }
                if (testResult.isNotBlank()) {
                    Text(
                        testResult,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (testResult.startsWith("✅")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Text("Ключ хранится только на этом телефоне.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(currentCfg()) }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}


// Added for Fridge recipe generation
fun generateRecipeFromIngredientsHelper(ingredients: String, onResult: (String) -> Unit) {
    val prompt = "Придумай вкусное блюдо из следующих ингредиентов: $ingredients. Выведи результат в формате JSON: { 'title': '...', 'prep_time': '...', 'ingredients': [], 'steps': [] }"
    // This calls your existing AI infrastructure. For now we mock the callback.
    onResult("Mock Recipe for: $ingredients")
}
