@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

data class AiConfig(val provider: String, val key: String, val model: String, val baseUrl: String)

class AiProviderInfo(
    val id: String, val title: String, val baseUrl: String, val model: String, val hint: String
)

object AiProviders {
    val list = listOf(
        AiProviderInfo("auto", "Авто (без настройки)", "", "", "Работает сразу: встроенный ключ сборки, а если его нет, бесплатный общий сервер."),
        AiProviderInfo("gemini", "Google Gemini", "", "gemini-flash-latest", "Бесплатный ключ: aistudio.google.com → Get API key."),
        AiProviderInfo("openrouter", "OpenRouter", "https://openrouter.ai/api/v1", "meta-llama/llama-3.3-70b-instruct:free", "Ключ на openrouter.ai. Бесплатные модели помечены :free, актуальный список смотрите на сайте и вставьте название в поле «Модель»."),
        AiProviderInfo("groq", "Groq", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile", "Бесплатный ключ: console.groq.com."),
        AiProviderInfo("mistral", "Mistral", "https://api.mistral.ai/v1", "mistral-small-latest", "Ключ: console.mistral.ai (есть бесплатный тариф)."),
        AiProviderInfo("pollinations", "Pollinations (без ключа)", "https://text.pollinations.ai/openai", "openai", "Бесплатный сервер без регистрации. Возможны ограничения по частоте."),
        AiProviderInfo("custom", "Свой сервер (OpenAI-совместимый)", "", "", "Любой сервис с адресом вида …/v1: Ollama, LM Studio, свой прокси. Укажите адрес, модель и ключ (если нужен).")
    )

    fun info(id: String): AiProviderInfo = list.firstOrNull { it.id == id } ?: list[0]

    fun loadFor(p: android.content.SharedPreferences, id: String): AiConfig {
        val inf = info(id)
        val legacyKey = if (id == "gemini") (p.getString("gemini_key", "") ?: "") else ""
        val legacyModel = if (id == "gemini") p.getString("gemini_model", null) else null
        val key = p.getString("ai_key_" + id, null) ?: legacyKey
        val model = p.getString("ai_model_" + id, null) ?: legacyModel ?: inf.model
        val base = p.getString("ai_base_" + id, null) ?: inf.baseUrl
        return AiConfig(id, key, model, base)
    }

    fun load(p: android.content.SharedPreferences): AiConfig {
        val id = p.getString("ai_provider", null)
            ?: if (!p.getString("gemini_key", "").isNullOrBlank()) "gemini" else "auto"
        return loadFor(p, id)
    }

    fun save(p: android.content.SharedPreferences, c: AiConfig) {
        p.edit()
            .putString("ai_provider", c.provider)
            .putString("ai_key_" + c.provider, c.key)
            .putString("ai_model_" + c.provider, c.model)
            .putString("ai_base_" + c.provider, c.baseUrl)
            .apply()
    }
}

object AiClient {
    /** POST с защитой от «unexpected end of stream»: без keep-alive, фиксированная длина, повторы. */
    private fun post(url: String, headers: Map<String, String>, body: String): Pair<Int, String> {
        val bytes = body.toByteArray(Charsets.UTF_8)
        var last: Exception? = null
        for (attempt in 0..2) {
            try {
                val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.useCaches = false
                c.connectTimeout = 20000
                c.readTimeout = 90000
                c.setFixedLengthStreamingMode(bytes.size)
                c.setRequestProperty("Connection", "close")
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
                c.outputStream.use { it.write(bytes) }
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val text = stream?.use { String(it.readBytes(), Charsets.UTF_8) } ?: ""
                c.disconnect()
                if ((code == 503 || code == 500) && attempt < 2) {
                    Thread.sleep(1200)
                    continue
                }
                return code to text
            } catch (e: java.io.IOException) {
                last = e
                Thread.sleep(700)
            }
        }
        throw Exception("нет связи с сервером ИИ (" + (last?.message ?: "") + ")")
    }

    fun call(
        key: String, model: String, system: String, msgs: List<Pair<String, String>>,
        maxTokens: Int = 4096, json: Boolean = false
    ): String {
        val body = JSONObject()
        val sysParts = JSONArray()
        sysParts.put(JSONObject().put("text", system))
        body.put("systemInstruction", JSONObject().put("parts", sysParts))
        val contents = JSONArray()
        msgs.forEach { (r, t) ->
            val parts = JSONArray()
            parts.put(JSONObject().put("text", t))
            contents.put(JSONObject().put("role", if (r == "assistant") "model" else "user").put("parts", parts))
        }
        body.put("contents", contents)
        val gc = JSONObject()
        gc.put("maxOutputTokens", maxTokens)
        if (json) gc.put("responseMimeType", "application/json")
        body.put("generationConfig", gc)

        val (code, text) = post(
            "https://generativelanguage.googleapis.com/v1beta/models/" + model.trim() + ":generateContent",
            mapOf("x-goog-api-key" to key.trim()),
            body.toString()
        )
        if (code !in 200..299) {
            val msg = try {
                JSONObject(text).getJSONObject("error").getString("message")
            } catch (e: Exception) {
                text.take(200)
            }
            throw Exception("$code: $msg")
        }
        val cand = JSONObject(text).optJSONArray("candidates")
        val parts = cand?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                if (!part.optBoolean("thought", false)) sb.append(part.optString("text"))
            }
        }
        val out = sb.toString().trim()
        if (out.isEmpty()) throw Exception("пустой ответ (возможно, сработал фильтр безопасности)")
        return out
    }

    /** Бесплатный общий сервер без ключа (запасной вариант). */
    fun callFree(system: String, msgs: List<Pair<String, String>>): String {
        val arr = JSONArray()
        arr.put(JSONObject().put("role", "system").put("content", system))
        msgs.forEach { (r, t) -> arr.put(JSONObject().put("role", if (r == "assistant") "assistant" else "user").put("content", t)) }
        val body = JSONObject()
        body.put("model", "openai")
        body.put("messages", arr)
        val (code, text) = post("https://text.pollinations.ai/openai", emptyMap(), body.toString())
        if (code !in 200..299) throw Exception("бесплатный сервер ответил $code. Добавьте свой ключ в настройках (шестерёнка)")
        val out = try {
            JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
        } catch (e: Exception) {
            ""
        }
        if (out.isEmpty()) throw Exception("пустой ответ бесплатного сервера. Добавьте свой ключ в настройках")
        return out
    }

    /** Ключ пользователя → встроенный ключ сборки → бесплатный сервер без ключа. */
    fun chat(
        userKey: String, model: String, system: String, msgs: List<Pair<String, String>>,
        maxTokens: Int = 4096, json: Boolean = false
    ): String {
        val k = userKey.trim().ifBlank { BuildConfig.GEMINI_KEY }
        return if (k.isNotBlank()) call(k, model, system, msgs, maxTokens, json) else callFree(system, msgs)
    }

    /** Любой OpenAI-совместимый сервис: .../chat/completions */
    fun openAi(c: AiConfig, system: String, msgs: List<Pair<String, String>>, maxTokens: Int): String {
        val base = c.baseUrl.trim().trimEnd('/')
        if (base.isBlank()) throw Exception("укажите адрес сервера в настройках")
        if (c.model.isBlank()) throw Exception("укажите модель в настройках")
        val arr = JSONArray()
        arr.put(JSONObject().put("role", "system").put("content", system))
        msgs.forEach { (r, t) ->
            arr.put(JSONObject().put("role", if (r == "assistant") "assistant" else "user").put("content", t))
        }
        val body = JSONObject()
        body.put("model", c.model.trim())
        body.put("messages", arr)
        body.put("max_tokens", maxTokens)
        val headers = HashMap<String, String>()
        if (c.key.isNotBlank()) headers["Authorization"] = "Bearer " + c.key.trim()
        val (code, text) = post(base + "/chat/completions", headers, body.toString())
        if (code !in 200..299) {
            val msg = try {
                JSONObject(text).getJSONObject("error").getString("message")
            } catch (e: Exception) {
                text.take(200)
            }
            throw Exception("$code: $msg")
        }
        val out = try {
            JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
        } catch (e: Exception) {
            ""
        }
        if (out.isEmpty()) throw Exception("пустой ответ сервера")
        return out
    }

    fun chatCfg(
        c: AiConfig, system: String, msgs: List<Pair<String, String>>,
        maxTokens: Int = 4096, json: Boolean = false
    ): String = when (c.provider) {
        "auto" -> if (BuildConfig.GROQ_KEY.isNotBlank()) {
            openAi(
                AiConfig("groq", BuildConfig.GROQ_KEY, "llama-3.3-70b-versatile", "https://api.groq.com/openai/v1"),
                system, msgs, maxTokens
            )
        } else {
            chat("", "gemini-flash-latest", system, msgs, maxTokens, json)
        }
        "gemini" -> {
            if (c.key.isBlank()) throw Exception("введите ключ Gemini в настройках (шестерёнка)")
            call(c.key, c.model.ifBlank { "gemini-flash-latest" }, system, msgs, maxTokens, json)
        }
        else -> openAi(c, system, msgs, maxTokens)
    }

    fun recipeJsonSystem(): String =
        "Преобразуй присланный текст в рецепт. Верни ТОЛЬКО один JSON-объект без пояснений и без markdown. " +
            "Поля: title (строка), description (строка), servings (целое), timeMin (целое, минуты), tempC (целое, 0 если не нужна), " +
            "category (целое: 0 завтраки, 1 супы, 2 основные блюда, 3 салаты, 4 закуски, 5 выпечка, 6 десерты, 7 напитки, 8 заготовки), " +
            "ingredients (массив объектов name, amount число, unit одно из: г, кг, мл, л, шт, ст.л., ч.л., стакан, щепотка, по вкусу), " +
            "steps (массив строк), secrets (строка с советами или пустая)."

    fun parseRecipeJson(raw: String): ParsedRecipe? {
        val a = raw.indexOf('{')
        val b = raw.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        val o = try {
            JSONObject(raw.substring(a, b + 1))
        } catch (e: Exception) {
            return null
        }
        val title = o.optString("title").trim()
        if (title.isEmpty()) return null
        val ings = ArrayList<Ingredient>()
        val ia = o.optJSONArray("ingredients")
        if (ia != null) {
            for (i in 0 until ia.length()) {
                val x = ia.optJSONObject(i) ?: continue
                val unit = x.optString("unit").trim().let { if (it in UNITS) it else "" }
                ings.add(Ingredient(x.optString("name").trim(), x.optDouble("amount", 0.0).let { if (it.isNaN()) 0.0 else it }, unit))
            }
        }
        val steps = ArrayList<String>()
        val sa = o.optJSONArray("steps")
        if (sa != null) {
            for (i in 0 until sa.length()) {
                val s = sa.optString(i).trim()
                if (s.isNotEmpty()) steps.add(s)
            }
        }
        if (ings.isEmpty() && steps.isEmpty()) return null
        return ParsedRecipe(
            title = title,
            description = o.optString("description").trim(),
            servings = o.optInt("servings", 4).let { if (it in 1..99) it else 4 },
            timeMin = o.optInt("timeMin", 0).coerceAtLeast(0),
            tempC = o.optInt("tempC", 0).coerceAtLeast(0),
            ingredients = ings,
            steps = steps,
            imageUrl = null,
            sourceUrl = "ИИ-помощник",
            category = o.optInt("category", 2).coerceIn(0, CATEGORIES.size - 1)
        )
    }
}

data class AiAction(
    val type: String,
    val date: String = "",
    val slot: Int = 1,
    val recipeId: String = "",
    val name: String = "",
    val amount: Double = 0.0,
    val unit: String = "",
    val servings: Int = 0
)

data class Msg(
    val role: String,
    val text: String,
    val raw: String,
    val actions: List<AiAction> = emptyList(),
    val planDone: Boolean = false,
    val shopDone: Boolean = false
)

object AiActions {
    private val re = Regex("<actions>(.*?)</actions>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))

    fun extract(raw: String): Pair<String, List<AiAction>> {
        val m = re.find(raw)
        if (m == null) {
            val idx = raw.indexOf("<actions>", ignoreCase = true)
            return (if (idx >= 0) raw.substring(0, idx) else raw).trim() to emptyList()
        }
        val clean = raw.replace(re, "").trim()
        val body = m.groupValues[1].trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val out = ArrayList<AiAction>()
        try {
            val arr = JSONArray(body)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val amount = o.optDouble("amount", 0.0)
                out.add(
                    AiAction(
                        type = o.optString("type"),
                        date = o.optString("date"),
                        slot = o.optInt("slot", 1),
                        recipeId = o.optString("recipeId"),
                        name = o.optString("name"),
                        amount = if (amount.isNaN()) 0.0 else amount,
                        unit = o.optString("unit"),
                        servings = o.optInt("servings", 0)
                    )
                )
            }
        } catch (e: Exception) {
        }
        return clean to out
    }

    fun systemPrompt(store: CookbookStore, rid: String): String {
        val today = java.time.LocalDate.now()
        val ru = Locale("ru")
        val monday = today.with(java.time.DayOfWeek.MONDAY)
        val week = (0..6).joinToString(", ") {
            val d = monday.plusDays(it.toLong())
            d.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, ru) + " " + d
        }
        val todayName = today.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, ru)
        val catalog = store.recipes.joinToString("\n") {
            it.id + " | " + it.title + " | " + it.cuisine + " | " + (CATEGORIES.getOrNull(it.category)?.second ?: "")
        }
        var s = "Ты — весёлый, дружелюбный кулинарный помощник в приложении «MyCookbook». " +
            "Отвечай по-русски, коротко и по делу, можно с лёгким юмором. " +
            "Указывай граммовки, время и температуру, предлагай замены продуктов.\n\n" +
            "Сегодня: " + today + " (" + todayName + "). Текущая неделя: " + week + ".\n\n" +
            "Каталог рецептов пользователя (id | название | кухня | категория):\n" + catalog + "\n\n" +
            "ДЕЙСТВИЯ. Если пользователь просит составить меню или рацион, запланировать блюда, что-то приготовить в определённый день или купить продукты, " +
            "ответь обычным текстом, а в самом конце добавь блок действий строго в таком виде:\n" +
            "<actions>\n[{\"type\":\"plan\",\"date\":\"ГГГГ-ММ-ДД\",\"slot\":1,\"recipeId\":\"id из каталога\"}]\n</actions>\n" +
            "Типы действий:\n" +
            "- plan: добавить блюдо в план питания. slot: 0 завтрак, 1 обед, 2 ужин. recipeId — только из каталога выше.\n" +
            "- shop: добавить продукт в список покупок: {\"type\":\"shop\",\"name\":\"курица\",\"amount\":500,\"unit\":\"г\"} (unit: г, кг, мл, л, шт, ст.л., ч.л.).\n" +
            "- shop_recipe: добавить все продукты рецепта из каталога: {\"type\":\"shop_recipe\",\"recipeId\":\"id\",\"servings\":4}.\n" +
            "- open: показать рецепт: {\"type\":\"open\",\"recipeId\":\"id\"}.\n" +
            "Правила: для меню на неделю распределяй разные блюда из каталога по дням (завтрак — из завтраков, обед — супы и основные, ужин — основные и салаты) и используй даты текущей недели. " +
            "Если подходящего блюда в каталоге нет, предложи его текстом и добавь нужные продукты действиями shop. " +
            "Внутри блока только JSON без пояснений. Если действий не нужно, блок не добавляй."
        val r = if (rid.isNotEmpty()) store.recipe(rid) else null
        if (r != null) {
            s += "\n\nПользователь сейчас смотрит свой рецепт «" + r.title + "» (id " + r.id + "). Порций: " + r.servings + ". Ингредиенты: " +
                r.ingredients.joinToString("; ") { it.name + " " + ingredientLine(it, 1.0) } +
                ". Шаги: " + r.steps.mapIndexed { i, st -> (i + 1).toString() + ") " + st.text }.joinToString(" ") +
                (if (r.notes.isNotBlank()) ". Заметки: " + r.notes else "")
        }
        return s
    }
}

@Composable
fun AiScreen(store: CookbookStore, nav: NavHostController, rid: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("cookbook_prefs", Context.MODE_PRIVATE) }
    var cfg by remember { mutableStateOf(AiProviders.load(prefs)) }
    var showSettings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf<Msg>() }
    val listState = rememberLazyListState()
    var phraseIdx by remember { mutableIntStateOf(0) }
    val phrases = remember {
        listOf(
            "Взбиваю мысли венчиком…",
            "Жонглирую яйцами…",
            "Листаю вашу книгу рецептов…",
            "Пробую соус на соль…",
            "Ищу, куда спрятался базилик…",
            "Разогреваю нейроны на среднем огне…"
        )
    }
    val recipe = if (rid.isNotEmpty()) store.recipe(rid) else null

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_LONG).show()

    fun send(text: String) {
        val t = text.trim()
        if (busy || t.isEmpty()) return
        messages.add(Msg("user", t, t))
        input = ""
        scope.launch {
            busy = true
            try {
                val system = AiActions.systemPrompt(store, rid)
                val history = messages.toList().takeLast(20).dropWhile { it.role != "user" }.map { it.role to it.raw }
                val reply = withContext(Dispatchers.IO) { AiClient.chatCfg(cfg, system, history) }
                val (clean, acts) = AiActions.extract(reply)
                messages.add(Msg("assistant", clean, reply, acts))
            } catch (e: Exception) {
                messages.removeAt(messages.lastIndex)
                input = t
                toast("Ошибка ИИ: " + (e.message ?: "нет связи"))
            }
            busy = false
        }
    }

    fun toBook(text: String) {
        if (busy) return
        scope.launch {
            busy = true
            try {
                val raw = withContext(Dispatchers.IO) {
                    AiClient.chatCfg(cfg, AiClient.recipeJsonSystem(), listOf("user" to text), 4096, true)
                }
                val p = AiClient.parseRecipeJson(raw)
                if (p == null) {
                    toast("Не удалось оформить рецепт. Попробуйте попросить ИИ написать рецепт полностью.")
                } else {
                    val id = WebImport.addToBook(ctx, store, p)
                    toast("Добавлено в книгу")
                    nav.navigate("recipe/$id")
                }
            } catch (e: Exception) {
                toast("Ошибка ИИ: " + (e.message ?: "нет связи"))
            }
            busy = false
        }
    }

    fun applyPlan(i: Int) {
        val m = messages[i]
        var n = 0
        for (a in m.actions) {
            if (a.type != "plan") continue
            val r = store.recipe(a.recipeId)
            val d = try {
                java.time.LocalDate.parse(a.date)
            } catch (e: Exception) {
                null
            }
            if (r != null && d != null && a.slot in 0..2) {
                store.setPlan(d.toString(), a.slot, r.id)
                n++
            }
        }
        messages[i] = m.copy(planDone = true)
        toast(if (n > 0) "В план питания добавлено блюд: $n" else "Не нашёл подходящих блюд в книге")
    }

    fun applyShop(i: Int) {
        val m = messages[i]
        var n = 0
        for (a in m.actions) {
            if (a.type == "shop" && a.name.isNotBlank()) {
                store.addShop(a.name, a.amount, a.unit)
                n++
            } else if (a.type == "shop_recipe") {
                val r = store.recipe(a.recipeId)
                if (r != null) {
                    store.addShopRecipe(r, if (a.servings > 0) a.servings else r.servings)
                    n++
                }
            }
        }
        messages[i] = m.copy(shopDone = true)
        toast(if (n > 0) "В список покупок добавлено: $n" else "Нечего добавлять")
    }

    LaunchedEffect(busy) {
        while (busy) {
            delay(1700)
            phraseIdx++
        }
    }
    LaunchedEffect(messages.size, busy) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (recipe != null) "ИИ: " + recipe.title else "ИИ-помощник", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } },
                actions = {
                    IconButton(onClick = { nav.navigate("shopping") }) { Icon(Icons.Filled.ShoppingCart, "Список покупок") }
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Filled.Settings, "Настройки ИИ") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().imePadding()) {
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                LiveChef(Modifier.size(width = 64.dp, height = 100.dp), busy = busy, cheer = messages.size)
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(10.dp)
                ) {
                    Text(
                        if (busy) phrases[phraseIdx % phrases.size]
                        else "Скажите, что приготовить, и я запланирую блюда и составлю список покупок!",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(),
                state = listState,
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (messages.isEmpty()) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (cfg.provider == "auto") {
                                Text(
                                    "Помощник работает без настройки. Для более быстрых и стабильных ответов добавьте свой бесплатный ключ (значок шестерёнки).",
                                    color = MaterialTheme.colorScheme.primary,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            val ideas = if (recipe != null) listOf(
                                "Чем можно заменить ингредиенты в этом рецепте?",
                                "Запланируй это блюдо на субботу и добавь продукты в список покупок",
                                "Предложи, с чем подать это блюдо"
                            ) else listOf(
                                "Составь меню на неделю из моей книги и запланируй его",
                                "Хочу приготовить паэлью в субботу, добавь в план и в список покупок",
                                "Что купить для борща?",
                                "Чем заменить сливки?"
                            )
                            ideas.forEach { idea ->
                                AssistChip(onClick = { send(idea) }, label = { Text(idea) })
                            }
                        }
                    }
                }
                items(messages.size) { i ->
                    val m = messages[i]
                    val mine = m.role == "user"
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
                        Box(
                            Modifier
                                .widthIn(max = 320.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                                .padding(12.dp)
                        ) {
                            Text(m.text, color = if (mine) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface)
                        }
                        if (!mine) {
                            val planCount = m.actions.count { it.type == "plan" }
                            val shopCount = m.actions.count { it.type == "shop" || it.type == "shop_recipe" }
                            val open = m.actions.firstOrNull { it.type == "open" && store.recipe(it.recipeId) != null }
                            if (planCount > 0 || shopCount > 0 || open != null) {
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    if (planCount > 0) {
                                        FilledTonalButton(onClick = { applyPlan(i) }, enabled = !m.planDone, contentPadding = PaddingValues(horizontal = 12.dp)) {
                                            Text(if (m.planDone) "✅ В плане" else "📅 В план ($planCount)")
                                        }
                                    }
                                    if (shopCount > 0) {
                                        FilledTonalButton(onClick = { applyShop(i) }, enabled = !m.shopDone, contentPadding = PaddingValues(horizontal = 12.dp)) {
                                            Text(if (m.shopDone) "✅ В списке" else "🛒 В список ($shopCount)")
                                        }
                                    }
                                    if (open != null) {
                                        OutlinedButton(onClick = { nav.navigate("recipe/" + open.recipeId) }, contentPadding = PaddingValues(horizontal = 12.dp)) {
                                            Text("📖 Открыть рецепт")
                                        }
                                    }
                                }
                            }
                            TextButton(onClick = { toBook(m.text) }, enabled = !busy) {
                                Icon(Icons.Filled.Add, null, Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Сохранить как рецепт")
                            }
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    placeholder = { Text("Что приготовить?") },
                    maxLines = 4,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { send(input) }, enabled = !busy && input.isNotBlank()) {
                    Icon(Icons.AutoMirrored.Filled.Send, "Отправить", tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }

    if (showSettings) {
        AiSettingsDialog(
            cfg = cfg,
            onSave = {
                cfg = it
                AiProviders.save(prefs, it)
                showSettings = false
            },
            onDismiss = { showSettings = false }
        )
    }
}

@Composable
fun AiSettingsDialog(cfg: AiConfig, onSave: (AiConfig) -> Unit, onDismiss: () -> Unit) {
    val prefs = LocalContext.current.getSharedPreferences("cookbook_prefs", Context.MODE_PRIVATE)
    var prov by remember { mutableStateOf(cfg.provider) }
    var key by remember { mutableStateOf(cfg.key) }
    var model by remember { mutableStateOf(cfg.model) }
    var base by remember { mutableStateOf(cfg.baseUrl) }
    var open by remember { mutableStateOf(false) }
    val inf = AiProviders.info(prov)

    fun pick(id: String) {
        val c = AiProviders.loadFor(prefs, id)
        prov = id
        key = c.key
        model = c.model
        base = c.baseUrl
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Настройки ИИ") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box {
                    OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(inf.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                        AiProviders.list.forEach { p ->
                            DropdownMenuItem(text = { Text(p.title) }, onClick = { open = false; pick(p.id) })
                        }
                    }
                }
                Text(inf.hint, style = MaterialTheme.typography.bodySmall)
                if (prov != "auto" && prov != "pollinations") {
                    OutlinedTextField(
                        key, { key = it },
                        label = { Text(if (prov == "custom") "Ключ (если нужен)" else "Ключ API") },
                        singleLine = true,
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (prov != "auto") {
                    OutlinedTextField(model, { model = it }, label = { Text("Модель") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                if (prov != "auto" && prov != "gemini") {
                    OutlinedTextField(base, { base = it }, label = { Text("Адрес сервера (…/v1)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                Text("Ключ хранится только на этом телефоне.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(AiConfig(prov, key.trim(), model.trim().ifBlank { inf.model }, base.trim().ifBlank { inf.baseUrl }))
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
