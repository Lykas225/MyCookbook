@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

val CATEGORIES = listOf(
    "🥞" to "Завтраки",       // 0
    "🍲" to "Супы",           // 1
    "🍝" to "Основные блюда", // 2
    "🥗" to "Салаты",         // 3
    "🧀" to "Закуски",        // 4
    "🥧" to "Выпечка",        // 5
    "🍰" to "Десерты",        // 6
    "🥤" to "Напитки",        // 7
    "🥫" to "Консервация"     // 8
)

data class SubCategoryInfo(val id: String, val emoji: String, val title: String)

private val CORE_SUBS = listOf(
    SubCategoryInfo("meat", "🥩", "Мясо"),
    SubCategoryInfo("poultry", "🍗", "Курица"),
    SubCategoryInfo("fish", "🐟", "Рыба"),
    SubCategoryInfo("veggie", "🥦", "Из овощей")
)

val SUBCATEGORIES: Map<Int, List<SubCategoryInfo>> = mapOf(
    0 to listOf(
        SubCategoryInfo("sweet", "🍯", "Сладкие"),
        SubCategoryInfo("veggie", "🥦", "Из овощей"),
        SubCategoryInfo("meat", "🥩", "Мясо"),
        SubCategoryInfo("poultry", "🍗", "Курица"),
        SubCategoryInfo("fish", "🐟", "Рыба")
    ),
    1 to CORE_SUBS,
    2 to CORE_SUBS,
    3 to CORE_SUBS,
    4 to CORE_SUBS,
    5 to listOf(
        SubCategoryInfo("sweet", "🧁", "Сладкая выпечка"),
        SubCategoryInfo("savory", "🥐", "Несладкая выпечка")
    ),
    7 to listOf(
        SubCategoryInfo("coffee", "☕", "Кофе"),
        SubCategoryInfo("tea", "🍵", "Чай и сборы")
    ),
    8 to listOf(
        SubCategoryInfo("veggie", "🥒", "Овощи и салаты"),
        SubCategoryInfo("mushrooms", "🍄", "Грибы"),
        SubCategoryInfo("sweet", "🍓", "Варенье и компоты"),
        SubCategoryInfo("meat_fish", "🥩", "Мясо и рыба")
    )
)

val CATEGORY_HINTS: Map<Int, String> = mapOf(
    0 to "Сладкие • Овощи • Мясо",
    1 to "Мясо • Курица • Рыба • Овощи",
    2 to "Мясо • Курица • Рыба • Овощи",
    3 to "Мясо • Курица • Рыба • Овощи",
    4 to "Мясо • Курица • Рыба • Овощи",
    5 to "Сладкая • Несладкая",
    6 to "Торты и сладости",
    7 to "Кофе • Чай",
    8 to "Овощи • Грибы • Варенье"
)

fun subCategoriesOf(cat: Int): List<SubCategoryInfo> = SUBCATEGORIES[cat].orEmpty()

fun subCategoryInfo(cat: Int, subId: String): SubCategoryInfo? =
    SUBCATEGORIES[cat]?.firstOrNull { it.id == subId }

fun inferSubCategory(r: Recipe): String {
    val tl = r.title.lowercase().replace('ё', 'е')
    val t = (r.title + " " + r.description).lowercase().replace('ё', 'е')
    val ingClean = r.ingredients
        .map { it.name.lowercase().replace('ё', 'е') }
        .filter { !it.contains("бульон") }
        .joinToString(" ")

    return when (r.category) {
        5 -> {
            val savoryKw = listOf(
                "пицц", "киш", "хачапури", "самса", "эмпанадас", "наан", "пиде", "брецел",
                "капуст", "курник", "рыб", "сырн", "мяс", "куриц", "бекон", "несладк", "хлеб", "лепешк", "чебурек", "беляш"
            )
            if (savoryKw.any { tl.contains(it) } || t.contains("несладк")) "savory" else "sweet"
        }
        7 -> {
            if (tl.contains("чай") || tl.contains("матча") || tl.contains("каркаде") || tl.contains("пуэр") || tl.contains("глинтвейн") || r.cuisine.lowercase().contains("чай")) "tea"
            else if (tl.contains("кофе") || tl.contains("капучино") || tl.contains("латте") || tl.contains("раф") || tl.contains("колд брю") || tl.contains("глясе") || tl.contains("дальгона") || r.cuisine.lowercase().contains("кофе")) "coffee"
            else "tea"
        }
        8 -> {
            when {
                listOf("тушенк", "скумбр", "сало", "мяс", "рыб", "курин").any { tl.contains(it) } -> "meat_fish"
                listOf("опят", "гриб", "грузди", "шампиньон").any { tl.contains(it) } -> "mushrooms"
                listOf("варень", "повидл", "компот", "смородин", "облепих", "груши", "тыквенный сок", "джем").any { tl.contains(it) } -> "sweet"
                else -> "veggie"
            }
        }
        0, 1, 2, 3, 4 -> {
            if (r.category == 0 && listOf("блин", "панкейк", "сырник", "вафл", "творожная запеканка", "каша", "оладьи сладк").any { tl.contains(it) }) {
                return "sweet"
            }
            val fishKw = listOf(
                "рыб", "лосос", "семг", "форел", "треск", "скумбр", "минта", "горбуш", "щук",
                "кревет", "дорадо", "карп", "сельдь", "тунец", "тунца", "мидии", "вонголе",
                "морепродукт", "уха", "буйабес", "севиче", "гравлакс", "филадельфия", "фиш ",
                "паэлья", "пад тай", "том ям", "клэм"
            )
            val meatKw = listOf(
                "говядин", "говяж", "свинин", "свин", "баранин", "баран", "телятин", "теляч",
                "мяс", "фарш", "бекон", "ветчин", "колбас", "гуанчале", "ребр", "рульк", "стейк",
                "котлет", "фрикадел", "пельмен", "хинкал", "манты", "голубц", "долма", "плов",
                "бефстроганов", "шницель", "бургер", "бигос", "бешбармак", "болоньезе", "бургиньон",
                "тонкацу", "пулькоги", "искендер", "оссобуко", "оджахури", "люля", "гедза",
                "массаман", "буррито", "фейжоада", "ломо сальтадо", "вепрево", "ирландск",
                "солянк", "харчо", "гуляш", "фо бо", "рамен", "лагман", "шурпа", "борщ",
                "оливье", "окрошк", "тако", "чили кон карне", "мусака", "кефте", "крок-месье",
                "бань ми", "кимпаб", "карбонар", "бибимбап"
            )
            val poultryKw = listOf(
                "куриц", "курин", "цыплен", "петух", "утк", "утин", "индейк", "птиц",
                "фо га", "том кха", "чахохбили", "чкмерули", "баттер чикен", "кунг пао",
                "курица терияки", "тикка масала", "адобо", "сувлаки", "шаурм", "фахитас",
                "энчиладас", "бирьяни", "киевск", "цезарь"
            )
            when {
                fishKw.any { t.contains(it) } -> "fish"
                poultryKw.any { t.contains(it) } -> "poultry"
                meatKw.any { t.contains(it) } || Regex("(?<![а-я])щи(?![а-я])").containsMatchIn(t) -> "meat"
                listOf("лосос", "семг", "форел", "треск", "скумбр", "минта", "кревет", "рыб", "тунец", "сельдь", "мидии").any { ingClean.contains(it) } -> "fish"
                listOf("куриц", "курин", "утк", "утин", "индейк", "цыплен").any { ingClean.contains(it) } -> "poultry"
                listOf("говядин", "говяж", "свинин", "свин", "баранин", "баран", "телятин", "фарш", "бекон", "ветчин", "колбас", "гуанчале").any { ingClean.contains(it) } -> "meat"
                else -> "veggie"
            }
        }
        else -> ""
    }
}

fun effectiveSubCategory(r: Recipe): String {
    val valid = SUBCATEGORIES[r.category]?.map { it.id }?.toSet().orEmpty()
    if (r.subCategory.isNotBlank() && r.subCategory in valid) return r.subCategory
    return inferSubCategory(r)
}
val UNITS = listOf("г", "кг", "мл", "л", "шт", "ст.л.", "ч.л.", "стакан", "щепотка", "по вкусу")
val MEALS = listOf("🌅 Завтрак", "☀️ Обед", "🌙 Ужин")

data class Ingredient(val name: String, val amount: Double, val unit: String)

data class Step(
    val text: String,
    val timerMin: Int = 0,
    val mediaPath: String? = null,
    val mediaIsVideo: Boolean = false
)

data class MediaItem(
    val id: String,
    val path: String,
    val isVideo: Boolean,
    val recipeId: String?,
    val addedAt: Long
)

data class ShopItem(
    val id: String,
    val name: String,
    val amount: Double,
    val unit: String,
    val done: Boolean
)

data class Recipe(
    val id: String,
    val title: String,
    val category: Int,
    val description: String,
    val servings: Int,
    val ingredients: List<Ingredient>,
    val tempC: Int,
    val timeMin: Int,
    val notes: String,
    val secrets: String,
    val steps: List<Step>,
    val favorite: Boolean,
    val lastViewed: Long,
    val createdAt: Long,
    val cuisine: String = "",
    val videoUrl: String = "",
    val subCategory: String = ""
)

fun seedRecipes(): List<Recipe> {
    val now = System.currentTimeMillis()
    fun r(
        title: String, cat: Int, desc: String, serv: Int, temp: Int, time: Int,
        ing: List<Ingredient>, steps: List<Step>, secrets: String
    ) = Recipe(
        UUID.randomUUID().toString(), title, cat, desc, serv, ing, temp, time,
        "", secrets, steps, false, 0L, now
    )
    return listOf(
        r(
            "Борщ классический", 1, "Наваристый борщ со свёклой и капустой", 6, 0, 150,
            listOf(
                Ingredient("Говядина на кости", 600.0, "г"),
                Ingredient("Свёкла", 2.0, "шт"),
                Ingredient("Капуста белокочанная", 300.0, "г"),
                Ingredient("Картофель", 3.0, "шт"),
                Ingredient("Морковь", 1.0, "шт"),
                Ingredient("Лук репчатый", 1.0, "шт"),
                Ingredient("Томатная паста", 2.0, "ст.л."),
                Ingredient("Вода", 2.5, "л"),
                Ingredient("Соль", 0.0, "по вкусу")
            ),
            listOf(
                Step("Залейте мясо холодной водой, доведите до кипения, снимите пену и варите на слабом огне.", 90),
                Step("Нарежьте картофель кубиками, капусту — соломкой. Свёклу и морковь натрите на крупной тёрке.", 0),
                Step("Обжарьте лук, морковь и свёклу с томатной пастой на сковороде.", 10),
                Step("Положите в бульон картофель, через 10 минут капусту, затем зажарку. Варите до готовности овощей.", 20),
                Step("Выключите огонь, дайте борщу настояться под крышкой.", 15)
            ),
            "Добавьте чайную ложку уксуса или сока лимона к свёкле — борщ останется ярко-красным."
        ),
        r(
            "Блины тонкие", 0, "Кружевные блины на молоке", 4, 0, 40,
            listOf(
                Ingredient("Молоко", 500.0, "мл"),
                Ingredient("Яйца", 2.0, "шт"),
                Ingredient("Мука", 200.0, "г"),
                Ingredient("Сахар", 2.0, "ст.л."),
                Ingredient("Растительное масло", 2.0, "ст.л."),
                Ingredient("Соль", 1.0, "щепотка")
            ),
            listOf(
                Step("Взбейте яйца с сахаром и солью, влейте половину молока.", 0),
                Step("Всыпьте муку, перемешайте до гладкости, добавьте остальное молоко и масло.", 0),
                Step("Дайте тесту отдохнуть.", 15),
                Step("Жарьте на хорошо разогретой сковороде по 1 минуте с каждой стороны.", 0)
            ),
            "Тесто должно отдохнуть 15 минут — блины будут эластичными и не порвутся."
        ),
        r(
            "Паста с томатным соусом", 2, "Быстрый ужин за 25 минут", 2, 0, 25,
            listOf(
                Ingredient("Спагетти", 200.0, "г"),
                Ingredient("Помидоры в собственном соку", 400.0, "г"),
                Ingredient("Чеснок", 2.0, "шт"),
                Ingredient("Оливковое масло", 2.0, "ст.л."),
                Ingredient("Базилик", 1.0, "щепотка"),
                Ingredient("Соль", 0.0, "по вкусу")
            ),
            listOf(
                Step("Отварите спагетти в подсоленной воде на 1 минуту меньше, чем указано на упаковке.", 9),
                Step("Обжарьте чеснок в масле, добавьте помидоры и тушите соус.", 10),
                Step("Переложите пасту в соус, добавьте немного воды от варки, перемешайте и подавайте с базиликом.", 0)
            ),
            "Пара ложек воды от варки пасты делает соус шелковистым и помогает ему держаться на спагетти."
        )
    )
}
