@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

val CATEGORIES = listOf(
    "🥞" to "Завтраки",
    "🍲" to "Супы",
    "🍝" to "Основные блюда",
    "🥗" to "Салаты",
    "🧀" to "Закуски",
    "🥧" to "Выпечка",
    "🍰" to "Десерты",
    "🥤" to "Напитки",
    "🥫" to "Заготовки"
)
val UNITS = listOf("г", "кг", "мл", "л", "шт", "ст.л.", "ч.л.", "стакан", "щепотка", "по вкусу")
val MEALS = listOf("🌅 Завтрак", "☀️ Обед", "🌙 Ужин")

data class Ingredient(val name: String, val amount: Double, val unit: String)

data class Step(
    val text: String,
    val timerMin: Int = 0,
    val mediaPath: String? = null,
    val mediaIsVideo: Boolean = false
)

data class MediaItem(
    val id: String,
    val path: String,
    val isVideo: Boolean,
    val recipeId: String?,
    val addedAt: Long
)

data class ShopItem(
    val id: String,
    val name: String,
    val amount: Double,
    val unit: String,
    val done: Boolean
)

data class Recipe(
    val id: String,
    val title: String,
    val category: Int,
    val description: String,
    val servings: Int,
    val ingredients: List<Ingredient>,
    val tempC: Int,
    val timeMin: Int,
    val notes: String,
    val secrets: String,
    val steps: List<Step>,
    val favorite: Boolean,
    val lastViewed: Long,
    val createdAt: Long,
    val cuisine: String = ""
)

fun seedRecipes(): List<Recipe> {
    val now = System.currentTimeMillis()
    fun r(
        title: String, cat: Int, desc: String, serv: Int, temp: Int, time: Int,
        ing: List<Ingredient>, steps: List<Step>, secrets: String
    ) = Recipe(
        UUID.randomUUID().toString(), title, cat, desc, serv, ing, temp, time,
        "", secrets, steps, false, 0L, now
    )
    return listOf(
        r(
            "Борщ классический", 1, "Наваристый борщ со свёклой и капустой", 6, 0, 150,
            listOf(
                Ingredient("Говядина на кости", 600.0, "г"),
                Ingredient("Свёкла", 2.0, "шт"),
                Ingredient("Капуста белокочанная", 300.0, "г"),
                Ingredient("Картофель", 3.0, "шт"),
                Ingredient("Морковь", 1.0, "шт"),
                Ingredient("Лук репчатый", 1.0, "шт"),
                Ingredient("Томатная паста", 2.0, "ст.л."),
                Ingredient("Вода", 2.5, "л"),
                Ingredient("Соль", 0.0, "по вкусу")
            ),
            listOf(
                Step("Залейте мясо холодной водой, доведите до кипения, снимите пену и варите на слабом огне.", 90),
                Step("Нарежьте картофель кубиками, капусту — соломкой. Свёклу и морковь натрите на крупной тёрке.", 0),
                Step("Обжарьте лук, морковь и свёклу с томатной пастой на сковороде.", 10),
                Step("Положите в бульон картофель, через 10 минут капусту, затем зажарку. Варите до готовности овощей.", 20),
                Step("Выключите огонь, дайте борщу настояться под крышкой.", 15)
            ),
            "Добавьте чайную ложку уксуса или сока лимона к свёкле — борщ останется ярко-красным."
        ),
        r(
            "Блины тонкие", 0, "Кружевные блины на молоке", 4, 0, 40,
            listOf(
                Ingredient("Молоко", 500.0, "мл"),
                Ingredient("Яйца", 2.0, "шт"),
                Ingredient("Мука", 200.0, "г"),
                Ingredient("Сахар", 2.0, "ст.л."),
                Ingredient("Растительное масло", 2.0, "ст.л."),
                Ingredient("Соль", 1.0, "щепотка")
            ),
            listOf(
                Step("Взбейте яйца с сахаром и солью, влейте половину молока.", 0),
                Step("Всыпьте муку, перемешайте до гладкости, добавьте остальное молоко и масло.", 0),
                Step("Дайте тесту отдохнуть.", 15),
                Step("Жарьте на хорошо разогретой сковороде по 1 минуте с каждой стороны.", 0)
            ),
            "Тесто должно отдохнуть 15 минут — блины будут эластичными и не порвутся."
        ),
        r(
            "Паста с томатным соусом", 2, "Быстрый ужин за 25 минут", 2, 0, 25,
            listOf(
                Ingredient("Спагетти", 200.0, "г"),
                Ingredient("Помидоры в собственном соку", 400.0, "г"),
                Ingredient("Чеснок", 2.0, "шт"),
                Ingredient("Оливковое масло", 2.0, "ст.л."),
                Ingredient("Базилик", 1.0, "щепотка"),
                Ingredient("Соль", 0.0, "по вкусу")
            ),
            listOf(
                Step("Отварите спагетти в подсоленной воде на 1 минуту меньше, чем указано на упаковке.", 9),
                Step("Обжарьте чеснок в масле, добавьте помидоры и тушите соус.", 10),
                Step("Переложите пасту в соус, добавьте немного воды от варки, перемешайте и подавайте с базиликом.", 0)
            ),
            "Пара ложек воды от варки пасты делает соус шелковистым и помогает ему держаться на спагетти."
        )
    )
}
