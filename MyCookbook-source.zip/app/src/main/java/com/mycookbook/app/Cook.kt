@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import kotlinx.coroutines.*
import java.io.File

@Composable
fun CookScreen(store: CookbookStore, timer: TimerState, id: String, nav: NavHostController) {
    val recipe = store.recipe(id)
    val view = LocalView.current
    val ctx = LocalContext.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }
    if (recipe == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Рецепт не найден") }
        return
    }

    val total = recipe.steps.size + 2
    val pager = rememberPagerState(pageCount = { total })
    val scope = rememberCoroutineScope()
    var servings by remember { mutableIntStateOf(recipe.servings) }
    var player by remember { mutableStateOf<Pair<String, Boolean>?>(null) }

    var autoSpeak by remember { mutableStateOf(false) }
    var listening by remember { mutableStateOf(false) }

    fun currentSpeechText(page: Int): String = when {
        page == 0 -> "Подготовка к блюду ${recipe.title}. Ингредиенты: " +
            recipe.ingredients.joinToString(", ") { it.name }
        page <= recipe.steps.size -> {
            val idx = page - 1
            val st = recipe.steps[idx]
            "Шаг ${idx + 1}. ${st.text}" + if (st.timerMin > 0) " Таймер на ${st.timerMin} минут." else ""
        }
        else -> "Готово! Приятного аппетита!"
    }

    val voiceHolder = remember { arrayOfNulls<VoiceAssistant>(1) }
    val voiceAssistant = remember {
        VoiceAssistant(
            context = ctx,
            onStateChange = { listening = it },
            onCommand = { cmd ->
                scope.launch {
                    when (cmd) {
                        "NEXT" -> {
                            val next = (pager.currentPage + 1).coerceAtMost(total - 1)
                            pager.animateScrollToPage(next)
                        }
                        "PREV" -> {
                            val prev = (pager.currentPage - 1).coerceAtLeast(0)
                            pager.animateScrollToPage(prev)
                        }
                        "REPEAT" -> {
                            voiceHolder[0]?.speak(currentSpeechText(pager.currentPage))
                        }
                        "TIMER_START" -> {
                            val idx = pager.currentPage - 1
                            if (idx in recipe.steps.indices && recipe.steps[idx].timerMin > 0) {
                                val mins = recipe.steps[idx].timerMin
                                timer.start(mins * 60, "${recipe.title}: шаг ${idx + 1}")
                                voiceHolder[0]?.speak("Таймер на $mins минут запущен")
                            } else if (timer.remainingSec > 0 && !timer.running) {
                                timer.resume()
                                voiceHolder[0]?.speak("Таймер продолжен")
                            }
                        }
                        "TIMER_STOP" -> {
                            if (timer.finished) timer.dismiss()
                            else if (timer.running) timer.pause()
                        }
                    }
                }
            }
        ).also { voiceHolder[0] = it }
    }

    DisposableEffect(Unit) {
        onDispose { voiceAssistant.destroy() }
    }

    LaunchedEffect(pager.currentPage, autoSpeak) {
        if (autoSpeak) {
            voiceAssistant.speak(currentSpeechText(pager.currentPage))
        }
    }

    val audioPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            voiceAssistant.startListening()
        } else {
            Toast.makeText(ctx, "Нужен доступ к микрофону для голосовых команд", Toast.LENGTH_SHORT).show()
        }
    }

    fun triggerVoice() {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (granted) {
            voiceAssistant.startListening()
        } else {
            audioPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(recipe.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Filled.Close, "Закрыть") } },
                actions = {
                    IconButton(onClick = {
                        autoSpeak = !autoSpeak
                        if (!autoSpeak) voiceAssistant.stopSpeaking()
                        Toast.makeText(
                            ctx,
                            if (autoSpeak) "Озвучка шагов включена" else "Озвучка шагов выключена",
                            Toast.LENGTH_SHORT
                        ).show()
                    }) {
                        Icon(
                            if (autoSpeak) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff,
                            "Озвучка шагов",
                            tint = if (autoSpeak) MaterialTheme.colorScheme.primary else LocalContentColor.current
                        )
                    }
                    IconButton(onClick = { triggerVoice() }) {
                        Icon(
                            Icons.Filled.Mic,
                            "Голосовая команда",
                            tint = if (listening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            LinearProgressIndicator(
                progress = { (pager.currentPage + 1).toFloat() / total },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            )
            if (listening) {
                Text(
                    "🎤 Слушаю… Скажите: «дальше», «назад», «повтори», «таймер»",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                    textAlign = TextAlign.Center
                )
            }
            HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page ->
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    when {
                        page == 0 -> {
                            Text("Подготовка", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (recipe.timeMin > 0) InfoChip("⏱ " + formatTime(recipe.timeMin))
                                if (recipe.tempC > 0) InfoChip("🌡 ${recipe.tempC} °C")
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Порций", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                IconButton(onClick = { if (servings > 1) servings-- }) { Icon(Icons.Filled.Remove, null) }
                                Text("$servings", style = MaterialTheme.typography.titleMedium)
                                IconButton(onClick = { if (servings < 99) servings++ }) { Icon(Icons.Filled.Add, null) }
                            }
                            val factor = servings.toDouble() / recipe.servings.coerceAtLeast(1)
                            recipe.ingredients.forEach { ing ->
                                Row(Modifier.fillMaxWidth()) {
                                    Text(ing.name, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                                    Text(ingredientLine(ing, factor), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                                }
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                            }
                            if (recipe.secrets.isNotBlank()) {
                                Text("💡 " + recipe.secrets, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        page <= recipe.steps.size -> {
                            val idx = page - 1
                            val step = recipe.steps[idx]
                            Text("Шаг ${idx + 1} из ${recipe.steps.size}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                            val mp = step.mediaPath
                            if (mp != null && File(mp).exists()) {
                                MediaThumb(mp, step.mediaIsVideo, Modifier.fillMaxWidth().height(220.dp)) { player = mp to step.mediaIsVideo }
                            }
                            Text(step.text, style = MaterialTheme.typography.headlineSmall)
                            if (step.timerMin > 0) {
                                val label = "${recipe.title}: шаг ${idx + 1}"
                                val mine = timer.label == label && timer.active
                                if (mine) {
                                    Text(
                                        if (timer.finished) "Время вышло!" else formatClock(timer.remainingSec),
                                        style = MaterialTheme.typography.displayMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (timer.finished) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        if (!timer.finished) {
                                            FilledTonalButton(onClick = { if (timer.running) timer.pause() else timer.resume() }) {
                                                Icon(if (timer.running) Icons.Filled.Pause else Icons.Filled.PlayArrow, null)
                                                Spacer(Modifier.width(6.dp))
                                                Text(if (timer.running) "Пауза" else "Продолжить")
                                            }
                                        }
                                        OutlinedButton(onClick = { timer.dismiss() }) { Text(if (timer.finished) "Остановить сигнал" else "Сбросить") }
                                    }
                                } else {
                                    Button(onClick = { timer.start(step.timerMin * 60, label) }, shape = RoundedCornerShape(16.dp)) {
                                        Icon(Icons.Filled.Timer, null)
                                        Spacer(Modifier.width(8.dp))
                                        Text("Запустить таймер на ${step.timerMin} мин")
                                    }
                                }
                            }
                        }
                        else -> {
                            Spacer(Modifier.height(40.dp))
                            Text("🍽", fontSize = 64.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                            Text("Готово! Приятного аппетита!", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                            Button(onClick = { nav.popBackStack() }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Text("Закрыть") }
                        }
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = { scope.launch { pager.animateScrollToPage((pager.currentPage - 1).coerceAtLeast(0)) } },
                    enabled = pager.currentPage > 0,
                    modifier = Modifier.weight(1f).height(52.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Назад")
                }
                Button(
                    onClick = { scope.launch { pager.animateScrollToPage((pager.currentPage + 1).coerceAtMost(total - 1)) } },
                    enabled = pager.currentPage < total - 1,
                    modifier = Modifier.weight(1f).height(52.dp)
                ) {
                    Text("Дальше")
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, null)
                }
            }
        }
    }

    player?.let { p -> FullscreenMedia(p.first, p.second, { player = null }) }
}
