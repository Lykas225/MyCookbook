@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import kotlinx.coroutines.*
import java.io.File

@Composable
fun RatatouilleHelpDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🐭 Голосовые команды Рататуя") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "Включите режим «Без рук» — в фоне помощник игнорирует посторонние разговоры на кухне и откликается на имена «Рататуй» или «Реми». Работают оба сценария:\n1) Диалог: скажите «Рататуй» (или «Реми») → он ответит «Да, слушаю!» и выполнит следующую команду.\n2) Слитно: сразу скажите «Рататуй, дальше» или «Реми, поставь таймер на 5 минут».",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                HorizontalDivider()
                Text("📖 Навигация по рецепту", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("• «Рататуй, дальше» / «следующий шаг» / «готово»\n• «Рататуй, назад» / «предыдущий шаг»\n• «Рататуй, шаг 3» / «в начало»\n• «Рататуй, повтори» / «прочитай»\n• «Рататуй, тихо» / «замолчи»", style = MaterialTheme.typography.bodySmall)

                Text("🥕 Продукты и порции", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("• «Рататуй, ингредиенты» — зачитает весь список\n• «Рататуй, сколько муки?» — граммовка по продукту\n• «Рататуй, сделай на 6 порций» / «увеличь порции»\n• «Рататуй, какая температура?» / «сколько готовить?»\n• «Рататуй, секреты» — зачитает советы и заметки", style = MaterialTheme.typography.bodySmall)

                Text("⏱ До 10 таймеров голосом", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("• «Рататуй, поставь таймер на 10 минут»\n• «Рататуй, таймер суп на 40 минут» / «на полчаса»\n• «Рататуй, запусти таймер» (таймер текущего шага)\n• «Рататуй, добавь 3 минуты к таймеру»\n• «Рататуй, сколько осталось?» / «проверь таймеры»\n• «Рататуй, пауза таймер 2» / «продолжи таймер 2»\n• «Рататуй, стоп таймер» / «останови все таймеры»", style = MaterialTheme.typography.bodySmall)

                Text("🤖 Умная помощь на кухне", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("• «Рататуй, добавь в покупки молоко»\n• «Рататуй, открой таймеры» / «включи видео»\n• «Рататуй, чем заменить сливки?» (любой вопрос ИИ)\n• «Рататуй, спи» — отключить прослушивание", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Понятно") }
        }
    )
}

@Composable
fun CookScreen(store: CookbookStore, timer: TimerState, id: String, nav: NavHostController) {
    val recipe = store.recipe(id)
    val view = LocalView.current
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("cookbook_prefs", Context.MODE_PRIVATE) }

    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }
    if (recipe == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Рецепт не найден") }
        return
    }

    val total = recipe.steps.size + 2
    val pager = rememberPagerState(pageCount = { total })
    val scope = rememberCoroutineScope()
    var servings by remember { mutableIntStateOf(recipe.servings) }
    var player by remember { mutableStateOf<Pair<String, Boolean>?>(null) }

    var autoSpeak by remember { mutableStateOf(true) }
    var handsFree by remember { mutableStateOf(prefs.getBoolean("ratatouille_hands_free", false)) }
    var voiceMode by remember { mutableStateOf(VoiceMode.OFF) }
    var lastHeard by remember { mutableStateOf("") }
    var showHelp by remember { mutableStateOf(false) }
    var aiBusy by remember { mutableStateOf(false) }

    fun currentSpeechText(page: Int): String = when {
        page == 0 -> "Подготовка к блюду ${recipe.title}. Порций: $servings. Ингредиенты: " +
            recipe.ingredients.joinToString(", ") {
                val qty = ingredientLine(it, servings.toDouble() / recipe.servings.coerceAtLeast(1))
                if (qty.isBlank()) it.name else "${it.name} $qty"
            }
        page <= recipe.steps.size -> {
            val idx = page - 1
            val st = recipe.steps[idx]
            "Шаг ${idx + 1}. ${st.text}" + if (st.timerMin > 0) " Таймер на ${formatDurationRu(st.timerMin * 60)}." else ""
        }
        else -> "Готово! Приятного аппетита!"
    }

    fun findIngredientAnswer(query: String): String {
        val q = query.lowercase().replace('ё', 'е').trim()
        val factor = servings.toDouble() / recipe.servings.coerceAtLeast(1)
        val stem = if (q.length >= 4) q.dropLast(1) else q
        val stem2 = if (q.length >= 5) q.dropLast(2) else stem
        val matches = recipe.ingredients.filter { ing ->
            val n = ing.name.lowercase().replace('ё', 'е')
            n.contains(q) || n.contains(stem) || (stem2.length >= 3 && n.contains(stem2)) ||
                q.split(" ").any { w -> w.length >= 3 && n.contains(w.dropLast(if (w.length >= 5) 1 else 0)) }
        }
        if (matches.isEmpty()) {
            return "В этом рецепте я не нашёл «$query»."
        }
        return matches.joinToString(". ") { ing ->
            val line = ingredientLine(ing, factor)
            if (line.isBlank()) "${ing.name} — по вкусу" else "${ing.name}: $line"
        }
    }

    val voiceHolder = remember { arrayOfNulls<VoiceAssistant>(1) }

    fun handleCommand(cmd: VoiceCommand) {
        val va = voiceHolder[0] ?: return
        scope.launch {
            when (cmd) {
                is VoiceCommand.NextStep -> {
                    if (pager.currentPage < total - 1) {
                        val next = pager.currentPage + 1
                        pager.animateScrollToPage(next)
                        if (!autoSpeak) va.speak(currentSpeechText(next))
                    } else {
                        va.speak("Это последний шаг. Блюдо уже готово!")
                    }
                }
                is VoiceCommand.PrevStep -> {
                    if (pager.currentPage > 0) {
                        val prev = pager.currentPage - 1
                        pager.animateScrollToPage(prev)
                        if (!autoSpeak) va.speak(currentSpeechText(prev))
                    } else {
                        va.speak("Вы уже в самом начале рецепта.")
                    }
                }
                is VoiceCommand.GoToStep -> {
                    val target = cmd.stepNumber.coerceIn(1, recipe.steps.size.coerceAtLeast(1))
                    if (recipe.steps.isEmpty()) {
                        va.speak("В этом рецепте нет пошаговой инструкции.")
                    } else {
                        pager.animateScrollToPage(target)
                        if (!autoSpeak) va.speak(currentSpeechText(target))
                    }
                }
                is VoiceCommand.GoToStart -> {
                    pager.animateScrollToPage(0)
                    if (!autoSpeak) va.speak(currentSpeechText(0))
                }
                is VoiceCommand.RepeatStep -> {
                    va.speak(currentSpeechText(pager.currentPage))
                }
                is VoiceCommand.StopSpeaking -> {
                    va.stopSpeaking()
                }
                is VoiceCommand.ReadIngredients -> {
                    val factor = servings.toDouble() / recipe.servings.coerceAtLeast(1)
                    if (recipe.ingredients.isEmpty()) {
                        va.speak("Ингредиенты не указаны.")
                    } else {
                        val listText = recipe.ingredients.joinToString(", ") {
                            val qty = ingredientLine(it, factor)
                            if (qty.isBlank()) it.name else "${it.name} $qty"
                        }
                        va.speak("На $servings порций понадобится: $listText.")
                    }
                }
                is VoiceCommand.AskIngredient -> {
                    va.speak(findIngredientAnswer(cmd.query))
                }
                is VoiceCommand.SetServings -> {
                    servings = cmd.servings.coerceIn(1, 99)
                    va.speak("Пересчитал ингредиенты на $servings порций.")
                }
                is VoiceCommand.ChangeServings -> {
                    servings = (servings + cmd.delta).coerceIn(1, 99)
                    va.speak("Теперь $servings порций.")
                }
                is VoiceCommand.AskTemp -> {
                    if (recipe.tempC > 0) {
                        va.speak("Температура приготовления: ${recipe.tempC} градусов.")
                    } else {
                        va.speak("В этом рецепте температура духовки не указана.")
                    }
                }
                is VoiceCommand.AskTotalTime -> {
                    if (recipe.timeMin > 0) {
                        va.speak("Общее время приготовления: ${formatDurationRu(recipe.timeMin * 60)}.")
                    } else {
                        va.speak("Общее время в этом рецепте не указано.")
                    }
                }
                is VoiceCommand.ReadSecrets -> {
                    val text = listOf(recipe.secrets, recipe.notes).filter { it.isNotBlank() }.joinToString(". ")
                    va.speak(text.ifBlank { "Особых секретов или заметок к этому рецепту пока нет." })
                }
                is VoiceCommand.TimerStart -> {
                    if (cmd.seconds > 0) {
                        val started = timer.start(cmd.seconds, cmd.label)
                        if (started == null) {
                            va.speak("Уже запущено максимум 10 таймеров. Сначала остановите один из них.")
                        } else {
                            va.speak("Запустил ${started.label} на ${formatDurationRu(cmd.seconds)}.")
                        }
                    } else {
                        val idx = pager.currentPage - 1
                        if (idx in recipe.steps.indices && recipe.steps[idx].timerMin > 0) {
                            val mins = recipe.steps[idx].timerMin
                            val lbl = "${recipe.title}: шаг ${idx + 1}"
                            val started = timer.start(mins * 60, lbl)
                            if (started == null) {
                                va.speak("Уже запущено максимум 10 таймеров.")
                            } else {
                                va.speak("Запустил таймер шага ${idx + 1} на ${formatDurationRu(mins * 60)}.")
                            }
                        } else {
                            val paused = timer.findTimer(preferPaused = true)
                            if (paused != null && !paused.running && !paused.finished) {
                                timer.resume(paused.id)
                                va.speak("Продолжил ${paused.label}.")
                            } else {
                                va.speak("Уточните время, например: поставь таймер на 5 минут.")
                            }
                        }
                    }
                }
                is VoiceCommand.TimerAdd -> {
                    val target = timer.findTimer(number = cmd.number, query = cmd.query)
                    if (target == null) {
                        va.speak("Нет активных таймеров, чтобы добавить время.")
                    } else {
                        val upd = timer.addTime(target.id, cmd.deltaSeconds)
                        if (upd != null) {
                            va.speak("Добавил ${formatDurationRu(cmd.deltaSeconds)} к ${upd.label}. Осталось ${formatDurationRu(upd.remainingSec)}.")
                        }
                    }
                }
                is VoiceCommand.TimerPause -> {
                    if (cmd.all) {
                        val n = timer.pauseAll()
                        va.speak(if (n > 0) "Поставил на паузу таймеров: $n." else "Нет идущих таймеров.")
                    } else {
                        val target = timer.findTimer(number = cmd.number, query = cmd.query)
                        if (target == null) {
                            va.speak("Активных таймеров нет.")
                        } else {
                            timer.pause(target.id)
                            va.speak("${target.label} на паузе.")
                        }
                    }
                }
                is VoiceCommand.TimerResume -> {
                    if (cmd.all) {
                        val n = timer.resumeAll()
                        va.speak(if (n > 0) "Продолжил таймеров: $n." else "Нет таймеров на паузе.")
                    } else {
                        val target = timer.findTimer(number = cmd.number, query = cmd.query, preferPaused = true)
                        if (target == null) {
                            va.speak("Нет таймеров на паузе.")
                        } else {
                            timer.resume(target.id)
                            va.speak("Продолжил ${target.label}.")
                        }
                    }
                }
                is VoiceCommand.TimerStop -> {
                    if (cmd.all) {
                        val n = timer.dismissAll()
                        va.speak(if (n > 0) "Остановил все таймеры." else "Активных таймеров нет.")
                    } else {
                        val target = timer.findTimer(number = cmd.number, query = cmd.query, preferFinished = true)
                        if (target == null) {
                            va.speak("Нет активных таймеров.")
                        } else {
                            timer.dismiss(target.id)
                            va.speak("Остановил ${target.label}.")
                        }
                    }
                }
                is VoiceCommand.TimerStatus -> {
                    if (timer.timers.isEmpty()) {
                        va.speak("Сейчас нет запущенных таймеров.")
                    } else if (cmd.number != null || !cmd.query.isNullOrBlank()) {
                        val target = timer.findTimer(number = cmd.number, query = cmd.query)
                        if (target == null) {
                            va.speak("Такой таймер не найден.")
                        } else if (target.finished) {
                            va.speak("${target.label} уже закончился!")
                        } else {
                            val st = if (target.running) "осталось" else "на паузе, осталось"
                            va.speak("${target.label}: $st ${formatDurationRu(target.remainingSec)}.")
                        }
                    } else {
                        val summary = timer.timers.joinToString(". ") { t ->
                            when {
                                t.finished -> "${t.label} уже готов"
                                t.running -> "${t.label} — осталось ${formatDurationRu(t.remainingSec)}"
                                else -> "${t.label} на паузе, ${formatDurationRu(t.remainingSec)}"
                            }
                        }
                        va.speak("Активных таймеров ${timer.timers.size}. $summary.")
                    }
                }
                is VoiceCommand.AddToShopping -> {
                    store.addShop(cmd.item, 0.0, "")
                    va.speak("Добавил ${cmd.item} в список покупок.")
                }
                is VoiceCommand.OpenTimers -> {
                    va.speak("Открываю таймеры.")
                    nav.navigate("timer")
                }
                is VoiceCommand.OpenVideo -> {
                    va.speak("Открываю видео приготовления.")
                    nav.navigate("video/$id")
                }
                is VoiceCommand.ShowHelp -> {
                    showHelp = true
                    va.speak("Скажите: дальше, назад, повтори, сколько нужно продукта, поставь таймер на нужное время, сколько осталось, останови таймер, или задайте любой кулинарный вопрос.")
                }
                is VoiceCommand.Sleep -> {
                    handsFree = false
                    prefs.edit().putBoolean("ratatouille_hands_free", false).apply()
                }
                is VoiceCommand.AskAi -> {
                    if (aiBusy) return@launch
                    aiBusy = true
                    va.speak("Секунду, подумаю…")
                    try {
                        val cfg = AiProviders.load(prefs)
                        val sys = "Ты — кулинарный помощник Рататуй на кухне. Пользователь сейчас готовит «${recipe.title}» " +
                            "(шаг ${pager.currentPage} из ${recipe.steps.size}). " +
                            "Ответь ОЧЕНЬ коротко (1–2 предложения) по-русски, простыми словами для озвучки вслух, без списков и символов форматирования."
                        val ans = withContext(Dispatchers.IO) {
                            AiClient.chatCfg(cfg, sys, listOf("user" to cmd.question), maxTokens = 300)
                        }
                        val clean = ans.replace(Regex("[*_#`]+"), "").trim()
                        va.speak(clean.ifBlank { "Не расслышал, повторите пожалуйста." })
                    } catch (e: Exception) {
                        va.speak("Не удалось связаться с ИИ, проверьте интернет.")
                    }
                    aiBusy = false
                }
            }
        }
    }

    val voiceAssistant = remember {
        VoiceAssistant(
            context = ctx,
            onModeChange = { m ->
                voiceMode = m
                if (m == VoiceMode.OFF) handsFree = false
            },
            onHeardText = { t -> lastHeard = t },
            onCommand = { cmd -> handleCommand(cmd) }
        ).also { voiceHolder[0] = it }
    }

    DisposableEffect(Unit) {
        timer.onTimerFinished = { t ->
            voiceAssistant.speak(timer.announceText(t), keepDialog = handsFree)
        }
        onDispose {
            timer.onTimerFinished = null
            voiceAssistant.destroy()
        }
    }

    LaunchedEffect(Unit) {
        if (handsFree) {
            val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (granted) {
                voiceAssistant.setHandsFree(true)
            } else {
                handsFree = false
            }
        }
    }

    LaunchedEffect(pager.currentPage, autoSpeak) {
        if (autoSpeak) {
            voiceAssistant.speak(currentSpeechText(pager.currentPage))
        }
    }

    var pendingAction by remember { mutableStateOf<String?>(null) }
    val audioPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            when (pendingAction) {
                "handsfree" -> {
                    handsFree = true
                    prefs.edit().putBoolean("ratatouille_hands_free", true).apply()
                    voiceAssistant.setHandsFree(true)
                    voiceAssistant.speak("Рататуй на связи! В фоне я игнорирую разговоры и откликнусь на Рататуй или Реми.")
                }
                "single" -> voiceAssistant.startSingleCommand()
            }
        } else {
            Toast.makeText(ctx, "Нужен доступ к микрофону для голосового помощника Рататуй", Toast.LENGTH_SHORT).show()
        }
        pendingAction = null
    }

    fun requestAudioThen(action: String) {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (granted) {
            if (action == "handsfree") {
                val next = !handsFree
                handsFree = next
                prefs.edit().putBoolean("ratatouille_hands_free", next).apply()
                voiceAssistant.setHandsFree(next)
                if (next) {
                    voiceAssistant.speak("Рататуй на связи! В фоне я игнорирую разговоры и откликнусь на Рататуй или Реми.")
                } else {
                    voiceAssistant.stopSpeaking()
                }
            } else {
                voiceAssistant.startSingleCommand()
            }
        } else {
            pendingAction = action
            audioPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(recipe.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Filled.Close, "Закрыть") } },
                actions = {
                    IconButton(onClick = { nav.navigate("video/$id") }) {
                        Icon(Icons.Filled.OndemandVideo, "Видео приготовления")
                    }
                    IconButton(onClick = { showHelp = true }) {
                        Icon(Icons.Filled.HelpOutline, "Команды Рататуя")
                    }
                    IconButton(onClick = {
                        autoSpeak = !autoSpeak
                        if (!autoSpeak) voiceAssistant.stopSpeaking()
                        Toast.makeText(
                            ctx,
                            if (autoSpeak) "Автоозвучка шагов включена" else "Автоозвучка шагов выключена",
                            Toast.LENGTH_SHORT
                        ).show()
                    }) {
                        Icon(
                            if (autoSpeak) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff,
                            "Озвучка шагов",
                            tint = if (autoSpeak) MaterialTheme.colorScheme.primary else LocalContentColor.current
                        )
                    }
                    IconButton(onClick = { requestAudioThen("handsfree") }) {
                        Icon(
                            if (handsFree) Icons.Filled.RecordVoiceOver else Icons.Filled.Mic,
                            "Режим Рататуй",
                            tint = when {
                                voiceMode == VoiceMode.LISTENING_COMMAND -> MaterialTheme.colorScheme.error
                                handsFree -> MaterialTheme.colorScheme.primary
                                else -> LocalContentColor.current
                            }
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            LinearProgressIndicator(
                progress = { (pager.currentPage + 1).toFloat() / total },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            )

            // Compact Ratatouille Voice Assistant Bar
            val statusBg = when (voiceMode) {
                VoiceMode.LISTENING_COMMAND -> MaterialTheme.colorScheme.errorContainer
                VoiceMode.WAITING_WAKE -> MaterialTheme.colorScheme.primaryContainer
                VoiceMode.SPEAKING -> MaterialTheme.colorScheme.secondaryContainer
                VoiceMode.OFF -> MaterialTheme.colorScheme.surfaceVariant
            }
            val statusFg = when (voiceMode) {
                VoiceMode.LISTENING_COMMAND -> MaterialTheme.colorScheme.onErrorContainer
                VoiceMode.WAITING_WAKE -> MaterialTheme.colorScheme.onPrimaryContainer
                VoiceMode.SPEAKING -> MaterialTheme.colorScheme.onSecondaryContainer
                VoiceMode.OFF -> MaterialTheme.colorScheme.onSurfaceVariant
            }
            val statusLabel = when {
                aiBusy -> "🐭 Рататуй думает…"
                voiceMode == VoiceMode.LISTENING_COMMAND -> "🎤 Рататуй слушает команду…"
                voiceMode == VoiceMode.WAITING_WAKE -> "👂 Жду «Рататуй» / «Реми» (фон)"
                voiceMode == VoiceMode.SPEAKING -> "🔊 Рататуй говорит…"
                else -> "🐭 Позвать Рататуя / Реми (нажмите)"
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .clickable {
                        if (voiceMode == VoiceMode.SPEAKING) voiceAssistant.stopSpeaking()
                        else requestAudioThen("single")
                    },
                colors = CardDefaults.cardColors(containerColor = statusBg)
            ) {
                Row(
                    Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(statusLabel, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = statusFg)
                        if (lastHeard.isNotBlank() && voiceMode != VoiceMode.OFF) {
                            Text(
                                "«$lastHeard»",
                                style = MaterialTheme.typography.bodySmall,
                                color = statusFg.copy(alpha = 0.8f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    FilterChip(
                        selected = handsFree,
                        onClick = { requestAudioThen("handsfree") },
                        label = { Text(if (handsFree) "Без рук ✓" else "Без рук", fontSize = 11.sp) }
                    )
                }
            }

            // Active timers strip (supports up to 10 timers right from cooking screen)
            if (timer.timers.isNotEmpty()) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    timer.timers.forEach { t ->
                        val chipColor = when {
                            t.finished -> MaterialTheme.colorScheme.error
                            t.running -> MaterialTheme.colorScheme.primary
                            else -> MaterialTheme.colorScheme.secondary
                        }
                        Surface(
                            color = chipColor,
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.clickable {
                                if (t.finished) timer.dismiss(t.id) else nav.navigate("timer")
                            }
                        ) {
                            Row(
                                Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "#${t.number} ${t.label.take(14)}: " +
                                        if (t.finished) "Готово!" else formatClock(t.remainingSec),
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(Modifier.width(4.dp))
                                Icon(
                                    if (t.finished) Icons.Filled.NotificationsOff else Icons.Filled.Close,
                                    "Остановить",
                                    tint = Color.White,
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clickable { timer.dismiss(t.id) }
                                )
                            }
                        }
                    }
                }
            }

            HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page ->
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    when {
                        page == 0 -> {
                            Text("Подготовка", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (recipe.timeMin > 0) InfoChip("⏱ " + formatTime(recipe.timeMin))
                                if (recipe.tempC > 0) InfoChip("🌡 ${recipe.tempC} °C")
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Порций", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                IconButton(onClick = { if (servings > 1) servings-- }) { Icon(Icons.Filled.Remove, null) }
                                Text("$servings", style = MaterialTheme.typography.titleMedium)
                                IconButton(onClick = { if (servings < 99) servings++ }) { Icon(Icons.Filled.Add, null) }
                            }
                            val factor = servings.toDouble() / recipe.servings.coerceAtLeast(1)
                            recipe.ingredients.forEach { ing ->
                                Row(Modifier.fillMaxWidth()) {
                                    Text(ing.name, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                                    Text(ingredientLine(ing, factor), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                                }
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                            }
                            if (recipe.secrets.isNotBlank()) {
                                Text("💡 " + recipe.secrets, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        page <= recipe.steps.size -> {
                            val idx = page - 1
                            val step = recipe.steps[idx]
                            Text("Шаг ${idx + 1} из ${recipe.steps.size}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                            val mp = step.mediaPath
                            if (mp != null && File(mp).exists()) {
                                MediaThumb(mp, step.mediaIsVideo, Modifier.fillMaxWidth().height(220.dp)) { player = mp to step.mediaIsVideo }
                            }
                            Text(step.text, style = MaterialTheme.typography.headlineSmall)
                            if (step.timerMin > 0) {
                                val label = "${recipe.title}: шаг ${idx + 1}"
                                val stepTimer = timer.findByLabel(label)
                                if (stepTimer != null) {
                                    Text(
                                        if (stepTimer.finished) "Время вышло!" else formatClock(stepTimer.remainingSec),
                                        style = MaterialTheme.typography.displayMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (stepTimer.finished) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        if (!stepTimer.finished) {
                                            FilledTonalButton(onClick = {
                                                if (stepTimer.running) timer.pause(stepTimer.id) else timer.resume(stepTimer.id)
                                            }) {
                                                Icon(if (stepTimer.running) Icons.Filled.Pause else Icons.Filled.PlayArrow, null)
                                                Spacer(Modifier.width(6.dp))
                                                Text(if (stepTimer.running) "Пауза" else "Продолжить")
                                            }
                                            OutlinedButton(onClick = { timer.addTime(stepTimer.id, 60) }) {
                                                Text("+1 мин")
                                            }
                                        }
                                        OutlinedButton(onClick = { timer.dismiss(stepTimer.id) }) {
                                            Text(if (stepTimer.finished) "Остановить сигнал" else "Сбросить")
                                        }
                                    }
                                } else {
                                    Button(
                                        onClick = {
                                            val started = timer.start(step.timerMin * 60, label)
                                            if (started == null) {
                                                Toast.makeText(ctx, "Максимум 10 таймеров одновременно", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        shape = RoundedCornerShape(16.dp)
                                    ) {
                                        Icon(Icons.Filled.Timer, null)
                                        Spacer(Modifier.width(8.dp))
                                        Text("Запустить таймер на ${step.timerMin} мин")
                                    }
                                }
                            }
                        }
                        else -> {
                            Spacer(Modifier.height(40.dp))
                            Text("🍽", fontSize = 64.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                            Text("Готово! Приятного аппетита!", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                            Button(onClick = { nav.popBackStack() }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Text("Закрыть") }
                        }
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = { scope.launch { pager.animateScrollToPage((pager.currentPage - 1).coerceAtLeast(0)) } },
                    enabled = pager.currentPage > 0,
                    modifier = Modifier.weight(1f).height(52.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Назад")
                }
                Button(
                    onClick = { scope.launch { pager.animateScrollToPage((pager.currentPage + 1).coerceAtMost(total - 1)) } },
                    enabled = pager.currentPage < total - 1,
                    modifier = Modifier.weight(1f).height(52.dp)
                ) {
                    Text("Дальше")
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, null)
                }
            }
        }
    }

    if (showHelp) RatatouilleHelpDialog { showHelp = false }
    player?.let { p -> FullscreenMedia(p.first, p.second, { player = null }) }
}
