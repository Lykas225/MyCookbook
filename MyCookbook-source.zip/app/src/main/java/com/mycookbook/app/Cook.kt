@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

@Composable
fun CookScreen(store: CookbookStore, timer: TimerState, id: String, nav: NavHostController) {
    val recipe = store.recipe(id)
    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }
    if (recipe == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Рецепт не найден") }
        return
    }

    val total = recipe.steps.size + 2
    val pager = rememberPagerState(pageCount = { total })
    val scope = rememberCoroutineScope()
    var servings by remember { mutableIntStateOf(recipe.servings) }
    var player by remember { mutableStateOf<Pair<String, Boolean>?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(recipe.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Filled.Close, "Закрыть") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            LinearProgressIndicator(
                progress = { (pager.currentPage + 1).toFloat() / total },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            )
            HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page ->
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    when {
                        page == 0 -> {
                            Text("Подготовка", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (recipe.timeMin > 0) InfoChip("⏱ " + formatTime(recipe.timeMin))
                                if (recipe.tempC > 0) InfoChip("🌡 ${recipe.tempC} °C")
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Порций", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                IconButton(onClick = { if (servings > 1) servings-- }) { Icon(Icons.Filled.Remove, null) }
                                Text("$servings", style = MaterialTheme.typography.titleMedium)
                                IconButton(onClick = { if (servings < 99) servings++ }) { Icon(Icons.Filled.Add, null) }
                            }
                            val factor = servings.toDouble() / recipe.servings.coerceAtLeast(1)
                            recipe.ingredients.forEach { ing ->
                                Row(Modifier.fillMaxWidth()) {
                                    Text(ing.name, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                                    Text(ingredientLine(ing, factor), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                                }
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                            }
                            if (recipe.secrets.isNotBlank()) {
                                Text("💡 " + recipe.secrets, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        page <= recipe.steps.size -> {
                            val idx = page - 1
                            val step = recipe.steps[idx]
                            Text("Шаг ${idx + 1} из ${recipe.steps.size}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                            val mp = step.mediaPath
                            if (mp != null && File(mp).exists()) {
                                MediaThumb(mp, step.mediaIsVideo, Modifier.fillMaxWidth().height(220.dp)) { player = mp to step.mediaIsVideo }
                            }
                            Text(step.text, style = MaterialTheme.typography.headlineSmall)
                            if (step.timerMin > 0) {
                                val label = "${recipe.title}: шаг ${idx + 1}"
                                val mine = timer.label == label && timer.active
                                if (mine) {
                                    Text(
                                        if (timer.finished) "Время вышло!" else formatClock(timer.remainingSec),
                                        style = MaterialTheme.typography.displayMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (timer.finished) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        if (!timer.finished) {
                                            FilledTonalButton(onClick = { if (timer.running) timer.pause() else timer.resume() }) {
                                                Icon(if (timer.running) Icons.Filled.Pause else Icons.Filled.PlayArrow, null)
                                                Spacer(Modifier.width(6.dp))
                                                Text(if (timer.running) "Пауза" else "Продолжить")
                                            }
                                        }
                                        OutlinedButton(onClick = { timer.dismiss() }) { Text(if (timer.finished) "Остановить сигнал" else "Сбросить") }
                                    }
                                } else {
                                    Button(onClick = { timer.start(step.timerMin * 60, label) }, shape = RoundedCornerShape(16.dp)) {
                                        Icon(Icons.Filled.Timer, null)
                                        Spacer(Modifier.width(8.dp))
                                        Text("Запустить таймер на ${step.timerMin} мин")
                                    }
                                }
                            }
                        }
                        else -> {
                            Spacer(Modifier.height(40.dp))
                            Text("🍽", fontSize = 64.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                            Text("Готово! Приятного аппетита!", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                            Button(onClick = { nav.popBackStack() }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Text("Закрыть") }
                        }
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = { scope.launch { pager.animateScrollToPage((pager.currentPage - 1).coerceAtLeast(0)) } },
                    enabled = pager.currentPage > 0,
                    modifier = Modifier.weight(1f).height(52.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Назад")
                }
                Button(
                    onClick = { scope.launch { pager.animateScrollToPage((pager.currentPage + 1).coerceAtMost(total - 1)) } },
                    enabled = pager.currentPage < total - 1,
                    modifier = Modifier.weight(1f).height(52.dp)
                ) {
                    Text("Дальше")
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, null)
                }
            }
        }
    }

    player?.let { p -> FullscreenMedia(p.first, p.second, { player = null }) }
}
