@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.navigation.NavHostController
import kotlinx.coroutines.*
import java.io.File

@Composable
fun RatatouilleHelpDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🐭 Голосовые команды Рататуя") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "Рататуй работает на ВСЕХ страницах и во всех разделах! Включите «Без рук» — в фоне он игнорирует посторонние разговоры и откликается на имена «Рататуй» или «Реми».\n1) Диалог: «Рататуй» → «Да, слушаю!» → команда.\n2) Слитно: сразу «Рататуй, дальше» или «Реми, таймер 5 минут».",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                HorizontalDivider()
                Text("🏠 Навигация по всей книге (с любой страницы)", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("• «Рататуй, готовь борщ» / «приготовим шарлотку» — сразу откроет пошаговую готовку\n• «Рататуй, найди оливье» / «открой рецепт плов»\n• «Рататуй, покажи сладкую выпечку» / «несладкую выпечку» / «рыбные супы» / «мясо» / «курица» / «рыба» / «овощи»\n• «Рататуй, главная» / «все рецепты» / «план» / «что в плане сегодня?» / «покупки» / «холодильник» / «архив» / «меню» / «назад»", style = MaterialTheme.typography.bodySmall)

                Text("📖 В рецепте и режиме готовки", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("• «Рататуй, начинаем готовить» / «дальше» / «назад» / «шаг 3» / «в начало» / «повтори» / «тихо»\n• «Рататуй, ингредиенты» / «сколько муки?»\n• «Рататуй, сделай на 6 порций» / «увеличь порции»\n• «Рататуй, какая температура?» / «сколько готовить?» / «секреты»\n• «Рататуй, в любимые» / «добавь ингредиенты в покупки» / «включи видео»", style = MaterialTheme.typography.bodySmall)

                Text("⏱ До 10 таймеров голосом (с любой страницы)", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("• «Рататуй, поставь таймер на 10 минут»\n• «Рататуй, таймер суп на 40 минут» / «на полчаса»\n• «Рататуй, запусти таймер» (таймер текущего шага)\n• «Рататуй, добавь 3 минуты к таймеру»\n• «Рататуй, сколько осталось?» / «проверь таймеры»\n• «Рататуй, пауза таймер 2» / «продолжи таймер 2»\n• «Рататуй, стоп таймер» / «останови все таймеры»", style = MaterialTheme.typography.bodySmall)

                Text("🤖 Умная помощь на кухне", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("• «Рататуй, добавь в покупки молоко»\n• «Рататуй, чем заменить сливки?» (любой вопрос ИИ вслух)\n• «Рататуй, смени тему» / «спи» (отключить прослушивание)", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Понятно") }
        }
    )
}

@Composable
fun CookScreen(store: CookbookStore, timer: TimerState, id: String, nav: NavHostController) {
    val recipe = store.recipe(id)
    val view = LocalView.current
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("cookbook_prefs", Context.MODE_PRIVATE) }
    val voiceHub = LocalVoiceHub.current

    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }
    if (recipe == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Рецепт не найден") }
        return
    }

    val total = recipe.steps.size + 2
    val pager = rememberPagerState(pageCount = { total })
    val scope = rememberCoroutineScope()
    var servings by remember { mutableIntStateOf(recipe.servings) }
    var player by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
    var autoSpeak by remember { mutableStateOf(true) }

    fun currentSpeechText(page: Int): String = when {
        page == 0 -> "Подготовка к блюду ${recipe.title}. Порций: $servings. Ингредиенты: " +
            recipe.ingredients.joinToString(", ") {
                val qty = ingredientLine(it, servings.toDouble() / recipe.servings.coerceAtLeast(1))
                if (qty.isBlank()) it.name else "${it.name} $qty"
            }
        page <= recipe.steps.size -> {
            val idx = page - 1
            val st = recipe.steps[idx]
            "Шаг ${idx + 1}. ${st.text}" + if (st.timerMin > 0) " Таймер на ${formatDurationRu(st.timerMin * 60)}." else ""
        }
        else -> "Готово! Приятного аппетита!"
    }

    fun findIngredientAnswer(query: String): String {
        val q = query.lowercase().replace('ё', 'е').trim()
        val factor = servings.toDouble() / recipe.servings.coerceAtLeast(1)
        val stem = if (q.length >= 4) q.dropLast(1) else q
        val stem2 = if (q.length >= 5) q.dropLast(2) else stem
        val matches = recipe.ingredients.filter { ing ->
            val n = ing.name.lowercase().replace('ё', 'е')
            n.contains(q) || n.contains(stem) || (stem2.length >= 3 && n.contains(stem2)) ||
                q.split(" ").any { w -> w.length >= 3 && n.contains(w.dropLast(if (w.length >= 5) 1 else 0)) }
        }
        if (matches.isEmpty()) {
            return "В этом рецепте я не нашёл «$query»."
        }
        return matches.joinToString(". ") { ing ->
            val line = ingredientLine(ing, factor)
            if (line.isBlank()) "${ing.name} — по вкусу" else "${ing.name}: $line"
        }
    }

    // Регистрируем обработчик команд шагов готовки в глобальном голосовом центре
    DisposableEffect(recipe.id) {
        voiceHub.registerScreenHandler { cmd ->
            when (cmd) {
                is VoiceCommand.NextStep -> {
                    scope.launch {
                        if (pager.currentPage < total - 1) {
                            val next = pager.currentPage + 1
                            pager.animateScrollToPage(next)
                            if (!autoSpeak) voiceHub.speak(currentSpeechText(next))
                        } else {
                            voiceHub.speak("Это последний шаг. Блюдо уже готово!")
                        }
                    }
                    true
                }
                is VoiceCommand.PrevStep -> {
                    scope.launch {
                        if (pager.currentPage > 0) {
                            val prev = pager.currentPage - 1
                            pager.animateScrollToPage(prev)
                            if (!autoSpeak) voiceHub.speak(currentSpeechText(prev))
                        } else {
                            voiceHub.speak("Вы уже в самом начале рецепта.")
                        }
                    }
                    true
                }
                is VoiceCommand.GoToStep -> {
                    scope.launch {
                        val target = cmd.stepNumber.coerceIn(1, recipe.steps.size.coerceAtLeast(1))
                        if (recipe.steps.isEmpty()) {
                            voiceHub.speak("В этом рецепте нет пошаговой инструкции.")
                        } else {
                            pager.animateScrollToPage(target)
                            if (!autoSpeak) voiceHub.speak(currentSpeechText(target))
                        }
                    }
                    true
                }
                is VoiceCommand.GoToStart -> {
                    scope.launch {
                        pager.animateScrollToPage(0)
                        if (!autoSpeak) voiceHub.speak(currentSpeechText(0))
                    }
                    true
                }
                is VoiceCommand.RepeatStep -> {
                    voiceHub.speak(currentSpeechText(pager.currentPage))
                    true
                }
                is VoiceCommand.ReadIngredients -> {
                    val factor = servings.toDouble() / recipe.servings.coerceAtLeast(1)
                    if (recipe.ingredients.isEmpty()) {
                        voiceHub.speak("Ингредиенты не указаны.")
                    } else {
                        val listText = recipe.ingredients.joinToString(", ") {
                            val qty = ingredientLine(it, factor)
                            if (qty.isBlank()) it.name else "${it.name} $qty"
                        }
                        voiceHub.speak("На $servings порций понадобится: $listText.")
                    }
                    true
                }
                is VoiceCommand.AskIngredient -> {
                    voiceHub.speak(findIngredientAnswer(cmd.query))
                    true
                }
                is VoiceCommand.SetServings -> {
                    servings = cmd.servings.coerceIn(1, 99)
                    voiceHub.speak("Пересчитал ингредиенты на $servings порций.")
                    true
                }
                is VoiceCommand.ChangeServings -> {
                    servings = (servings + cmd.delta).coerceIn(1, 99)
                    voiceHub.speak("Теперь $servings порций.")
                    true
                }
                is VoiceCommand.AddRecipeToShopping -> {
                    store.addShopRecipe(recipe, servings)
                    voiceHub.speak("Добавил продукты на $servings порций в список покупок.")
                    true
                }
                is VoiceCommand.TimerStart -> {
                    if (cmd.seconds == 0) {
                        val idx = pager.currentPage - 1
                        if (idx in recipe.steps.indices && recipe.steps[idx].timerMin > 0) {
                            val mins = recipe.steps[idx].timerMin
                            val lbl = "${recipe.title}: шаг ${idx + 1}"
                            val started = timer.start(mins * 60, lbl)
                            if (started == null) {
                                voiceHub.speak("Уже запущено максимум 10 таймеров.")
                            } else {
                                voiceHub.speak("Запустил таймер шага ${idx + 1} на ${formatDurationRu(mins * 60)}.")
                            }
                            true
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }
                is VoiceCommand.AskAi -> {
                    if (voiceHub.aiBusy) return@registerScreenHandler true
                    scope.launch {
                        voiceHub.setAiBusyState(true)
                        voiceHub.speak("Секунду, подумаю…")
                        try {
                            val cfg = AiProviders.load(prefs)
                            val sys = "Ты — кулинарный помощник Рататуй на кухне. Пользователь сейчас готовит «${recipe.title}» " +
                                "(шаг ${pager.currentPage} из ${recipe.steps.size}, порций: $servings). " +
                                "Ответь ОЧЕНЬ коротко (1–2 предложения) по-русски, простыми словами для озвучки вслух, без списков и символов форматирования."
                            val ans = withContext(Dispatchers.IO) {
                                AiClient.chatCfg(cfg, sys, listOf("user" to cmd.question), maxTokens = 300)
                            }
                            val clean = ans.replace(Regex("[*_#`]+"), "").trim()
                            voiceHub.speak(clean.ifBlank { "Не расслышал, повторите пожалуйста." })
                        } catch (e: Exception) {
                            voiceHub.speak("Не удалось связаться с ИИ, проверьте интернет.")
                        }
                        voiceHub.setAiBusyState(false)
                    }
                    true
                }
                else -> false
            }
        }
        onDispose {
            voiceHub.registerScreenHandler(null)
        }
    }

    LaunchedEffect(pager.currentPage, autoSpeak) {
        if (autoSpeak) {
            voiceHub.speak(currentSpeechText(pager.currentPage))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(recipe.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Filled.Close, "Закрыть") } },
                actions = {
                    IconButton(onClick = { nav.navigate("video/$id") }) {
                        Icon(Icons.Filled.OndemandVideo, "Видео приготовления")
                    }
                    IconButton(onClick = { voiceHub.openHelp() }) {
                        Icon(Icons.Filled.HelpOutline, "Команды Рататуя")
                    }
                    IconButton(onClick = {
                        autoSpeak = !autoSpeak
                        if (!autoSpeak) voiceHub.stopSpeaking()
                        Toast.makeText(
                            ctx,
                            if (autoSpeak) "Автоозвучка шагов включена" else "Автоозвучка шагов выключена",
                            Toast.LENGTH_SHORT
                        ).show()
                    }) {
                        Icon(
                            if (autoSpeak) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff,
                            "Озвучка шагов",
                            tint = if (autoSpeak) MaterialTheme.colorScheme.primary else LocalContentColor.current
                        )
                    }
                    IconButton(onClick = { voiceHub.triggerVoice("handsfree") }) {
                        Icon(
                            if (voiceHub.handsFree) Icons.Filled.RecordVoiceOver else Icons.Filled.Mic,
                            "Режим Рататуй",
                            tint = when {
                                voiceHub.voiceMode == VoiceMode.LISTENING_COMMAND -> MaterialTheme.colorScheme.error
                                voiceHub.handsFree -> MaterialTheme.colorScheme.primary
                                else -> LocalContentColor.current
                            }
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            LinearProgressIndicator(
                progress = { (pager.currentPage + 1).toFloat() / total },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            )

            // Compact Ratatouille Voice Assistant Bar (wired to GlobalVoiceHub)
            val statusBg = when (voiceHub.voiceMode) {
                VoiceMode.LISTENING_COMMAND -> MaterialTheme.colorScheme.errorContainer
                VoiceMode.WAITING_WAKE -> MaterialTheme.colorScheme.primaryContainer
                VoiceMode.SPEAKING -> MaterialTheme.colorScheme.secondaryContainer
                VoiceMode.OFF -> MaterialTheme.colorScheme.surfaceVariant
            }
            val statusFg = when (voiceHub.voiceMode) {
                VoiceMode.LISTENING_COMMAND -> MaterialTheme.colorScheme.onErrorContainer
                VoiceMode.WAITING_WAKE -> MaterialTheme.colorScheme.onPrimaryContainer
                VoiceMode.SPEAKING -> MaterialTheme.colorScheme.onSecondaryContainer
                VoiceMode.OFF -> MaterialTheme.colorScheme.onSurfaceVariant
            }
            val statusLabel = when {
                voiceHub.aiBusy -> "🐭 Рататуй думает…"
                voiceHub.voiceMode == VoiceMode.LISTENING_COMMAND -> "🎤 Рататуй слушает команду…"
                voiceHub.voiceMode == VoiceMode.WAITING_WAKE -> "👂 Жду «Рататуй» / «Реми» (фон)"
                voiceHub.voiceMode == VoiceMode.SPEAKING -> "🔊 Рататуй говорит…"
                else -> "🐭 Позвать Рататуя / Реми (нажмите)"
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .clickable {
                        if (voiceHub.voiceMode == VoiceMode.SPEAKING) voiceHub.stopSpeaking()
                        else voiceHub.triggerVoice("single")
                    },
                colors = CardDefaults.cardColors(containerColor = statusBg)
            ) {
                Row(
                    Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(statusLabel, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = statusFg)
                        if (voiceHub.lastHeard.isNotBlank() && voiceHub.voiceMode != VoiceMode.OFF) {
                            Text(
                                "«${voiceHub.lastHeard}»",
                                style = MaterialTheme.typography.bodySmall,
                                color = statusFg.copy(alpha = 0.8f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    FilterChip(
                        selected = voiceHub.handsFree,
                        onClick = { voiceHub.triggerVoice("handsfree") },
                        label = { Text(if (voiceHub.handsFree) "Без рук ✓" else "Без рук", fontSize = 11.sp) }
                    )
                }
            }

            // Active timers strip (supports up to 10 timers right from cooking screen)
            if (timer.timers.isNotEmpty()) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    timer.timers.forEach { t ->
                        val chipColor = when {
                            t.finished -> MaterialTheme.colorScheme.error
                            t.running -> MaterialTheme.colorScheme.primary
                            else -> MaterialTheme.colorScheme.secondary
                        }
                        Surface(
                            color = chipColor,
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.clickable {
                                if (t.finished) timer.dismiss(t.id) else nav.navigate("timer")
                            }
                        ) {
                            Row(
                                Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "#${t.number} ${t.label.take(14)}: " +
                                        if (t.finished) "Готово!" else formatClock(t.remainingSec),
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(Modifier.width(4.dp))
                                Icon(
                                    if (t.finished) Icons.Filled.NotificationsOff else Icons.Filled.Close,
                                    "Остановить",
                                    tint = Color.White,
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clickable { timer.dismiss(t.id) }
                                )
                            }
                        }
                    }
                }
            }

            HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page ->
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    when {
                        page == 0 -> {
                            Text("Подготовка", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (recipe.timeMin > 0) InfoChip("⏱ " + formatTime(recipe.timeMin))
                                if (recipe.tempC > 0) InfoChip("🌡 ${recipe.tempC} °C")
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Порций", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                IconButton(onClick = { if (servings > 1) servings-- }) { Icon(Icons.Filled.Remove, null) }
                                Text("$servings", style = MaterialTheme.typography.titleMedium)
                                IconButton(onClick = { if (servings < 99) servings++ }) { Icon(Icons.Filled.Add, null) }
                            }
                            val factor = servings.toDouble() / recipe.servings.coerceAtLeast(1)
                            recipe.ingredients.forEach { ing ->
                                Row(Modifier.fillMaxWidth()) {
                                    Text(ing.name, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                                    Text(ingredientLine(ing, factor), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                                }
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                            }
                            if (recipe.secrets.isNotBlank()) {
                                Text("💡 " + recipe.secrets, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        page <= recipe.steps.size -> {
                            val idx = page - 1
                            val step = recipe.steps[idx]
                            Text("Шаг ${idx + 1} из ${recipe.steps.size}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                            val mp = step.mediaPath
                            if (mp != null && File(mp).exists()) {
                                MediaThumb(mp, step.mediaIsVideo, Modifier.fillMaxWidth().height(220.dp)) { player = mp to step.mediaIsVideo }
                            }
                            Text(step.text, style = MaterialTheme.typography.headlineSmall)
                            if (step.timerMin > 0) {
                                val label = "${recipe.title}: шаг ${idx + 1}"
                                val stepTimer = timer.findByLabel(label)
                                if (stepTimer != null) {
                                    Text(
                                        if (stepTimer.finished) "Время вышло!" else formatClock(stepTimer.remainingSec),
                                        style = MaterialTheme.typography.displayMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (stepTimer.finished) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        if (!stepTimer.finished) {
                                            FilledTonalButton(onClick = {
                                                if (stepTimer.running) timer.pause(stepTimer.id) else timer.resume(stepTimer.id)
                                            }) {
                                                Icon(if (stepTimer.running) Icons.Filled.Pause else Icons.Filled.PlayArrow, null)
                                                Spacer(Modifier.width(6.dp))
                                                Text(if (stepTimer.running) "Пауза" else "Продолжить")
                                            }
                                            OutlinedButton(onClick = { timer.addTime(stepTimer.id, 60) }) {
                                                Text("+1 мин")
                                            }
                                        }
                                        OutlinedButton(onClick = { timer.dismiss(stepTimer.id) }) {
                                            Text(if (stepTimer.finished) "Остановить сигнал" else "Сбросить")
                                        }
                                    }
                                } else {
                                    Button(
                                        onClick = {
                                            val started = timer.start(step.timerMin * 60, label)
                                            if (started == null) {
                                                Toast.makeText(ctx, "Максимум 10 таймеров одновременно", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        shape = RoundedCornerShape(16.dp)
                                    ) {
                                        Icon(Icons.Filled.Timer, null)
                                        Spacer(Modifier.width(8.dp))
                                        Text("Запустить таймер на ${step.timerMin} мин")
                                    }
                                }
                            }
                        }
                        else -> {
                            Spacer(Modifier.height(40.dp))
                            Text("🍽", fontSize = 64.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                            Text("Готово! Приятного аппетита!", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                            Button(onClick = { nav.popBackStack() }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Text("Закрыть") }
                        }
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = { scope.launch { pager.animateScrollToPage((pager.currentPage - 1).coerceAtLeast(0)) } },
                    enabled = pager.currentPage > 0,
                    modifier = Modifier.weight(1f).height(52.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Назад")
                }
                Button(
                    onClick = { scope.launch { pager.animateScrollToPage((pager.currentPage + 1).coerceAtMost(total - 1)) } },
                    enabled = pager.currentPage < total - 1,
                    modifier = Modifier.weight(1f).height(52.dp)
                ) {
                    Text("Дальше")
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, null)
                }
            }
        }
    }

    player?.let { p -> FullscreenMedia(p.first, p.second, { player = null }) }
}

fun findBestRecipeByVoice(recipes: List<Recipe>, query: String): Recipe? {
    val q = query.lowercase().replace('ё', 'е').trim()
    if (q.isBlank()) return null
    recipes.firstOrNull { it.title.lowercase().replace('ё', 'е') == q }?.let { return it }
    recipes.firstOrNull { it.title.lowercase().replace('ё', 'е').contains(q) }?.let { return it }
    val words = q.split(Regex("\\s+")).filter { it.length >= 3 }
    if (words.isEmpty()) return null
    val stems = words.map { w -> if (w.length >= 5) w.dropLast(2) else if (w.length == 4) w.dropLast(1) else w }
    return recipes.mapNotNull { r ->
        val t = r.title.lowercase().replace('ё', 'е')
        val score = stems.count { st -> t.contains(st) } * 3 +
            stems.count { st -> r.ingredients.any { it.name.lowercase().replace('ё', 'е').contains(st) } }
        if (score > 0) r to score else null
    }.maxByOrNull { it.second }?.first
}
