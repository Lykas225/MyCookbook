@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

@Composable
fun DetailScreen(store: CookbookStore, id: String, nav: NavHostController) {
    val recipe = store.recipe(id)
    LaunchedEffect(id) { store.markViewed(id) }

    var servings by remember(id) { mutableIntStateOf(recipe?.servings ?: 1) }
    var viewer by remember { mutableStateOf<MediaItem?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var shareMenu by remember { mutableStateOf(false) }
    val actions = rememberMediaActions { p, v -> store.addMedia(p, v, id) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(recipe?.title ?: "Рецепт", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") }
                },
                actions = {
                    if (recipe != null) {
                        Box {
                            IconButton(onClick = { shareMenu = true }) { Icon(Icons.Filled.Share, "Поделиться") }
                            DropdownMenu(expanded = shareMenu, onDismissRequest = { shareMenu = false }) {
                                DropdownMenuItem(
                                    text = { Text("Текстом (с фото)") },
                                    onClick = { shareMenu = false; shareRecipeText(ctx, store, recipe) }
                                )
                                DropdownMenuItem(
                                    text = { Text("Файлом для MyCookbook") },
                                    onClick = {
                                        shareMenu = false
                                        scope.launch {
                                            try {
                                                shareRecipeFile(ctx, store, recipe)
                                            } catch (e: Exception) {
                                                Toast.makeText(ctx, "Не удалось подготовить файл", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                )
                            }
                        }
                        IconButton(onClick = { store.toggleFavorite(id) }) {
                            Icon(
                                if (recipe.favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                "Любимое",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = { nav.navigate("edit/$id") }) { Icon(Icons.Filled.Edit, "Редактировать") }
                        IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, "Удалить") }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        if (recipe == null) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { Text("Рецепт не найден") }
        } else {
            val media = store.mediaOf(id)
            val factor = servings.toDouble() / recipe.servings.coerceAtLeast(1)
            Column(
                Modifier
                    .padding(pad)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                val cover = store.coverOf(id)
                if (cover != null) {
                    MediaThumb(cover.path, cover.isVideo, Modifier.fillMaxWidth().height(220.dp)) { viewer = cover }
                }
                if (recipe.description.isNotBlank()) {
                    Text(recipe.description, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    InfoChip((CATEGORIES.getOrNull(recipe.category)?.first ?: "🍽") + " " + (CATEGORIES.getOrNull(recipe.category)?.second ?: ""))
                    if (recipe.cuisine.isNotBlank()) InfoChip(recipe.cuisine)
                    if (recipe.timeMin > 0) InfoChip("⏱ " + formatTime(recipe.timeMin))
                    if (recipe.tempC > 0) InfoChip("🌡 ${recipe.tempC} °C")
                }

                if (recipe.steps.isNotEmpty()) {
                    Button(
                        onClick = { nav.navigate("cook/$id") },
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Filled.PlayArrow, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Как приготовить", fontSize = 17.sp)
                    }
                }

                OutlinedButton(
                    onClick = { nav.navigate("ai/$id") },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Filled.Lightbulb, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Спросить ИИ об этом рецепте")
                }

                OutlinedButton(
                    onClick = {
                        store.addShopRecipe(recipe, servings)
                        Toast.makeText(ctx, "Продукты добавлены в список покупок", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Filled.ShoppingCart, null)
                    Spacer(Modifier.width(8.dp))
                    Text("В список покупок")
                }

                // Ingredients with portion calculator
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Ингредиенты", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            IconButton(onClick = { if (servings > 1) servings-- }) { Icon(Icons.Filled.Remove, "Меньше") }
                            Text("🍽 $servings", fontWeight = FontWeight.SemiBold)
                            IconButton(onClick = { if (servings < 99) servings++ }) { Icon(Icons.Filled.Add, "Больше") }
                        }
                        if (recipe.ingredients.isEmpty()) {
                            Text("Не указаны", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        recipe.ingredients.forEach { ing ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                                Text(ing.name, modifier = Modifier.weight(1f))
                                Text(ingredientLine(ing, factor), fontWeight = FontWeight.SemiBold)
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        }
                    }
                }

                if (recipe.steps.isNotEmpty()) {
                    Text("Шаги приготовления", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    recipe.steps.forEachIndexed { i, s ->
                        Row(verticalAlignment = Alignment.Top) {
                            Box(
                                Modifier.size(28.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                                contentAlignment = Alignment.Center
                            ) { Text("${i + 1}", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold) }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(s.text)
                                if (s.timerMin > 0) {
                                    Text("⏱ ${s.timerMin} мин", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                                }
                                val mp = s.mediaPath
                                if (mp != null && File(mp).exists()) {
                                    Spacer(Modifier.height(6.dp))
                                    MediaThumb(mp, s.mediaIsVideo, Modifier.size(width = 160.dp, height = 100.dp)) {
                                        viewer = MediaItem("step$i", mp, s.mediaIsVideo, id, 0L)
                                    }
                                }
                            }
                        }
                    }
                }

                if (recipe.secrets.isNotBlank()) {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Column(Modifier.padding(14.dp)) {
                            Text("💡 Секреты и хитрости", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Spacer(Modifier.height(4.dp))
                            Text(recipe.secrets, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                }
                if (recipe.notes.isNotBlank()) {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))) {
                        Column(Modifier.padding(14.dp)) {
                            Text("📝 Личные заметки", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text(recipe.notes)
                        }
                    }
                }

                Text("Фото и видео блюда", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (media.isNotEmpty()) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(media, key = { it.id }) { m ->
                            MediaThumb(m.path, m.isVideo, Modifier.size(110.dp)) { viewer = m }
                        }
                    }
                }
                MediaAddButtons(actions)
                Spacer(Modifier.height(24.dp))
            }
        }
    }

    viewer?.let { v ->
        if (v.id.startsWith("step")) {
            FullscreenMedia(v.path, v.isVideo, { viewer = null })
        } else {
            MediaViewerDialog(v, store) { viewer = null }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Удалить рецепт?") },
            text = { Text("Фото и видео останутся в архиве.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    store.deleteRecipe(id)
                    nav.popBackStack()
                }) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Отмена") } }
        )
    }
}
