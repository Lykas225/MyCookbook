@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import java.util.Locale

data class KitchenTimer(
    val id: Int,
    val number: Int,
    val label: String,
    val totalSec: Int,
    val remainingSec: Int,
    val running: Boolean,
    val finished: Boolean,
    val endAtMs: Long = 0L
)

class TimerState(private val app: Application, private val scope: CoroutineScope) {
    companion object {
        const val MAX_TIMERS = 10
    }

    var timers by mutableStateOf<List<KitchenTimer>>(emptyList())
        private set

    var onTimerFinished: ((KitchenTimer) -> Unit)? = null

    private var nextId = 1
    private var tickJob: Job? = null
    private var alarmStopJob: Job? = null
    private var ringtone: android.media.Ringtone? = null
    private var fallbackTts: TextToSpeech? = null
    private var fallbackTtsReady = false

    val active: Boolean get() = timers.isNotEmpty()
    val anyFinished: Boolean get() = timers.any { it.finished }
    val runningCount: Int get() = timers.count { it.running }

    val primaryTimer: KitchenTimer?
        get() = timers.firstOrNull { it.finished }
            ?: timers.filter { it.running }.minByOrNull { it.remainingSec }
            ?: timers.firstOrNull()

    init {
        try {
            fallbackTts = TextToSpeech(app) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    fallbackTts?.language = Locale("ru", "RU")
                    val p = RemyVoiceProfile.load(app.getSharedPreferences("cookbook_prefs", android.content.Context.MODE_PRIVATE))
                    fallbackTts?.setPitch(p.pitch)
                    fallbackTts?.setSpeechRate(p.rate)
                    fallbackTtsReady = true
                }
            }
        } catch (e: Exception) {
        }
    }

    fun start(seconds: Int, newLabel: String = ""): KitchenTimer? {
        if (seconds <= 0) return null
        val cleanLabel = newLabel.trim()

        // If restarting an existing timer with the exact same non-empty label, reset it
        if (cleanLabel.isNotEmpty()) {
            val same = timers.firstOrNull { it.label.equals(cleanLabel, ignoreCase = true) }
            if (same != null) {
                val now = System.currentTimeMillis()
                val updated = same.copy(
                    totalSec = seconds,
                    remainingSec = seconds,
                    running = true,
                    finished = false,
                    endAtMs = now + seconds * 1000L
                )
                timers = timers.map { if (it.id == same.id) updated else it }
                if (!anyFinished) stopAlarm()
                ensureTicking()
                return updated
            }
        }

        if (timers.size >= MAX_TIMERS) return null

        val usedNumbers = timers.map { it.number }.toSet()
        val num = (1..MAX_TIMERS).firstOrNull { it !in usedNumbers } ?: (timers.size + 1)
        val finalLabel = cleanLabel.ifBlank { "Таймер $num" }
        val now = System.currentTimeMillis()
        val created = KitchenTimer(
            id = nextId++,
            number = num,
            label = finalLabel,
            totalSec = seconds,
            remainingSec = seconds,
            running = true,
            finished = false,
            endAtMs = now + seconds * 1000L
        )
        timers = timers + created
        ensureTicking()
        return created
    }

    fun resume(id: Int): KitchenTimer? {
        val t = timers.firstOrNull { it.id == id } ?: return null
        if (t.running || t.remainingSec <= 0) return t
        val updated = t.copy(
            running = true,
            finished = false,
            endAtMs = System.currentTimeMillis() + t.remainingSec * 1000L
        )
        timers = timers.map { if (it.id == id) updated else it }
        ensureTicking()
        return updated
    }

    fun resumeAll(): Int {
        val now = System.currentTimeMillis()
        var count = 0
        timers = timers.map { t ->
            if (!t.running && !t.finished && t.remainingSec > 0) {
                count++
                t.copy(running = true, endAtMs = now + t.remainingSec * 1000L)
            } else t
        }
        if (count > 0) ensureTicking()
        return count
    }

    fun pause(id: Int): KitchenTimer? {
        val t = timers.firstOrNull { it.id == id } ?: return null
        if (!t.running) return t
        val left = ((t.endAtMs - System.currentTimeMillis() + 999) / 1000).toInt().coerceAtLeast(1)
        val updated = t.copy(running = false, remainingSec = left)
        timers = timers.map { if (it.id == id) updated else it }
        return updated
    }

    fun pauseAll(): Int {
        val now = System.currentTimeMillis()
        var count = 0
        timers = timers.map { t ->
            if (t.running) {
                count++
                val left = ((t.endAtMs - now + 999) / 1000).toInt().coerceAtLeast(1)
                t.copy(running = false, remainingSec = left)
            } else t
        }
        return count
    }

    fun addTime(id: Int, deltaSec: Int): KitchenTimer? {
        val t = timers.firstOrNull { it.id == id } ?: return null
        val newRem = (t.remainingSec + deltaSec).coerceAtLeast(1)
        val newTotal = maxOf(t.totalSec, newRem)
        val updated = if (t.running) {
            t.copy(
                totalSec = newTotal,
                remainingSec = newRem,
                finished = false,
                endAtMs = System.currentTimeMillis() + newRem * 1000L
            )
        } else {
            t.copy(
                totalSec = newTotal,
                remainingSec = newRem,
                finished = false
            )
        }
        timers = timers.map { if (it.id == id) updated else it }
        if (!anyFinished) stopAlarm()
        if (updated.running) ensureTicking()
        return updated
    }

    fun dismiss(id: Int): KitchenTimer? {
        val t = timers.firstOrNull { it.id == id } ?: return null
        timers = timers.filter { it.id != id }
        if (!anyFinished) stopAlarm()
        if (timers.none { it.running }) tickJob?.cancel()
        return t
    }

    fun dismissFinished(): Int {
        val n = timers.count { it.finished }
        timers = timers.filter { !it.finished }
        stopAlarm()
        if (timers.none { it.running }) tickJob?.cancel()
        return n
    }

    fun dismissAll(): Int {
        val n = timers.size
        tickJob?.cancel()
        timers = emptyList()
        stopAlarm()
        return n
    }

    fun findByLabel(label: String): KitchenTimer? =
        timers.firstOrNull { it.label.equals(label, ignoreCase = true) }

    fun findTimer(number: Int? = null, query: String? = null, preferFinished: Boolean = false, preferPaused: Boolean = false): KitchenTimer? {
        if (number != null) {
            timers.firstOrNull { it.number == number }?.let { return it }
        }
        if (!query.isNullOrBlank()) {
            val q = query.trim().lowercase()
            val stem = if (q.length >= 4) q.dropLast(1) else q
            timers.firstOrNull { it.label.lowercase().contains(q) }?.let { return it }
            timers.firstOrNull { it.label.lowercase().contains(stem) }?.let { return it }
        }
        if (preferFinished) {
            timers.firstOrNull { it.finished }?.let { return it }
        }
        if (preferPaused) {
            timers.lastOrNull { !it.running && !it.finished && it.remainingSec > 0 }?.let { return it }
        }
        return timers.lastOrNull { it.running } ?: timers.lastOrNull()
    }

    fun announceText(t: KitchenTimer): String {
        val lbl = t.label.trim()
        return if (lbl.lowercase().startsWith("таймер")) {
            "Внимание! $lbl закончился!"
        } else {
            "Внимание! Таймер $lbl закончился!"
        }
    }

    private fun ensureTicking() {
        if (tickJob?.isActive == true) return
        tickJob = scope.launch {
            while (timers.any { it.running }) {
                val now = System.currentTimeMillis()
                val justFinished = ArrayList<KitchenTimer>()
                var changed = false
                val updated = timers.map { t ->
                    if (!t.running) {
                        t
                    } else {
                        val left = ((t.endAtMs - now + 999) / 1000).toInt().coerceAtLeast(0)
                        if (left <= 0) {
                            changed = true
                            val fin = t.copy(remainingSec = 0, running = false, finished = true)
                            justFinished.add(fin)
                            fin
                        } else if (left != t.remainingSec) {
                            changed = true
                            t.copy(remainingSec = left)
                        } else {
                            t
                        }
                    }
                }
                if (changed) {
                    timers = updated
                }
                if (justFinished.isNotEmpty()) {
                    onTimersDone(justFinished)
                }
                delay(250)
            }
        }
    }

    private fun onTimersDone(list: List<KitchenTimer>) {
        ring()
        for (t in list) {
            val cb = onTimerFinished
            if (cb != null) {
                cb(t)
            } else if (fallbackTtsReady) {
                try {
                    fallbackTts?.speak(announceText(t), TextToSpeech.QUEUE_ADD, null, "timer_done_${t.id}")
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun ring() {
        stopAlarm()
        try {
            val uri = android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM)
                ?: android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION)
            ringtone = android.media.RingtoneManager.getRingtone(app, uri)
            ringtone?.play()
        } catch (e: Exception) {
        }
        try {
            val v = app.getSystemService(android.os.Vibrator::class.java)
            v?.vibrate(android.os.VibrationEffect.createWaveform(longArrayOf(0, 500, 250, 500, 250, 500), -1))
        } catch (e: Exception) {
        }
        alarmStopJob?.cancel()
        alarmStopJob = scope.launch {
            delay(15000)
            stopAlarm()
        }
    }

    fun stopAlarm() {
        alarmStopJob?.cancel()
        try {
            ringtone?.stop()
        } catch (e: Exception) {
        }
        ringtone = null
    }

    fun shutdown() {
        tickJob?.cancel()
        stopAlarm()
        try {
            fallbackTts?.stop()
            fallbackTts?.shutdown()
        } catch (e: Exception) {
        }
        fallbackTts = null
    }
}

fun formatDurationRu(totalSec: Int): String {
    val s = totalSec.coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    fun decl(n: Int, one: String, few: String, many: String): String {
        val m100 = n % 100
        val m10 = n % 10
        return when {
            m100 in 11..19 -> "$n $many"
            m10 == 1 -> "$n $one"
            m10 in 2..4 -> "$n $few"
            else -> "$n $many"
        }
    }
    val parts = ArrayList<String>()
    if (h > 0) parts.add(decl(h, "час", "часа", "часов"))
    if (m > 0) parts.add(decl(m, "минута", "минуты", "минут"))
    if (sec > 0 && h == 0) parts.add(decl(sec, "секунда", "секунды", "секунд"))
    return if (parts.isEmpty()) "меньше секунды" else parts.joinToString(" ")
}

class MainVm(app: Application) : AndroidViewModel(app) {
    val store = CookbookStore(app)
    val timer = TimerState(app, viewModelScope)

    override fun onCleared() {
        timer.shutdown()
        super.onCleared()
    }
}
