@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

class TimerState(private val app: Application, private val scope: CoroutineScope) {
    var totalSec by mutableIntStateOf(0)
        private set
    var remainingSec by mutableIntStateOf(0)
        private set
    var running by mutableStateOf(false)
        private set
    var finished by mutableStateOf(false)
        private set
    var label by mutableStateOf("")
        private set

    private var job: Job? = null
    private var endAt = 0L
    private var ringtone: android.media.Ringtone? = null

    val active: Boolean get() = running || finished || remainingSec > 0

    fun start(seconds: Int, newLabel: String) {
        stopAlarm()
        job?.cancel()
        running = false
        totalSec = seconds
        remainingSec = seconds
        label = newLabel
        finished = false
        resume()
    }

    fun resume() {
        if (remainingSec <= 0 || running) return
        running = true
        finished = false
        endAt = System.currentTimeMillis() + remainingSec * 1000L
        job?.cancel()
        job = scope.launch {
            while (true) {
                val left = ((endAt - System.currentTimeMillis() + 999) / 1000).toInt()
                remainingSec = left.coerceAtLeast(0)
                if (left <= 0) break
                delay(250)
            }
            running = false
            finished = true
            ring()
        }
    }

    fun pause() {
        job?.cancel()
        running = false
    }

    fun dismiss() {
        job?.cancel()
        running = false
        finished = false
        remainingSec = 0
        totalSec = 0
        label = ""
        stopAlarm()
    }

    private fun ring() {
        try {
            val uri = android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM)
            ringtone = android.media.RingtoneManager.getRingtone(app, uri)
            ringtone?.play()
        } catch (e: Exception) {
        }
        try {
            val v = app.getSystemService(android.os.Vibrator::class.java)
            v?.vibrate(android.os.VibrationEffect.createWaveform(longArrayOf(0, 600, 300, 600, 300, 600), -1))
        } catch (e: Exception) {
        }
        scope.launch {
            delay(20000)
            stopAlarm()
        }
    }

    private fun stopAlarm() {
        try {
            ringtone?.stop()
        } catch (e: Exception) {
        }
        ringtone = null
    }
}

class MainVm(app: Application) : AndroidViewModel(app) {
    val store = CookbookStore(app)
    val timer = TimerState(app, viewModelScope)
}
