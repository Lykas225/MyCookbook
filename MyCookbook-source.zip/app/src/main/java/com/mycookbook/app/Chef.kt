@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

enum class ChefAction { IDLE, WAVE, STIR, TASTE, CHEER, PULL }

/** Оригинальный мультяшный крыс-повар во весь рост, с объёмной светотенью. */
@Composable
fun ChefMascot(modifier: Modifier, action: ChefAction, phase: Float, blink: Boolean) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val furL = Color(0xFFBCC0CE)
        val furB = Color(0xFF8E93A3)
        val furD = Color(0xFF565B6D)
        val whL = Color.White
        val whB = Color(0xFFF4EFE5)
        val whD = Color(0xFFBDB29C)
        val pkL = Color(0xFFFFC9D6)
        val pkB = Color(0xFFE98BA0)
        val pkD = Color(0xFFA9556B)
        val snL = Color(0xFFF6F1E8)
        val snB = Color(0xFFDDD6CC)
        val snD = Color(0xFFA39A8E)
        val ink = Color(0xFF2A2C35)
        val wood = Color(0xFFB9854F)

        val s1 = sin(phase)
        val c1 = cos(phase)
        val s2 = sin(phase * 2f)
        val jump = if (action == ChefAction.CHEER) abs(s1) * h * 0.09f else 0f
        val bob = if (action == ChefAction.IDLE) s1 * h * 0.006f else 0f
        // «поворот головы» — даёт эффект объёма (параллакс черт лица)
        val yaw = (if (action == ChefAction.PULL) 0.03f else s1 * 0.016f) * w

        fun gradient(cx: Float, cy: Float, rx: Float, ry: Float, light: Color, base: Color, dark: Color): Brush {
            val r = maxOf(rx, ry)
            return Brush.radialGradient(
                0f to light, 0.5f to base, 1f to dark,
                center = Offset(cx - rx * 0.30f, cy - ry * 0.40f),
                radius = r * 1.5f
            )
        }

        fun blob(cx: Float, cy: Float, rx: Float, ry: Float, light: Color, base: Color, dark: Color) {
            drawOval(gradient(cx, cy, rx, ry, light, base, dark), Offset(cx - rx, cy - ry), Size(rx * 2f, ry * 2f))
        }

        // мягкая тень на полу
        val sh = 1f - jump / (h * 0.25f)
        drawOval(
            Brush.radialGradient(listOf(Color(0x66000000), Color.Transparent), center = Offset(w * 0.5f, h * 0.955f), radius = w * 0.42f * sh),
            Offset(w * (0.5f - 0.34f * sh), h * 0.93f),
            Size(w * 0.68f * sh, h * 0.05f)
        )

        translate(top = bob - jump) {
            // хвост
            val tail = Path()
            tail.moveTo(w * 0.70f, h * 0.82f)
            tail.cubicTo(w * 0.98f + s2 * w * 0.05f, h * 0.84f, w * 0.99f, h * 0.70f, w * 0.90f + s2 * w * 0.07f, h * 0.60f)
            drawPath(tail, pkD, style = Stroke(w * 0.042f, cap = StrokeCap.Round))
            drawPath(tail, pkB, style = Stroke(w * 0.028f, cap = StrokeCap.Round))

            // ноги и ступни
            blob(w * 0.39f, h * 0.885f, w * 0.06f, h * 0.05f, furL, furB, furD)
            blob(w * 0.61f, h * 0.885f, w * 0.06f, h * 0.05f, furL, furB, furD)
            blob(w * 0.355f, h * 0.94f, w * 0.105f, h * 0.028f, Color(0xFFD8C9C9), Color(0xFFB5A5A5), Color(0xFF7D6E6E))
            blob(w * 0.645f, h * 0.94f, w * 0.105f, h * 0.028f, Color(0xFFD8C9C9), Color(0xFFB5A5A5), Color(0xFF7D6E6E))

            // тело и китель
            blob(w * 0.5f, h * 0.67f, w * 0.31f, h * 0.215f, furL, furB, furD)
            drawRoundRect(
                Brush.linearGradient(0f to whL, 0.6f to whB, 1f to whD, start = Offset(w * 0.3f, h * 0.47f), end = Offset(w * 0.75f, h * 0.86f)),
                Offset(w * 0.26f, h * 0.47f), Size(w * 0.48f, h * 0.38f), CornerRadius(w * 0.18f)
            )
            drawRoundRect(Color(0x33000000), Offset(w * 0.26f, h * 0.47f), Size(w * 0.48f, h * 0.38f), CornerRadius(w * 0.18f), style = Stroke(w * 0.01f))
            drawLine(Color(0x22000000), Offset(w * 0.5f, h * 0.52f), Offset(w * 0.5f, h * 0.85f), w * 0.008f)
            blob(w * 0.5f, h * 0.60f, w * 0.022f, w * 0.022f, Color(0xFFA0A4B4), Color(0xFF6D7184), Color(0xFF3F4252))
            blob(w * 0.5f, h * 0.70f, w * 0.022f, w * 0.022f, Color(0xFFA0A4B4), Color(0xFF6D7184), Color(0xFF3F4252))

            // кастрюля и пар
            if (action == ChefAction.STIR) {
                drawRoundRect(
                    Brush.verticalGradient(listOf(Color(0xFF8A8FA4), Color(0xFF444859)), h * 0.73f, h * 0.86f),
                    Offset(w * 0.28f, h * 0.73f), Size(w * 0.44f, h * 0.13f), CornerRadius(w * 0.04f)
                )
                drawRoundRect(Color(0xFFB4B9CC), Offset(w * 0.26f, h * 0.715f), Size(w * 0.48f, h * 0.03f), CornerRadius(w * 0.02f))
                for (k in 0..2) {
                    val t = ((phase / 6.2832f) + k / 3f) % 1f
                    drawCircle(Color(0x88FFFFFF), w * (0.025f + 0.02f * t), Offset(w * (0.40f + 0.10f * k + s2 * 0.01f), h * (0.70f - 0.10f * t)))
                }
            }

            // тень под головой
            drawOval(
                Brush.radialGradient(listOf(Color(0x55000000), Color.Transparent), center = Offset(w * 0.5f, h * 0.475f), radius = w * 0.2f),
                Offset(w * 0.3f, h * 0.44f), Size(w * 0.4f, h * 0.07f)
            )

            // уши
            blob(w * 0.24f - yaw * 0.6f, h * 0.27f, w * 0.13f, w * 0.13f, furL, furB, furD)
            blob(w * 0.245f - yaw * 0.6f, h * 0.272f, w * 0.075f, w * 0.075f, pkL, Color(0xFFEDB3C0), pkB)
            blob(w * 0.76f - yaw * 0.6f, h * 0.27f, w * 0.13f, w * 0.13f, furL, furB, furD)
            blob(w * 0.755f - yaw * 0.6f, h * 0.272f, w * 0.075f, w * 0.075f, pkL, Color(0xFFEDB3C0), pkB)

            // голова и морда
            blob(w * 0.5f + yaw * 0.4f, h * 0.335f, w * 0.23f, h * 0.135f, furL, furB, furD)
            blob(w * 0.5f + yaw, h * 0.385f, w * 0.12f, h * 0.072f, snL, snB, snD)
            blob(w * 0.5f + yaw, h * 0.352f, w * 0.05f, h * 0.024f, pkL, pkB, pkD)
            drawCircle(Color(0xCCFFFFFF), w * 0.012f, Offset(w * 0.485f + yaw, h * 0.346f))
            drawCircle(Color(0x44FF6E8E), w * 0.035f, Offset(w * 0.33f + yaw, h * 0.385f))
            drawCircle(Color(0x44FF6E8E), w * 0.035f, Offset(w * 0.67f + yaw, h * 0.385f))

            // глаза
            val happy = blink || action == ChefAction.TASTE || action == ChefAction.CHEER
            for (side in 0..1) {
                val ex = (if (side == 0) 0.40f else 0.60f) * w + yaw * 1.1f
                if (happy) {
                    drawArc(ink, 200f, 140f, false, Offset(ex - w * 0.04f, h * 0.265f), Size(w * 0.08f, h * 0.05f), style = Stroke(w * 0.016f, cap = StrokeCap.Round))
                } else {
                    blob(ex, h * 0.285f, w * 0.052f, w * 0.052f, whL, whB, Color(0xFFB8B0A0))
                    val px = ex + yaw * 0.5f + s1 * w * 0.004f
                    blob(px, h * 0.288f, w * 0.027f, w * 0.028f, Color(0xFF5A5D70), ink, Color.Black)
                    drawCircle(Color.White, w * 0.009f, Offset(px - w * 0.009f, h * 0.280f))
                }
            }

            // усы
            for (i in 0..2) {
                val dy = h * 0.012f * i
                val sway = s2 * h * 0.004f
                drawLine(Color(0xCC4B4F5C), Offset(w * 0.42f + yaw, h * 0.37f + dy), Offset(w * 0.20f + yaw * 0.5f, h * (0.34f + 0.03f * i) + sway), strokeWidth = w * 0.008f)
                drawLine(Color(0xCC4B4F5C), Offset(w * 0.58f + yaw, h * 0.37f + dy), Offset(w * 0.80f + yaw * 0.5f, h * (0.34f + 0.03f * i) + sway), strokeWidth = w * 0.008f)
            }

            // рот и зубки
            if (action == ChefAction.CHEER) {
                drawOval(Color(0xFF3A1E24), Offset(w * 0.44f + yaw, h * 0.395f), Size(w * 0.12f, h * 0.055f))
                drawOval(pkB, Offset(w * 0.47f + yaw, h * 0.428f), Size(w * 0.06f, h * 0.02f))
            } else {
                drawArc(Color(0xFF4B4F5C), 20f, 140f, false, Offset(w * 0.44f + yaw, h * 0.385f), Size(w * 0.12f, h * 0.045f), style = Stroke(w * 0.014f, cap = StrokeCap.Round))
                drawRoundRect(whB, Offset(w * 0.485f + yaw, h * 0.398f), Size(w * 0.03f, h * 0.022f), CornerRadius(w * 0.006f))
            }

            // тень от колпака на лбу
            drawOval(
                Brush.radialGradient(listOf(Color(0x55000000), Color.Transparent), center = Offset(w * 0.5f + yaw * 0.4f, h * 0.235f), radius = w * 0.22f),
                Offset(w * 0.28f, h * 0.22f), Size(w * 0.44f, h * 0.05f)
            )

            // поварской колпак
            blob(w * 0.38f, h * 0.12f, w * 0.09f, w * 0.09f, whL, whB, whD)
            blob(w * 0.62f, h * 0.12f, w * 0.09f, w * 0.09f, whL, whB, whD)
            blob(w * 0.50f, h * 0.085f, w * 0.11f, w * 0.11f, whL, whB, whD)
            drawRoundRect(
                Brush.horizontalGradient(listOf(whD, whL, whB, whD), w * 0.33f, w * 0.67f),
                Offset(w * 0.33f, h * 0.15f), Size(w * 0.34f, h * 0.075f), CornerRadius(w * 0.03f)
            )
            drawRoundRect(Color(0x33000000), Offset(w * 0.33f, h * 0.15f), Size(w * 0.34f, h * 0.075f), CornerRadius(w * 0.03f), style = Stroke(w * 0.008f))

            // руки
            var lx = 0.12f + s1 * 0.008f
            var ly = 0.74f
            var rx = 0.88f - s1 * 0.008f
            var ry = 0.74f
            when (action) {
                ChefAction.WAVE -> { rx = 0.88f + s2 * 0.05f; ry = 0.36f }
                ChefAction.STIR -> { lx = 0.30f; ly = 0.76f; rx = 0.64f + c1 * 0.06f; ry = 0.66f + s1 * 0.025f }
                ChefAction.TASTE -> { rx = 0.60f; ry = 0.43f + s1 * 0.012f }
                ChefAction.CHEER -> { lx = 0.10f; ly = 0.36f + s2 * 0.03f; rx = 0.90f; ry = 0.36f - s2 * 0.03f }
                ChefAction.PULL -> { lx = 0.80f; ly = 0.50f; rx = 0.97f; ry = 0.46f }
                ChefAction.IDLE -> {}
            }
            if (action == ChefAction.STIR) {
                drawLine(wood, Offset(w * rx, h * ry), Offset(w * (rx - 0.05f), h * 0.80f), strokeWidth = w * 0.025f, cap = StrokeCap.Round)
            } else if (action == ChefAction.TASTE) {
                drawLine(wood, Offset(w * rx, h * ry), Offset(w * (rx - 0.05f), h * (ry - 0.06f)), strokeWidth = w * 0.022f, cap = StrokeCap.Round)
                drawOval(wood, Offset(w * (rx - 0.08f), h * (ry - 0.09f)), Size(w * 0.05f, h * 0.03f))
            }
            // объёмные рукава
            for (side in 0..1) {
                val sx = if (side == 0) 0.27f else 0.73f
                val hx = if (side == 0) lx else rx
                val hy = if (side == 0) ly else ry
                drawLine(whD, Offset(w * sx, h * 0.58f), Offset(w * hx, h * hy), strokeWidth = w * 0.105f, cap = StrokeCap.Round)
                drawLine(whB, Offset(w * sx, h * 0.58f), Offset(w * hx, h * hy), strokeWidth = w * 0.085f, cap = StrokeCap.Round)
                drawLine(Color(0xCCFFFFFF), Offset(w * (sx - 0.012f), h * 0.575f), Offset(w * (hx - 0.012f), h * (hy - 0.008f)), strokeWidth = w * 0.03f, cap = StrokeCap.Round)
                blob(w * hx, h * hy, w * 0.05f, w * 0.05f, furL, furB, furD)
            }
        }
    }
}

@Composable
fun DraggableChef(areaW: Float, areaH: Float, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val prefs = remember { ctx.getSharedPreferences("cookbook_prefs", Context.MODE_PRIVATE) }
    val wPx = with(density) { 90.dp.toPx() }
    val hPx = with(density) { 140.dp.toPx() }
    val defX = areaW - wPx - with(density) { 8.dp.toPx() }
    val defY = areaH - hPx - with(density) { 16.dp.toPx() }
    val maxX = (areaW - wPx).coerceAtLeast(0f)
    val maxY = (areaH - hPx).coerceAtLeast(0f)
    var x by remember { mutableFloatStateOf(prefs.getFloat("chef_x", -1f)) }
    var y by remember { mutableFloatStateOf(prefs.getFloat("chef_y", -1f)) }
    val cx = (if (x < 0f) defX else x).coerceIn(0f, maxX)
    val cy = (if (y < 0f) defY else y).coerceIn(0f, maxY)

    var action by remember { mutableStateOf(ChefAction.IDLE) }
    var blink by remember { mutableStateOf(false) }
    val inf = rememberInfiniteTransition(label = "chef")
    val phase by inf.animateFloat(
        initialValue = 0f,
        targetValue = 6.2832f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing)),
        label = "phase"
    )
    LaunchedEffect(Unit) {
        val rnd = kotlin.random.Random.Default
        val all = ChefAction.values().filter { it != ChefAction.PULL }
        while (true) {
            delay(3000L + rnd.nextLong(2500L))
            action = all[rnd.nextInt(all.size)]
        }
    }
    LaunchedEffect(Unit) {
        val rnd = kotlin.random.Random.Default
        while (true) {
            delay(2200L + rnd.nextLong(2500L))
            blink = true
            delay(140)
            blink = false
        }
    }

    ChefMascot(
        Modifier
            .offset { IntOffset(cx.roundToInt(), cy.roundToInt()) }
            .size(width = 90.dp, height = 140.dp)
            .pointerInput(Unit) { detectTapGestures(onTap = { onClick() }) }
            .pointerInput(areaW, areaH) {
                detectDragGestures(
                    onDragStart = { action = ChefAction.CHEER },
                    onDragEnd = {
                        action = ChefAction.IDLE
                        prefs.edit().putFloat("chef_x", x).putFloat("chef_y", y).apply()
                    },
                    onDragCancel = { action = ChefAction.IDLE }
                ) { change, drag ->
                    change.consume()
                    x = ((if (x < 0f) defX else x) + drag.x).coerceIn(0f, maxX)
                    y = ((if (y < 0f) defY else y) + drag.y).coerceIn(0f, maxY)
                }
            },
        action,
        phase,
        blink
    )
}
