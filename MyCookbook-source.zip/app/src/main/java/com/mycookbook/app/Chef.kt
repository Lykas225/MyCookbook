@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.roundToInt

@Composable
fun ChefMascot(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val line = Color(0xFFD9CDBD)
        val stroke = Stroke(w * 0.018f)

        // shadow
        drawOval(Color(0x33000000), Offset(w * 0.14f, h * 0.90f), Size(w * 0.72f, h * 0.08f))
        // fat body
        drawOval(Color.White, Offset(w * 0.08f, h * 0.48f), Size(w * 0.84f, h * 0.44f))
        drawOval(line, Offset(w * 0.08f, h * 0.48f), Size(w * 0.84f, h * 0.44f), style = stroke)
        // buttons
        drawCircle(Color(0xFFB85C3C), w * 0.028f, Offset(w * 0.5f, h * 0.64f))
        drawCircle(Color(0xFFB85C3C), w * 0.028f, Offset(w * 0.5f, h * 0.76f))
        // little arms
        drawCircle(Color.White, w * 0.095f, Offset(w * 0.11f, h * 0.68f))
        drawCircle(line, w * 0.095f, Offset(w * 0.11f, h * 0.68f), style = stroke)
        drawCircle(Color.White, w * 0.095f, Offset(w * 0.89f, h * 0.68f))
        drawCircle(line, w * 0.095f, Offset(w * 0.89f, h * 0.68f), style = stroke)
        // head
        drawCircle(Color(0xFFFFD3B0), w * 0.27f, Offset(w * 0.5f, h * 0.45f))
        drawCircle(Color(0xFFE9B48E), w * 0.27f, Offset(w * 0.5f, h * 0.45f), style = stroke)
        // cheeks
        drawCircle(Color(0x66FF6A6A), w * 0.055f, Offset(w * 0.32f, h * 0.52f))
        drawCircle(Color(0x66FF6A6A), w * 0.055f, Offset(w * 0.68f, h * 0.52f))
        // eyes
        drawCircle(Color(0xFF2B1D14), w * 0.03f, Offset(w * 0.41f, h * 0.45f))
        drawCircle(Color(0xFF2B1D14), w * 0.03f, Offset(w * 0.59f, h * 0.45f))
        // smile
        drawArc(
            Color(0xFF7A2E1E), 15f, 150f, false,
            Offset(w * 0.41f, h * 0.46f), Size(w * 0.18f, h * 0.10f),
            style = Stroke(w * 0.022f, cap = StrokeCap.Round)
        )
        // hat puffs
        drawCircle(Color.White, w * 0.13f, Offset(w * 0.36f, h * 0.17f))
        drawCircle(line, w * 0.13f, Offset(w * 0.36f, h * 0.17f), style = stroke)
        drawCircle(Color.White, w * 0.13f, Offset(w * 0.64f, h * 0.17f))
        drawCircle(line, w * 0.13f, Offset(w * 0.64f, h * 0.17f), style = stroke)
        drawCircle(Color.White, w * 0.16f, Offset(w * 0.5f, h * 0.11f))
        drawCircle(line, w * 0.16f, Offset(w * 0.5f, h * 0.11f), style = stroke)
        // hat band
        drawRoundRect(Color.White, Offset(w * 0.27f, h * 0.20f), Size(w * 0.46f, h * 0.12f), CornerRadius(w * 0.04f))
        drawRoundRect(line, Offset(w * 0.27f, h * 0.20f), Size(w * 0.46f, h * 0.12f), CornerRadius(w * 0.04f), style = stroke)
    }
}

@Composable
fun DraggableChef(areaW: Float, areaH: Float, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val prefs = remember { ctx.getSharedPreferences("cookbook_prefs", Context.MODE_PRIVATE) }
    val sizePx = with(density) { 84.dp.toPx() }
    val defX = areaW - sizePx - with(density) { 16.dp.toPx() }
    val defY = areaH - sizePx - with(density) { 24.dp.toPx() }
    val maxX = (areaW - sizePx).coerceAtLeast(0f)
    val maxY = (areaH - sizePx).coerceAtLeast(0f)
    var x by remember { mutableFloatStateOf(prefs.getFloat("chef_x", -1f)) }
    var y by remember { mutableFloatStateOf(prefs.getFloat("chef_y", -1f)) }
    val cx = (if (x < 0f) defX else x).coerceIn(0f, maxX)
    val cy = (if (y < 0f) defY else y).coerceIn(0f, maxY)

    ChefMascot(
        Modifier
            .offset { IntOffset(cx.roundToInt(), cy.roundToInt()) }
            .size(84.dp)
            .pointerInput(Unit) { detectTapGestures(onTap = { onClick() }) }
            .pointerInput(areaW, areaH) {
                detectDragGestures(
                    onDragEnd = { prefs.edit().putFloat("chef_x", x).putFloat("chef_y", y).apply() }
                ) { change, drag ->
                    change.consume()
                    x = ((if (x < 0f) defX else x) + drag.x).coerceIn(0f, maxX)
                    y = ((if (y < 0f) defY else y) + drag.y).coerceIn(0f, maxY)
                }
            }
    )
}
