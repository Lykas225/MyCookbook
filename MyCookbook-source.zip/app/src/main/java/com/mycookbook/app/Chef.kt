@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

enum class ChefAction { IDLE, WAVE, STIR, TASTE, CHEER, PULL }

/** Оригинальный мультяшный крыс-повар во весь рост. */
@Composable
fun ChefMascot(modifier: Modifier, action: ChefAction, phase: Float, blink: Boolean) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val fur = Color(0xFF8E93A3)
        val furDark = Color(0xFF6F7485)
        val outline = Color(0xFF4B4F5C)
        val pink = Color(0xFFE98BA0)
        val earIn = Color(0xFFEDB3C0)
        val snout = Color(0xFFDDD6CC)
        val white = Color.White
        val cream = Color(0xFFE2D8C6)
        val wood = Color(0xFFB9854F)
        val st = Stroke(w * 0.016f)

        val s1 = sin(phase)
        val c1 = cos(phase)
        val s2 = sin(phase * 2f)
        val jump = if (action == ChefAction.CHEER) abs(s1) * h * 0.09f else 0f
        val bob = if (action == ChefAction.IDLE) s1 * h * 0.006f else 0f

        // тень
        val sh = 1f - jump / (h * 0.25f)
        drawOval(Color(0x33000000), Offset(w * (0.5f - 0.30f * sh), h * 0.945f), Size(w * 0.60f * sh, h * 0.045f))

        translate(top = bob - jump) {
            // хвост
            val tail = Path()
            tail.moveTo(w * 0.70f, h * 0.82f)
            tail.cubicTo(w * 0.98f + s2 * w * 0.05f, h * 0.84f, w * 0.99f, h * 0.70f, w * 0.90f + s2 * w * 0.07f, h * 0.60f)
            drawPath(tail, pink, style = Stroke(w * 0.035f, cap = StrokeCap.Round))

            // ноги и ступни
            drawRoundRect(furDark, Offset(w * 0.33f, h * 0.84f), Size(w * 0.12f, h * 0.09f), CornerRadius(w * 0.04f))
            drawRoundRect(furDark, Offset(w * 0.55f, h * 0.84f), Size(w * 0.12f, h * 0.09f), CornerRadius(w * 0.04f))
            drawOval(Color(0xFFA39A9A), Offset(w * 0.28f, h * 0.915f), Size(w * 0.21f, h * 0.05f))
            drawOval(Color(0xFFA39A9A), Offset(w * 0.51f, h * 0.915f), Size(w * 0.21f, h * 0.05f))

            // тело и поварской китель
            drawOval(fur, Offset(w * 0.20f, h * 0.46f), Size(w * 0.60f, h * 0.42f))
            drawOval(outline, Offset(w * 0.20f, h * 0.46f), Size(w * 0.60f, h * 0.42f), style = st)
            drawRoundRect(white, Offset(w * 0.26f, h * 0.47f), Size(w * 0.48f, h * 0.38f), CornerRadius(w * 0.18f))
            drawRoundRect(cream, Offset(w * 0.26f, h * 0.47f), Size(w * 0.48f, h * 0.38f), CornerRadius(w * 0.18f), style = st)
            drawCircle(Color(0xFF7A7F8F), w * 0.02f, Offset(w * 0.5f, h * 0.60f))
            drawCircle(Color(0xFF7A7F8F), w * 0.02f, Offset(w * 0.5f, h * 0.70f))

            // кастрюля и пар
            if (action == ChefAction.STIR) {
                drawRoundRect(Color(0xFF55596B), Offset(w * 0.28f, h * 0.73f), Size(w * 0.44f, h * 0.13f), CornerRadius(w * 0.04f))
                drawRoundRect(Color(0xFF7C8196), Offset(w * 0.26f, h * 0.715f), Size(w * 0.48f, h * 0.03f), CornerRadius(w * 0.02f))
                for (k in 0..2) {
                    val t = ((phase / 6.2832f) + k / 3f) % 1f
                    drawCircle(Color(0x88FFFFFF), w * (0.025f + 0.02f * t), Offset(w * (0.40f + 0.10f * k + s2 * 0.01f), h * (0.70f - 0.10f * t)))
                }
            }

            // голова: уши, морда
            drawCircle(fur, w * 0.13f, Offset(w * 0.24f, h * 0.27f))
            drawCircle(earIn, w * 0.075f, Offset(w * 0.24f, h * 0.27f))
            drawCircle(outline, w * 0.13f, Offset(w * 0.24f, h * 0.27f), style = st)
            drawCircle(fur, w * 0.13f, Offset(w * 0.76f, h * 0.27f))
            drawCircle(earIn, w * 0.075f, Offset(w * 0.76f, h * 0.27f))
            drawCircle(outline, w * 0.13f, Offset(w * 0.76f, h * 0.27f), style = st)
            drawOval(fur, Offset(w * 0.27f, h * 0.20f), Size(w * 0.46f, h * 0.27f))
            drawOval(outline, Offset(w * 0.27f, h * 0.20f), Size(w * 0.46f, h * 0.27f), style = st)
            drawOval(snout, Offset(w * 0.38f, h * 0.31f), Size(w * 0.24f, h * 0.15f))
            drawOval(pink, Offset(w * 0.45f, h * 0.325f), Size(w * 0.10f, h * 0.045f))
            drawCircle(Color(0x55FF7A9A), w * 0.035f, Offset(w * 0.33f, h * 0.385f))
            drawCircle(Color(0x55FF7A9A), w * 0.035f, Offset(w * 0.67f, h * 0.385f))

            // глаза
            val happy = blink || action == ChefAction.TASTE || action == ChefAction.CHEER
            for (side in 0..1) {
                val ex = if (side == 0) 0.40f else 0.60f
                if (happy) {
                    drawArc(outline, 200f, 140f, false, Offset(w * (ex - 0.04f), h * 0.265f), Size(w * 0.08f, h * 0.05f), style = Stroke(w * 0.016f, cap = StrokeCap.Round))
                } else {
                    drawCircle(white, w * 0.05f, Offset(w * ex, h * 0.285f))
                    drawCircle(outline, w * 0.05f, Offset(w * ex, h * 0.285f), style = Stroke(w * 0.01f))
                    drawCircle(Color(0xFF22242B), w * 0.024f, Offset(w * ex + s1 * w * 0.006f, h * 0.288f))
                }
            }

            // усы
            for (i in 0..2) {
                val dy = h * 0.012f * i
                val sway = s2 * h * 0.004f
                drawLine(outline, Offset(w * 0.42f, h * 0.37f + dy), Offset(w * 0.20f, h * (0.34f + 0.03f * i) + sway), strokeWidth = w * 0.008f)
                drawLine(outline, Offset(w * 0.58f, h * 0.37f + dy), Offset(w * 0.80f, h * (0.34f + 0.03f * i) + sway), strokeWidth = w * 0.008f)
            }

            // рот и зубки
            if (action == ChefAction.CHEER) {
                drawOval(Color(0xFF3A1E24), Offset(w * 0.44f, h * 0.385f), Size(w * 0.12f, h * 0.055f))
                drawOval(pink, Offset(w * 0.47f, h * 0.418f), Size(w * 0.06f, h * 0.02f))
            } else {
                drawArc(outline, 20f, 140f, false, Offset(w * 0.44f, h * 0.375f), Size(w * 0.12f, h * 0.045f), style = Stroke(w * 0.014f, cap = StrokeCap.Round))
                drawRoundRect(white, Offset(w * 0.485f, h * 0.388f), Size(w * 0.03f, h * 0.022f), CornerRadius(w * 0.006f))
            }

            // поварской колпак
            drawCircle(white, w * 0.09f, Offset(w * 0.38f, h * 0.12f))
            drawCircle(white, w * 0.09f, Offset(w * 0.62f, h * 0.12f))
            drawCircle(white, w * 0.11f, Offset(w * 0.50f, h * 0.085f))
            drawCircle(cream, w * 0.09f, Offset(w * 0.38f, h * 0.12f), style = st)
            drawCircle(cream, w * 0.09f, Offset(w * 0.62f, h * 0.12f), style = st)
            drawRoundRect(white, Offset(w * 0.33f, h * 0.15f), Size(w * 0.34f, h * 0.075f), CornerRadius(w * 0.03f))
            drawRoundRect(cream, Offset(w * 0.33f, h * 0.15f), Size(w * 0.34f, h * 0.075f), CornerRadius(w * 0.03f), style = st)

            // руки
            var lx = 0.12f + s1 * 0.008f
            var ly = 0.74f
            var rx = 0.88f - s1 * 0.008f
            var ry = 0.74f
            when (action) {
                ChefAction.WAVE -> { rx = 0.88f + s2 * 0.05f; ry = 0.36f }
                ChefAction.STIR -> { lx = 0.30f; ly = 0.76f; rx = 0.64f + c1 * 0.06f; ry = 0.66f + s1 * 0.025f }
                ChefAction.TASTE -> { rx = 0.60f; ry = 0.43f + s1 * 0.012f }
                ChefAction.CHEER -> { lx = 0.10f; ly = 0.36f + s2 * 0.03f; rx = 0.90f; ry = 0.36f - s2 * 0.03f }
                ChefAction.PULL -> { lx = 0.80f; ly = 0.50f; rx = 0.97f; ry = 0.46f }
                ChefAction.IDLE -> {}
            }
            // ложка
            if (action == ChefAction.STIR) {
                drawLine(wood, Offset(w * rx, h * ry), Offset(w * (rx - 0.05f), h * 0.80f), strokeWidth = w * 0.025f, cap = StrokeCap.Round)
            } else if (action == ChefAction.TASTE) {
                drawLine(wood, Offset(w * rx, h * ry), Offset(w * (rx - 0.05f), h * (ry - 0.06f)), strokeWidth = w * 0.022f, cap = StrokeCap.Round)
                drawOval(wood, Offset(w * (rx - 0.08f), h * (ry - 0.09f)), Size(w * 0.05f, h * 0.03f))
            }
            // рукава и ладони
            drawLine(white, Offset(w * 0.27f, h * 0.58f), Offset(w * lx, h * ly), strokeWidth = w * 0.10f, cap = StrokeCap.Round)
            drawLine(white, Offset(w * 0.73f, h * 0.58f), Offset(w * rx, h * ry), strokeWidth = w * 0.10f, cap = StrokeCap.Round)
            drawCircle(fur, w * 0.05f, Offset(w * lx, h * ly))
            drawCircle(fur, w * 0.05f, Offset(w * rx, h * ry))
            drawCircle(outline, w * 0.05f, Offset(w * lx, h * ly), style = Stroke(w * 0.01f))
            drawCircle(outline, w * 0.05f, Offset(w * rx, h * ry), style = Stroke(w * 0.01f))
        }
    }
}

@Composable
fun DraggableChef(areaW: Float, areaH: Float, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val prefs = remember { ctx.getSharedPreferences("cookbook_prefs", Context.MODE_PRIVATE) }
    val wPx = with(density) { 90.dp.toPx() }
    val hPx = with(density) { 140.dp.toPx() }
    val defX = areaW - wPx - with(density) { 8.dp.toPx() }
    val defY = areaH - hPx - with(density) { 16.dp.toPx() }
    val maxX = (areaW - wPx).coerceAtLeast(0f)
    val maxY = (areaH - hPx).coerceAtLeast(0f)
    var x by remember { mutableFloatStateOf(prefs.getFloat("chef_x", -1f)) }
    var y by remember { mutableFloatStateOf(prefs.getFloat("chef_y", -1f)) }
    val cx = (if (x < 0f) defX else x).coerceIn(0f, maxX)
    val cy = (if (y < 0f) defY else y).coerceIn(0f, maxY)

    var action by remember { mutableStateOf(ChefAction.IDLE) }
    var blink by remember { mutableStateOf(false) }
    val inf = rememberInfiniteTransition(label = "chef")
    val phase by inf.animateFloat(
        initialValue = 0f,
        targetValue = 6.2832f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing)),
        label = "phase"
    )
    LaunchedEffect(Unit) {
        val rnd = kotlin.random.Random.Default
        val all = ChefAction.values().filter { it != ChefAction.PULL }
        while (true) {
            delay(3000L + rnd.nextLong(2500L))
            action = all[rnd.nextInt(all.size)]
        }
    }
    LaunchedEffect(Unit) {
        val rnd = kotlin.random.Random.Default
        while (true) {
            delay(2200L + rnd.nextLong(2500L))
            blink = true
            delay(140)
            blink = false
        }
    }

    ChefMascot(
        Modifier
            .offset { IntOffset(cx.roundToInt(), cy.roundToInt()) }
            .size(width = 90.dp, height = 140.dp)
            .pointerInput(Unit) { detectTapGestures(onTap = { onClick() }) }
            .pointerInput(areaW, areaH) {
                detectDragGestures(
                    onDragStart = { action = ChefAction.CHEER },
                    onDragEnd = {
                        action = ChefAction.IDLE
                        prefs.edit().putFloat("chef_x", x).putFloat("chef_y", y).apply()
                    },
                    onDragCancel = { action = ChefAction.IDLE }
                ) { change, drag ->
                    change.consume()
                    x = ((if (x < 0f) defX else x) + drag.x).coerceIn(0f, maxX)
                    y = ((if (y < 0f) defY else y) + drag.y).coerceIn(0f, maxY)
                }
            },
        action,
        phase,
        blink
    )
}
