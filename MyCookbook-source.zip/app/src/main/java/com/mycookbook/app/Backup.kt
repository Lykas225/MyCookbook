@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

object BackupIO {
    fun export(ctx: Context, json: JSONObject, paths: List<String>, uri: android.net.Uri): Int {
        var count = 0
        val out = ctx.contentResolver.openOutputStream(uri) ?: throw Exception("не удалось открыть файл")
        java.util.zip.ZipOutputStream(out.buffered()).use { z ->
            z.putNextEntry(java.util.zip.ZipEntry("cookbook.json"))
            z.write(json.toString().toByteArray(Charsets.UTF_8))
            z.closeEntry()
            for (p in paths) {
                val f = File(p)
                if (!f.exists()) continue
                z.putNextEntry(java.util.zip.ZipEntry("media/" + f.name))
                f.inputStream().use { it.copyTo(z) }
                z.closeEntry()
                count++
            }
        }
        return count
    }

    fun readBackup(ctx: Context, uri: android.net.Uri): JSONObject {
        val dir = MediaFiles.dir(ctx)
        var json: String? = null
        val input = ctx.contentResolver.openInputStream(uri) ?: throw Exception("не удалось открыть файл")
        java.util.zip.ZipInputStream(input.buffered()).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (e.isDirectory) continue
                if (e.name == "cookbook.json") {
                    json = String(z.readBytes(), Charsets.UTF_8)
                } else if (e.name.startsWith("media/")) {
                    val name = File(e.name).name
                    if (name.isNotEmpty()) File(dir, name).outputStream().use { o -> z.copyTo(o) }
                }
            }
        }
        val text = json ?: throw Exception("это не копия MyCookbook")
        return JSONObject(text)
    }
}

@Composable
fun BackupScreen(store: CookbookStore, nav: NavHostController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var pendingImport by remember { mutableStateOf<android.net.Uri?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            val data = store.exportData()
            val paths = (store.media.map { it.path } + store.recipes.flatMap { r -> r.steps.mapNotNull { it.mediaPath } }).distinct()
            scope.launch {
                busy = true
                status = "Сохраняю…"
                try {
                    val n = withContext(Dispatchers.IO) { BackupIO.export(ctx, data, paths, uri) }
                    status = "Готово: рецептов ${store.recipes.size}, файлов фото и видео $n"
                } catch (e: Exception) {
                    status = "Ошибка: " + (e.message ?: "не удалось сохранить")
                }
                busy = false
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) pendingImport = uri
    }

    fun doImport(uri: android.net.Uri, replace: Boolean) {
        scope.launch {
            busy = true
            status = "Восстанавливаю…"
            try {
                val json = withContext(Dispatchers.IO) { BackupIO.readBackup(ctx, uri) }
                val n = store.importData(json, MediaFiles.dir(ctx), replace)
                status = "Готово: добавлено рецептов $n"
            } catch (e: Exception) {
                status = "Ошибка: " + (e.message ?: "не удалось прочитать файл")
            }
            busy = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Резервная копия") },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Сохраните всю книгу одним файлом: рецепты, заметки, план питания, фото и видео. На новом телефоне установите приложение и восстановите книгу из этого файла.")
            Text(
                "Файл лучше сохранить в облако (Google Диск) или отправить себе — тогда он не потеряется вместе с телефоном.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            Button(
                onClick = { exportLauncher.launch("MyCookbook-backup-" + java.time.LocalDate.now() + ".zip") },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Filled.Add, null)
                Spacer(Modifier.width(8.dp))
                Text("Сохранить копию в файл")
            }
            OutlinedButton(
                onClick = { importLauncher.launch(arrayOf("*/*")) },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) { Text("Восстановить из файла") }
            if (status.isNotBlank()) {
                Text(status, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            }
        }
    }

    pendingImport?.let { uri ->
        AlertDialog(
            onDismissRequest = { pendingImport = null },
            title = { Text("Как восстановить?") },
            text = { Text("«Добавить» оставит ваши текущие рецепты и добавит из файла новые. «Заменить всё» полностью заменит книгу содержимым файла.") },
            confirmButton = { TextButton(onClick = { pendingImport = null; doImport(uri, false) }) { Text("Добавить") } },
            dismissButton = { TextButton(onClick = { pendingImport = null; doImport(uri, true) }) { Text("Заменить всё") } }
        )
    }
}
