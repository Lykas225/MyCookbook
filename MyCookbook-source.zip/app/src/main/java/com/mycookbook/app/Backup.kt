@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

object BackupIO {
    fun writeZip(out: java.io.OutputStream, json: JSONObject, paths: List<String>): Int {
        var count = 0
        java.util.zip.ZipOutputStream(out.buffered()).use { z ->
            z.putNextEntry(java.util.zip.ZipEntry("cookbook.json"))
            z.write(json.toString().toByteArray(Charsets.UTF_8))
            z.closeEntry()
            for (p in paths) {
                val f = File(p)
                if (!f.exists()) continue
                z.putNextEntry(java.util.zip.ZipEntry("media/" + f.name))
                f.inputStream().use { it.copyTo(z) }
                z.closeEntry()
                count++
            }
        }
        return count
    }

    fun export(ctx: Context, json: JSONObject, paths: List<String>, uri: android.net.Uri): Int {
        val out = ctx.contentResolver.openOutputStream(uri) ?: throw Exception("не удалось открыть файл")
        return writeZip(out, json, paths)
    }

    /** Копия в выбранную папку (например, на Google Диске). Старая копия заменяется. */
    fun exportToTree(ctx: Context, tree: android.net.Uri, json: JSONObject, paths: List<String>): Int {
        val dir = androidx.documentfile.provider.DocumentFile.fromTreeUri(ctx, tree)
            ?: throw Exception("папка недоступна")
        if (!dir.canWrite()) throw Exception("нет доступа к папке, выберите её заново")
        val name = "MyCookbook-backup.zip"
        dir.findFile(name)?.delete()
        val f = dir.createFile("application/zip", name) ?: throw Exception("не удалось создать файл в папке")
        return export(ctx, json, paths, f.uri)
    }

    fun readBackup(ctx: Context, uri: android.net.Uri): JSONObject {
        val dir = MediaFiles.dir(ctx)
        var json: String? = null
        val input = ctx.contentResolver.openInputStream(uri) ?: throw Exception("не удалось открыть файл")
        java.util.zip.ZipInputStream(input.buffered()).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (e.isDirectory) continue
                if (e.name == "cookbook.json") {
                    json = String(z.readBytes(), Charsets.UTF_8)
                } else if (e.name.startsWith("media/")) {
                    val name = File(e.name).name
                    if (name.isNotEmpty()) File(dir, name).outputStream().use { o -> z.copyTo(o) }
                }
            }
        }
        val text = json ?: throw Exception("это не копия MyCookbook")
        return JSONObject(text)
    }
}

/** Копия в папку, выбранную пользователем. Вызывать из основного потока. */
suspend fun runTreeBackup(ctx: Context, store: CookbookStore): Int {
    val p = ctx.getSharedPreferences("cookbook_prefs", Context.MODE_PRIVATE)
    val tree = p.getString("backup_tree", null) ?: throw Exception("папка не выбрана")
    val data = store.exportData()
    val paths = store.backupPaths()
    val n = withContext(Dispatchers.IO) { BackupIO.exportToTree(ctx, android.net.Uri.parse(tree), data, paths) }
    p.edit().putLong("backup_last", System.currentTimeMillis()).apply()
    return n
}

fun recipeToText(r: Recipe): String {
    val sb = StringBuilder()
    sb.append("🍽 ").append(r.title).append("\n")
    val head = listOfNotNull(
        r.cuisine.ifBlank { null },
        CATEGORIES.getOrNull(r.category)?.second,
        if (r.timeMin > 0) "⏱ " + formatTime(r.timeMin) else null,
        if (r.tempC > 0) "🌡 " + r.tempC + " °C" else null,
        "порций: " + r.servings
    )
    sb.append(head.joinToString(" · ")).append("\n")
    if (r.description.isNotBlank()) sb.append("\n").append(r.description).append("\n")
    if (r.ingredients.isNotEmpty()) {
        sb.append("\nИнгредиенты:\n")
        r.ingredients.forEach {
            val a = ingredientLine(it, 1.0)
            sb.append("• ").append(it.name)
            if (a.isNotBlank()) sb.append(" — ").append(a)
            sb.append("\n")
        }
    }
    if (r.steps.isNotEmpty()) {
        sb.append("\nПриготовление:\n")
        r.steps.forEachIndexed { i, s ->
            sb.append(i + 1).append(". ").append(s.text)
            if (s.timerMin > 0) sb.append(" (").append(s.timerMin).append(" мин)")
            sb.append("\n")
        }
    }
    if (r.secrets.isNotBlank()) sb.append("\n💡 ").append(r.secrets).append("\n")
    if (r.notes.isNotBlank()) sb.append("\n📝 ").append(r.notes).append("\n")
    sb.append("\n— из приложения MyCookbook")
    return sb.toString()
}

fun shareRecipeText(ctx: Context, store: CookbookStore, r: Recipe) {
    val i = android.content.Intent(android.content.Intent.ACTION_SEND)
    val cover = store.coverOf(r.id)
    if (cover != null && !cover.isVideo) {
        val uri = MediaFiles.uriFor(ctx, File(cover.path))
        i.type = "image/*"
        i.putExtra(android.content.Intent.EXTRA_STREAM, uri)
        i.clipData = android.content.ClipData.newRawUri("", uri)
        i.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    } else {
        i.type = "text/plain"
    }
    i.putExtra(android.content.Intent.EXTRA_TEXT, recipeToText(r))
    i.putExtra(android.content.Intent.EXTRA_SUBJECT, r.title)
    val chooser = android.content.Intent.createChooser(i, "Поделиться рецептом")
    chooser.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(chooser)
}

suspend fun shareRecipeFile(ctx: Context, store: CookbookStore, r: Recipe) {
    val json = store.exportRecipe(r.id)
    val paths = store.recipePaths(r.id)
    val dir = File(ctx.cacheDir, "share")
    dir.mkdirs()
    dir.listFiles()?.forEach { it.delete() }
    val safe = r.title.replace(Regex("[^\\p{L}\\p{N}]+"), "_").trim('_').ifBlank { "recipe" }.take(40)
    val f = File(dir, "MyCookbook-" + safe + ".zip")
    withContext(Dispatchers.IO) { f.outputStream().use { BackupIO.writeZip(it, json, paths) } }
    val uri = androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
    val i = android.content.Intent(android.content.Intent.ACTION_SEND)
    i.type = "application/zip"
    i.putExtra(android.content.Intent.EXTRA_STREAM, uri)
    i.putExtra(android.content.Intent.EXTRA_TEXT, "Рецепт «" + r.title + "». Откройте файл в приложении MyCookbook.")
    i.clipData = android.content.ClipData.newRawUri("", uri)
    i.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    val chooser = android.content.Intent.createChooser(i, "Поделиться файлом рецепта")
    chooser.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(chooser)
}

@Composable
fun BackupScreen(store: CookbookStore, nav: NavHostController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("cookbook_prefs", Context.MODE_PRIVATE) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var pendingImport by remember { mutableStateOf<android.net.Uri?>(null) }
    var tree by remember { mutableStateOf(prefs.getString("backup_tree", null)) }
    var last by remember { mutableStateOf(prefs.getLong("backup_last", 0L)) }

    LaunchedEffect(Unit) {
        val p = store.pendingImport
        if (p != null) {
            pendingImport = android.net.Uri.parse(p)
            store.pendingImport = null
        }
    }

    fun backupToTree() {
        if (busy) return
        scope.launch {
            busy = true
            status = "Сохраняю копию в папку…"
            try {
                val n = runTreeBackup(ctx, store)
                last = prefs.getLong("backup_last", 0L)
                status = "Копия сохранена: рецептов ${store.recipes.size}, файлов $n"
            } catch (e: Exception) {
                status = "Ошибка: " + (e.message ?: "не удалось сохранить")
            }
            busy = false
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            val data = store.exportData()
            val paths = store.backupPaths()
            scope.launch {
                busy = true
                status = "Сохраняю…"
                try {
                    val n = withContext(Dispatchers.IO) { BackupIO.export(ctx, data, paths, uri) }
                    status = "Готово: рецептов ${store.recipes.size}, файлов фото и видео $n"
                } catch (e: Exception) {
                    status = "Ошибка: " + (e.message ?: "не удалось сохранить")
                }
                busy = false
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) pendingImport = uri
    }
    val treeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (e: Exception) {
            }
            prefs.edit().putString("backup_tree", uri.toString()).putLong("backup_last", 0L).apply()
            tree = uri.toString()
            last = 0L
            backupToTree()
        }
    }

    fun doImport(uri: android.net.Uri, replace: Boolean) {
        scope.launch {
            busy = true
            status = "Восстанавливаю…"
            try {
                val json = withContext(Dispatchers.IO) { BackupIO.readBackup(ctx, uri) }
                val n = store.importData(json, MediaFiles.dir(ctx), replace)
                status = "Готово: добавлено рецептов $n"
            } catch (e: Exception) {
                status = "Ошибка: " + (e.message ?: "не удалось прочитать файл")
            }
            busy = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Резервная копия") },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())

            Text("☁️ Автоматическая копия в Google Диск", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "Выберите папку на Google Диске один раз. Приложение само обновляет в ней копию книги раз в сутки при запуске. " +
                    "В окне выбора откройте меню (три полоски) → Диск → нужную папку или создайте новую."
            )
            if (tree == null) {
                Button(
                    onClick = { treeLauncher.launch(null) },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(16.dp)
                ) { Text("Выбрать папку на Google Диске") }
            } else {
                val whenText = if (last > 0L) java.text.SimpleDateFormat("d MMM yyyy, HH:mm", Locale("ru")).format(java.util.Date(last)) else "ещё не делалась"
                Text("Папка выбрана ✓. Последняя копия: $whenText", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                Button(
                    onClick = { backupToTree() },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(16.dp)
                ) { Text("Сделать копию сейчас") }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { treeLauncher.launch(null) }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("Другая папка") }
                    OutlinedButton(
                        onClick = {
                            prefs.edit().remove("backup_tree").apply()
                            tree = null
                        },
                        enabled = !busy,
                        modifier = Modifier.weight(1f)
                    ) { Text("Отключить") }
                }
            }

            HorizontalDivider()

            Text("💾 Копия в файл", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Один zip-файл со всей книгой: рецепты, заметки, план, список покупок, фото и видео. Сохранить можно куда угодно, в том числе на Google Диск.")
            Button(
                onClick = { exportLauncher.launch("MyCookbook-backup-" + java.time.LocalDate.now() + ".zip") },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Filled.Add, null)
                Spacer(Modifier.width(8.dp))
                Text("Сохранить копию в файл")
            }
            OutlinedButton(
                onClick = { importLauncher.launch(arrayOf("*/*")) },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) { Text("Восстановить из файла (в том числе с Диска)") }

            if (status.isNotBlank()) {
                Text(status, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            }
        }
    }

    pendingImport?.let { uri ->
        AlertDialog(
            onDismissRequest = { pendingImport = null },
            title = { Text("Как восстановить?") },
            text = { Text("«Добавить» оставит ваши текущие рецепты и добавит из файла новые. «Заменить всё» полностью заменит книгу содержимым файла.") },
            confirmButton = { TextButton(onClick = { pendingImport = null; doImport(uri, false) }) { Text("Добавить") } },
            dismissButton = { TextButton(onClick = { pendingImport = null; doImport(uri, true) }) { Text("Заменить всё") } }
        )
    }
}
