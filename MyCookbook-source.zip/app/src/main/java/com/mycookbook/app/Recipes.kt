@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.navigation.NavHostController

@Composable
fun RecipesScreen(
    store: CookbookStore,
    nav: NavHostController,
    initialCat: Int,
    initialSub: String = ""
) {
    var query by remember { mutableStateOf("") }
    var cat by remember(initialCat) { mutableIntStateOf(initialCat) }
    var sub by remember(initialCat, initialSub) { mutableStateOf(initialSub) }
    var onlyFav by remember { mutableStateOf(false) }
    var cui by remember { mutableStateOf(store.cuisineFilter) }
    var cuiMenuOpen by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { store.cuisineFilter = "" }
    LaunchedEffect(store.searchQuery) {
        if (store.searchQuery.isNotBlank()) {
            query = store.searchQuery
            store.searchQuery = ""
        }
    }

    val activeSubs = remember(cat) { subCategoriesOf(cat) }
    val catRecipes = remember(store.recipes, cat) {
        if (cat == -1) store.recipes else store.recipes.filter { it.category == cat }
    }

    val q = query.trim().lowercase()
    val list = remember(catRecipes, sub, onlyFav, cui, q) {
        catRecipes
            .filter { sub.isEmpty() || effectiveSubCategory(it) == sub }
            .filter { !onlyFav || it.favorite }
            .filter { cui.isEmpty() || it.cuisine == cui }
            .filter { r ->
                q.isEmpty() ||
                    r.title.lowercase().contains(q) ||
                    r.cuisine.lowercase().contains(q) ||
                    r.ingredients.any { it.name.lowercase().contains(q) } ||
                    (subCategoryInfo(r.category, effectiveSubCategory(r))?.title?.lowercase()?.contains(q) == true)
            }
            .sortedBy { it.title.lowercase() }
    }

    val cuisines = remember(store.recipes) {
        store.recipes.map { it.cuisine }.filter { it.isNotBlank() }.distinct().sorted()
    }

    val headerTitle = if (cat in CATEGORIES.indices) {
        "${CATEGORIES[cat].first} ${CATEGORIES[cat].second}"
    } else {
        "Рецепты"
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            // Заголовок раздела + быстрые фильтры (Любимые и Кухни мира)
            Row(
                Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(start = if (cat != -1) 4.dp else 16.dp, end = 12.dp, top = 8.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (cat != -1) {
                    IconButton(onClick = {
                        if (sub.isNotEmpty()) {
                            sub = ""
                        } else {
                            cat = -1
                        }
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Все разделы")
                    }
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        headerTitle,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (sub.isNotEmpty()) {
                        val subInf = subCategoryInfo(cat, sub)
                        if (subInf != null) {
                            Text(
                                "${subInf.emoji} ${subInf.title}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
                IconButton(onClick = { onlyFav = !onlyFav }) {
                    Icon(
                        if (onlyFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        "Любимые",
                        tint = if (onlyFav) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (cuisines.isNotEmpty()) {
                    Box {
                        FilterChip(
                            selected = cui.isNotEmpty(),
                            onClick = { cuiMenuOpen = true },
                            label = {
                                Text(
                                    if (cui.isEmpty()) "🌍 Кухни" else cui,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontSize = 12.sp
                                )
                            }
                        )
                        DropdownMenu(expanded = cuiMenuOpen, onDismissRequest = { cuiMenuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("🌍 Все кухни", fontWeight = if (cui.isEmpty()) FontWeight.Bold else FontWeight.Normal) },
                                onClick = { cui = ""; cuiMenuOpen = false }
                            )
                            cuisines.forEach { c ->
                                DropdownMenuItem(
                                    text = { Text(c, fontWeight = if (cui == c) FontWeight.Bold else FontWeight.Normal) },
                                    onClick = { cui = c; cuiMenuOpen = false }
                                )
                            }
                        }
                    }
                }
            }

            // Поиск по рецептам
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Название или продукт") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, "Очистить") }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            )

            // 1-й уровень навигации: основные разделы книги
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = cat == -1,
                        onClick = { cat = -1; sub = "" },
                        label = { Text("📖 Все (${store.recipes.size})") }
                    )
                }
                items(CATEGORIES.indices.toList()) { i ->
                    FilterChip(
                        selected = cat == i,
                        onClick = {
                            if (cat == i) {
                                cat = -1
                                sub = ""
                            } else {
                                cat = i
                                sub = ""
                            }
                        },
                        label = { Text(CATEGORIES[i].first + " " + CATEGORIES[i].second) }
                    )
                }
            }

            // Список рецептов + 2-й уровень навигации (карточки подразделов внутри выбранного раздела)
            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 2.dp, bottom = 88.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (activeSubs.isNotEmpty()) {
                    item(key = "subs_panel_$cat") {
                        Column(
                            Modifier.fillMaxWidth().padding(bottom = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    if (cat == 5) "Выберите вид выпечки" else "Подразделы",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.weight(1f)
                                )
                                if (sub.isNotEmpty()) {
                                    TextButton(
                                        onClick = { sub = "" },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                    ) {
                                        Text("Показать все (${catRecipes.size})", fontSize = 12.sp)
                                    }
                                }
                            }
                            activeSubs.chunked(2).forEach { pair ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    pair.forEach { sInfo ->
                                        val sCount = catRecipes.count { effectiveSubCategory(it) == sInfo.id }
                                        val selected = sub == sInfo.id
                                        Card(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(14.dp))
                                                .clickable { sub = if (selected) "" else sInfo.id },
                                            colors = CardDefaults.cardColors(
                                                containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer
                                                else MaterialTheme.colorScheme.surfaceVariant
                                            ),
                                            border = BorderStroke(
                                                width = if (selected) 2.dp else 1.dp,
                                                color = if (selected) MaterialTheme.colorScheme.primary
                                                else MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)
                                            )
                                        ) {
                                            Row(
                                                Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(sInfo.emoji, fontSize = 22.sp)
                                                Spacer(Modifier.width(8.dp))
                                                Column(Modifier.weight(1f)) {
                                                    Text(
                                                        sInfo.title,
                                                        style = MaterialTheme.typography.bodyMedium,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer
                                                        else MaterialTheme.colorScheme.onSurface,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                    Text(
                                                        "$sCount рец.",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                                        else MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                if (selected) {
                                                    Icon(
                                                        Icons.Filled.CheckCircle,
                                                        null,
                                                        tint = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }

                if (list.isEmpty()) {
                    item {
                        HintText(
                            if (sub.isNotEmpty()) "В этом подразделе пока нет рецептов. Нажмите «Добавить» или сбросьте фильтр."
                            else "Рецептов не найдено. Нажмите «Добавить», чтобы создать первый."
                        )
                    }
                }
                items(list, key = { it.id }) { r ->
                    RecipeRow(store, r) { nav.navigate("recipe/${r.id}") }
                }
            }
        }

        ExtendedFloatingActionButton(
            onClick = { nav.navigate("edit/new") },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            icon = { Icon(Icons.Filled.Add, null) },
            text = { Text("Добавить") }
        )
    }
}
