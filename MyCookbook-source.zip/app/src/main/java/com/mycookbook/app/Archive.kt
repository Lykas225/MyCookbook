@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

@Composable
fun ArchiveScreen(store: CookbookStore, initialTab: Int) {
    var tab by remember(initialTab) { mutableIntStateOf(initialTab) }
    var viewer by remember { mutableStateOf<MediaItem?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var linkId by remember { mutableStateOf<String?>(null) }
    var linkPicker by remember { mutableStateOf(false) }

    val actions = rememberMediaActions { p, v ->
        store.addMedia(p, v, linkId)
        tab = if (v) 1 else 0
    }
    val all = store.media.filter { File(it.path).exists() }
    val items = all.filter { it.isVideo == (tab == 1) }.sortedByDescending { it.addedAt }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Text(
                "Архив",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.statusBarsPadding().padding(start = 16.dp, top = 12.dp, end = 16.dp, bottom = 8.dp)
            )
            TabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.background) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("📷 Фотоархив (${all.count { !it.isVideo }})") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("🎬 Видеоархив (${all.count { it.isVideo }})") })
            }
            if (items.isEmpty()) {
                HintText(if (tab == 0) "Фотографий пока нет. Нажмите «Добавить»." else "Видео пока нет. Нажмите «Добавить».")
            }
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 88.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(items, key = { it.id }) { m ->
                    Box {
                        MediaThumb(m.path, m.isVideo, Modifier.fillMaxWidth().aspectRatio(1f)) { viewer = m }
                        val name = m.recipeId?.let { store.recipe(it)?.title }
                        if (name != null) {
                            Text(
                                name,
                                color = Color.White,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .fillMaxWidth()
                                    .background(Color(0x88000000))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { showAdd = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            icon = { Icon(Icons.Filled.Add, null) },
            text = { Text("Добавить") }
        )
    }

    if (showAdd) {
        val linkName = linkId?.let { store.recipe(it)?.title }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Мои материалы") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { linkPicker = true }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.Link, null)
                        Spacer(Modifier.width(6.dp))
                        Text(linkName ?: "Привязать к рецепту (необязательно)", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    MediaAddButtons(actions) { showAdd = false }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Закрыть") } }
        )
    }
    if (linkPicker) {
        RecipePickerDialog(
            recipes = store.recipes.sortedBy { it.title.lowercase() },
            title = "Привязать к рецепту",
            allowClear = true,
            onPick = { linkId = it?.id; linkPicker = false },
            onDismiss = { linkPicker = false }
        )
    }
    viewer?.let { MediaViewerDialog(it, store) { viewer = null } }
}
