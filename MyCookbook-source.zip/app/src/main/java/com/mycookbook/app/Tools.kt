@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

@Composable
fun ToolsScreen(nav: NavHostController) {
    data class Tool(val emoji: String, val title: String, val desc: String, val route: String)
    val tools = listOf(
        Tool("⏱", "Таймер", "Следить за временем приготовления", "timer"),
        Tool("📏", "Калькулятор порций", "Пересчитывать граммовки", "calc"),
        Tool("📅", "План питания", "Планировать меню на неделю", "plan"),
        Tool("📷", "Фотоархив", "Хранить фотографии блюд", "archive?tab=0"),
        Tool("🎬", "Видеоархив", "Хранить свои видео приготовления", "archive?tab=1")
    )
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Инструменты", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        tools.forEach { t ->
            Card(
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable {
                    nav.navigate(t.route) {
                        if (t.route == "plan" || t.route.startsWith("archive")) {
                            popUpTo("home")
                            launchSingleTop = true
                        }
                    }
                },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(t.emoji, fontSize = 32.sp)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(t.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(t.desc, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
fun TimerScreen(timer: TimerState, nav: NavHostController) {
    var minutes by remember { mutableStateOf("10") }
    val presets = listOf(1, 3, 5, 10, 15, 20, 30, 45, 60)
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Таймер") },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(Modifier.height(16.dp))
            val shown = if (timer.active) timer.remainingSec else (minutes.toIntOrNull() ?: 0) * 60
            Text(
                if (timer.finished) "00:00" else formatClock(shown),
                fontSize = 76.sp,
                fontWeight = FontWeight.Bold,
                color = if (timer.finished) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
            )
            if (timer.label.isNotBlank()) {
                Text(timer.label, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (timer.finished) {
                Text("Время вышло!", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.error)
            }
            if (timer.totalSec > 0 && !timer.finished) {
                LinearProgressIndicator(
                    progress = { 1f - timer.remainingSec.toFloat() / timer.totalSec },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (timer.finished) {
                    Button(onClick = { timer.dismiss() }) { Text("Остановить сигнал") }
                } else if (timer.running) {
                    Button(onClick = { timer.pause() }) {
                        Icon(Icons.Filled.Pause, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Пауза")
                    }
                } else {
                    Button(onClick = {
                        if (timer.remainingSec > 0) timer.resume()
                        else {
                            val m = minutes.toIntOrNull() ?: 0
                            if (m > 0) timer.start(m * 60, "Таймер")
                        }
                    }) {
                        Icon(Icons.Filled.PlayArrow, null)
                        Spacer(Modifier.width(6.dp))
                        Text(if (timer.remainingSec > 0) "Продолжить" else "Старт")
                    }
                }
                if (timer.active && !timer.finished) {
                    OutlinedButton(onClick = { timer.dismiss() }) { Text("Сброс") }
                }
            }
            if (!timer.active) {
                OutlinedTextField(
                    minutes, { v -> if (v.all { it.isDigit() } && v.length <= 3) minutes = v },
                    label = { Text("Минут") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    presets.forEach { p ->
                        AssistChip(onClick = { minutes = p.toString() }, label = { Text("$p мин") })
                    }
                }
            }
        }
    }
}

@Composable
fun CalcScreen(store: CookbookStore, nav: NavHostController) {
    var from by remember { mutableStateOf("4") }
    var to by remember { mutableStateOf("6") }
    val rows = remember { mutableStateListOf(IngEdit(), IngEdit(), IngEdit()) }
    var picker by remember { mutableStateOf(false) }
    val f = from.toIntOrNull() ?: 0
    val t = to.toIntOrNull() ?: 0
    val factor = if (f > 0) t.toDouble() / f else 0.0

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Калькулятор порций") },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(onClick = { picker = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.MenuBook, null)
                Spacer(Modifier.width(8.dp))
                Text("Взять ингредиенты из рецепта")
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    from, { v -> if (v.all { it.isDigit() } && v.length <= 3) from = v },
                    label = { Text("Было порций") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    to, { v -> if (v.all { it.isDigit() } && v.length <= 3) to = v },
                    label = { Text("Нужно порций") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f)
                )
            }
            rows.forEachIndexed { idx, row ->
                val a = parseNum(row.amount)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(row.name, { row.name = it }, label = { Text("Продукт") }, singleLine = true, modifier = Modifier.weight(1.4f))
                    Spacer(Modifier.width(6.dp))
                    OutlinedTextField(
                        row.amount, { v -> if (v.all { it.isDigit() || it == ',' || it == '.' }) row.amount = v },
                        label = { Text("Было") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f)
                    )
                    UnitButton(row.unit) { row.unit = it }
                }
                if (a > 0 && f > 0 && t > 0) {
                    Text(
                        "→ " + formatAmount(a * factor) + " " + row.unit + (if (row.name.isNotBlank()) "  (${row.name})" else ""),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(start = 4.dp)
                    )
                }
                if (idx == rows.lastIndex) Spacer(Modifier.height(2.dp))
            }
            OutlinedButton(onClick = { rows.add(IngEdit()) }) {
                Icon(Icons.Filled.Add, null)
                Spacer(Modifier.width(6.dp))
                Text("Добавить строку")
            }
        }
    }

    if (picker) {
        RecipePickerDialog(
            recipes = store.recipes.sortedBy { it.title.lowercase() },
            title = "Выберите рецепт",
            allowClear = false,
            onPick = { r ->
                if (r != null) {
                    from = r.servings.toString()
                    rows.clear()
                    r.ingredients.forEach { rows.add(IngEdit(it.name, if (it.amount > 0) formatAmount(it.amount) else "", it.unit)) }
                    if (rows.isEmpty()) rows.add(IngEdit())
                }
                picker = false
            },
            onDismiss = { picker = false }
        )
    }
}
