@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mycookbook.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

@Composable
fun ToolsScreen(store: CookbookStore, nav: NavHostController) {
    data class MenuItem(val emoji: String, val title: String, val desc: String, val route: String)
    data class MenuSection(val title: String, val items: List<MenuItem>)

    val photoCount = store.media.count { !it.isVideo && File(it.path).exists() }
    val videoCount = store.media.count { it.isVideo && File(it.path).exists() }

    val sections = listOf(
        MenuSection(
            "Умная кухня",
            listOf(
                MenuItem("🤖", "ИИ-помощник", "Идеи, замены и меню", "ai"),
                MenuItem("❄️", "Холодильник", "Рецепты из остатков", "fridge"),
                MenuItem("📄", "Оцифровка", "Сканер и фото", "scanner"),
                MenuItem("🌐", "Из интернета", "Поиск и ссылки", "web")
            )
        ),
        MenuSection(
            "На кухне",
            listOf(
                MenuItem("🥫", "Консервация", "Глава заготовок (${store.recipes.count { it.category == 8 }})", "recipes?cat=8"),
                MenuItem("⏱", "Таймеры", "До 10 таймеров + Рататуй", "timer"),
                MenuItem("📏", "Калькулятор", "Пересчёт порций", "calc")
            )
        ),
        MenuSection(
            "Архив и книга",
            listOf(
                MenuItem("📷", "Фотоархив", if (photoCount > 0) "Фотографий: $photoCount" else "Фотографии блюд", "archive?tab=0"),
                MenuItem("🎬", "Видеоархив", if (videoCount > 0) "Видео: $videoCount" else "Свои видеоуроки", "archive?tab=1"),
                MenuItem("💾", "Копия книги", "Google Диск и файл", "backup"),
                MenuItem("⬇️", "Обновление", "Проверить версию", "update")
            )
        )
    )

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Меню", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(
                    "Рецептов в книге: ${store.recipes.size}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            FilledTonalIconButton(onClick = { store.chooseWallpaper(if (store.wallpaper == 0) 1 else 0) }) {
                Icon(Icons.Filled.Palette, "Сменить тему")
            }
        }

        sections.forEach { section ->
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    section.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                section.items.chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        pair.forEach { item ->
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { nav.navigate(item.route) },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                            ) {
                                Column(
                                    Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(item.emoji, fontSize = 28.sp)
                                    Text(
                                        item.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        item.desc,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun TimerScreen(timer: TimerState, nav: NavHostController) {
    val ctx = LocalContext.current
    var label by remember { mutableStateOf("") }
    var minutes by remember { mutableStateOf("10") }
    var seconds by remember { mutableStateOf("0") }
    val presets = listOf(1, 3, 5, 10, 15, 20, 30, 45, 60)

    var handsFree by remember { mutableStateOf(false) }
    var voiceMode by remember { mutableStateOf(VoiceMode.OFF) }
    var lastHeard by remember { mutableStateOf("") }

    val voiceHolder = remember { arrayOfNulls<VoiceAssistant>(1) }
    val voiceAssistant = remember {
        VoiceAssistant(
            context = ctx,
            onModeChange = { m ->
                voiceMode = m
                if (m == VoiceMode.OFF) handsFree = false
            },
            onHeardText = { lastHeard = it },
            onCommand = onCmd@{ cmd ->
                val va = voiceHolder[0] ?: return@onCmd
                when (cmd) {
                    is VoiceCommand.TimerStart -> {
                        if (cmd.seconds > 0) {
                            val started = timer.start(cmd.seconds, cmd.label)
                            if (started == null) va.speak("Уже запущено максимум 10 таймеров.")
                            else va.speak("Запустил ${started.label} на ${formatDurationRu(cmd.seconds)}.")
                        } else {
                            val paused = timer.findTimer(preferPaused = true)
                            if (paused != null && !paused.running && !paused.finished) {
                                timer.resume(paused.id)
                                va.speak("Продолжил ${paused.label}.")
                            } else {
                                va.speak("Назовите время, например: поставь таймер на 5 минут.")
                            }
                        }
                    }
                    is VoiceCommand.TimerAdd -> {
                        val target = timer.findTimer(number = cmd.number, query = cmd.query)
                        if (target == null) va.speak("Нет активных таймеров.")
                        else {
                            val u = timer.addTime(target.id, cmd.deltaSeconds)
                            if (u != null) va.speak("Добавил ${formatDurationRu(cmd.deltaSeconds)} к ${u.label}.")
                        }
                    }
                    is VoiceCommand.TimerPause -> {
                        if (cmd.all) {
                            val n = timer.pauseAll()
                            va.speak(if (n > 0) "На паузе таймеров: $n." else "Нет идущих таймеров.")
                        } else {
                            val t = timer.findTimer(number = cmd.number, query = cmd.query)
                            if (t == null) va.speak("Нет активных таймеров.")
                            else {
                                timer.pause(t.id)
                                va.speak("${t.label} на паузе.")
                            }
                        }
                    }
                    is VoiceCommand.TimerResume -> {
                        if (cmd.all) {
                            val n = timer.resumeAll()
                            va.speak(if (n > 0) "Продолжил таймеров: $n." else "Нет таймеров на паузе.")
                        } else {
                            val t = timer.findTimer(number = cmd.number, query = cmd.query, preferPaused = true)
                            if (t == null) va.speak("Нет таймеров на паузе.")
                            else {
                                timer.resume(t.id)
                                va.speak("Продолжил ${t.label}.")
                            }
                        }
                    }
                    is VoiceCommand.TimerStop -> {
                        if (cmd.all) {
                            timer.dismissAll()
                            va.speak("Остановил все таймеры.")
                        } else {
                            val t = timer.findTimer(number = cmd.number, query = cmd.query, preferFinished = true)
                            if (t == null) va.speak("Активных таймеров нет.")
                            else {
                                timer.dismiss(t.id)
                                va.speak("Остановил ${t.label}.")
                            }
                        }
                    }
                    is VoiceCommand.TimerStatus -> {
                        if (timer.timers.isEmpty()) {
                            va.speak("Сейчас нет запущенных таймеров.")
                        } else {
                            val summary = timer.timers.joinToString(". ") { t ->
                                if (t.finished) "${t.label} готов"
                                else "${t.label} — осталось ${formatDurationRu(t.remainingSec)}"
                            }
                            va.speak("Всего таймеров ${timer.timers.size}. $summary.")
                        }
                    }
                    is VoiceCommand.StopSpeaking -> va.stopSpeaking()
                    else -> va.speak("Скажите, например: поставь таймер суп на 15 минут, сколько осталось, или останови таймер.")
                }
            }
        ).also { voiceHolder[0] = it }
    }

    DisposableEffect(Unit) {
        timer.onTimerFinished = { t ->
            voiceAssistant.speak(timer.announceText(t), keepDialog = handsFree)
        }
        onDispose {
            timer.onTimerFinished = null
            voiceAssistant.destroy()
        }
    }

    var pendingAudioAction by remember { mutableStateOf<String?>(null) }
    val audioPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
            if (pendingAudioAction == "handsfree") {
                handsFree = true
                voiceAssistant.setHandsFree(true)
                voiceAssistant.speak("Рататуй слушает таймеры! Скажите: Рататуй, поставь таймер.")
            } else {
                voiceAssistant.startSingleCommand()
            }
        } else {
            Toast.makeText(ctx, "Нужен доступ к микрофону", Toast.LENGTH_SHORT).show()
        }
        pendingAudioAction = null
    }

    fun triggerVoice(action: String) {
        val granted = androidx.core.content.ContextCompat.checkSelfPermission(
            ctx, android.Manifest.permission.RECORD_AUDIO
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (granted) {
            if (action == "handsfree") {
                val next = !handsFree
                handsFree = next
                voiceAssistant.setHandsFree(next)
                if (next) voiceAssistant.speak("Рататуй на связи! Зовите по имени.")
                else voiceAssistant.stopSpeaking()
            } else {
                voiceAssistant.startSingleCommand()
            }
        } else {
            pendingAudioAction = action
            audioPermLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Таймеры (${timer.timers.size}/${TimerState.MAX_TIMERS})") },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } },
                actions = {
                    if (timer.timers.size > 1) {
                        TextButton(onClick = { timer.dismissAll() }) { Text("Сбросить все") }
                    }
                    IconButton(onClick = { triggerVoice("handsfree") }) {
                        Icon(
                            if (handsFree) Icons.Filled.RecordVoiceOver else Icons.Filled.Mic,
                            "Рататуй",
                            tint = if (voiceMode == VoiceMode.LISTENING_COMMAND) MaterialTheme.colorScheme.error
                            else if (handsFree) MaterialTheme.colorScheme.primary
                            else LocalContentColor.current
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize().imePadding(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                val statusText = when (voiceMode) {
                    VoiceMode.LISTENING_COMMAND -> "🎤 Рататуй слушает команду…"
                    VoiceMode.WAITING_WAKE -> "👂 Жду «Рататуй» / «Реми» (в фоне)"
                    VoiceMode.SPEAKING -> "🔊 Рататуй говорит…"
                    VoiceMode.OFF -> "🐭 Нажмите, чтобы управлять таймерами голосом"
                }
                Card(
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable {
                        if (voiceMode == VoiceMode.SPEAKING) voiceAssistant.stopSpeaking()
                        else triggerVoice("single")
                    },
                    colors = CardDefaults.cardColors(
                        containerColor = if (voiceMode == VoiceMode.LISTENING_COMMAND) MaterialTheme.colorScheme.errorContainer
                        else MaterialTheme.colorScheme.primaryContainer
                    )
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(statusText, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            if (lastHeard.isNotBlank() && voiceMode != VoiceMode.OFF) {
                                Text("«$lastHeard»", style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        FilterChip(
                            selected = handsFree,
                            onClick = { triggerVoice("handsfree") },
                            label = { Text(if (handsFree) "Без рук ✓" else "Без рук", fontSize = 11.sp) }
                        )
                    }
                }
            }

            if (timer.anyFinished) {
                item {
                    Button(
                        onClick = { timer.dismissFinished() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Filled.NotificationsOff, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Остановить сигнал")
                    }
                }
            }

            // Active timers list (up to 10)
            items(timer.timers, key = { it.id }) { t ->
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (t.finished) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "#${t.number}  ${t.label}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                if (t.finished) "Готово!" else formatClock(t.remainingSec),
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (t.finished) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                            )
                        }
                        if (t.totalSec > 0 && !t.finished) {
                            LinearProgressIndicator(
                                progress = { 1f - t.remainingSec.toFloat() / t.totalSec },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (!t.finished) {
                                FilledTonalButton(
                                    onClick = { if (t.running) timer.pause(t.id) else timer.resume(t.id) },
                                    contentPadding = PaddingValues(horizontal = 12.dp)
                                ) {
                                    Icon(if (t.running) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, Modifier.size(18.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text(if (t.running) "Пауза" else "Старт")
                                }
                                OutlinedButton(
                                    onClick = { timer.addTime(t.id, 60) },
                                    contentPadding = PaddingValues(horizontal = 10.dp)
                                ) { Text("+1 мин") }
                            }
                            Spacer(Modifier.weight(1f))
                            OutlinedButton(
                                onClick = { timer.dismiss(t.id) },
                                contentPadding = PaddingValues(horizontal = 12.dp)
                            ) {
                                Text(if (t.finished) "Выключить" else "Удалить")
                            }
                        }
                    }
                }
            }

            // Add new timer card
            item {
                val canAdd = timer.timers.size < TimerState.MAX_TIMERS
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            if (canAdd) "Новый таймер (${timer.timers.size}/${TimerState.MAX_TIMERS})"
                            else "Достигнут лимит: 10 таймеров",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        OutlinedTextField(
                            label, { label = it },
                            label = { Text("Название (например: Паста, Суп, Духовка)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                minutes, { v -> if (v.all { it.isDigit() } && v.length <= 3) minutes = v },
                                label = { Text("Минут") }, singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                seconds, { v -> if (v.all { it.isDigit() } && v.length <= 2) seconds = v },
                                label = { Text("Секунд") }, singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            presets.forEach { p ->
                                AssistChip(onClick = { minutes = p.toString(); seconds = "0" }, label = { Text("$p мин") })
                            }
                        }
                        Button(
                            onClick = {
                                val totalSec = (minutes.toIntOrNull() ?: 0) * 60 + (seconds.toIntOrNull() ?: 0)
                                if (totalSec <= 0) {
                                    Toast.makeText(ctx, "Укажите время больше 0", Toast.LENGTH_SHORT).show()
                                } else {
                                    val started = timer.start(totalSec, label)
                                    if (started == null) {
                                        Toast.makeText(ctx, "Уже запущено максимум 10 таймеров", Toast.LENGTH_SHORT).show()
                                    } else {
                                        label = ""
                                    }
                                }
                            },
                            enabled = canAdd,
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Filled.Add, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Запустить таймер")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CalcScreen(store: CookbookStore, nav: NavHostController) {
    var from by remember { mutableStateOf("4") }
    var to by remember { mutableStateOf("6") }
    val rows = remember { mutableStateListOf(IngEdit(), IngEdit(), IngEdit()) }
    var picker by remember { mutableStateOf(false) }
    val f = from.toIntOrNull() ?: 0
    val t = to.toIntOrNull() ?: 0
    val factor = if (f > 0) t.toDouble() / f else 0.0

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Калькулятор порций") },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(onClick = { picker = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.MenuBook, null)
                Spacer(Modifier.width(8.dp))
                Text("Взять ингредиенты из рецепта")
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    from, { v -> if (v.all { it.isDigit() } && v.length <= 3) from = v },
                    label = { Text("Было порций") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    to, { v -> if (v.all { it.isDigit() } && v.length <= 3) to = v },
                    label = { Text("Нужно порций") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f)
                )
            }
            rows.forEachIndexed { idx, row ->
                val a = parseNum(row.amount)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(row.name, { row.name = it }, label = { Text("Продукт") }, singleLine = true, modifier = Modifier.weight(1.4f))
                    Spacer(Modifier.width(6.dp))
                    OutlinedTextField(
                        row.amount, { v -> if (v.all { isAmountChar(it) } && v.length <= 12) row.amount = v },
                        label = { Text("Было") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text), modifier = Modifier.weight(1f)
                    )
                    UnitButton(row.unit) { row.unit = it }
                }
                if (a > 0 && f > 0 && t > 0) {
                    Text(
                        "→ " + formatAmount(a * factor) + " " + row.unit + (if (row.name.isNotBlank()) "  (${row.name})" else ""),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(start = 4.dp)
                    )
                }
                if (idx == rows.lastIndex) Spacer(Modifier.height(2.dp))
            }
            OutlinedButton(onClick = { rows.add(IngEdit()) }) {
                Icon(Icons.Filled.Add, null)
                Spacer(Modifier.width(6.dp))
                Text("Добавить строку")
            }
        }
    }

    if (picker) {
        RecipePickerDialog(
            recipes = store.recipes.sortedBy { it.title.lowercase() },
            title = "Выберите рецепт",
            allowClear = false,
            onPick = { r ->
                if (r != null) {
                    from = r.servings.toString()
                    rows.clear()
                    r.ingredients.forEach { rows.add(IngEdit(it.name, if (it.amount > 0) formatAmount(it.amount) else "", it.unit)) }
                    if (rows.isEmpty()) rows.add(IngEdit())
                }
                picker = false
            },
            onDismiss = { picker = false }
        )
    }
}
