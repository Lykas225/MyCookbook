package com.mycookbook.app

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun FridgeScreen(onRecipeGenerated: (String) -> Unit) {
    var ingredients by remember { mutableStateOf("") }
    var isGenerating by remember { mutableStateOf(false) }

    Column(modifier = Modifier.padding(16.dp).fillMaxSize()) {
        Text("Что есть в холодильнике?", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = ingredients,
            onValueChange = { ingredients = it },
            label = { Text("Например: курица, картошка, сыр") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                isGenerating = true
                generateRecipeFromIngredientsHelper(ingredients) { result ->
                    isGenerating = false
                    onRecipeGenerated(result)
                }
            },
            enabled = ingredients.isNotBlank() && !isGenerating,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (isGenerating) "Магия ИИ..." else "Придумать рецепт")
        }
    }
}
