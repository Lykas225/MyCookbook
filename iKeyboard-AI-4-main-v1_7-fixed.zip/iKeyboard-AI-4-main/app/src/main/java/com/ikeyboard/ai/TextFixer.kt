package com.ikeyboard.ai

import java.util.Locale
import kotlin.math.abs

/** Исправление опечаток при наборе и приведение текста диктовки к правильному виду. */
object TextFixer {

    private val tokenRe = Regex("[\\p{L}]+(?:['’][\\p{L}]+)*")

    // ---------- расстояние Дамерау–Левенштейна ----------

    fun damerau(a: String, b: String): Int {
        val n = a.length
        val m = b.length
        if (n == 0) return m
        if (m == 0) return n
        val d = Array(n + 1) { IntArray(m + 1) }
        for (i in 0..n) d[i][0] = i
        for (j in 0..m) d[0][j] = j
        for (i in 1..n) {
            for (j in 1..m) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                var v = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost)
                if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) {
                    v = minOf(v, d[i - 2][j - 2] + 1)
                }
                d[i][j] = v
            }
        }
        return d[n][m]
    }

    fun matchCase(orig: String, cand: String): String = when {
        orig.length > 1 && orig.all { it.isUpperCase() } -> cand.uppercase(Locale.ROOT)
        orig.isNotEmpty() && orig[0].isUpperCase() -> cand.replaceFirstChar { it.uppercase(Locale.ROOT) }
        else -> cand
    }

    // ---------- автоисправление при наборе ----------

    /** Соседние клавиши по раскладке: опечатка «по соседней клавише» — самая частая. */
    fun buildNeighbors(rows: List<List<String>>): Map<Char, Set<Char>> {
        val m = HashMap<Char, MutableSet<Char>>()
        fun add(a: String, b: String) {
            if (a.length == 1 && b.length == 1) m.getOrPut(a[0]) { mutableSetOf() }.add(b[0])
        }
        rows.forEachIndexed { r, row ->
            row.forEachIndexed { i, k ->
                if (i > 0) add(k, row[i - 1])
                if (i < row.size - 1) add(k, row[i + 1])
                if (r + 1 < rows.size) {
                    val below = rows[r + 1]
                    for (j in i - 1..i) if (j in below.indices) add(k, below[j])
                }
                if (r > 0) {
                    val above = rows[r - 1]
                    for (j in i..i + 1) if (j in above.indices) add(k, above[j])
                }
            }
        }
        return m
    }

    private fun isNeighborTypo(t: String, c: String, nb: Map<Char, Set<Char>>): Boolean {
        if (t.length == c.length) {
            val diff = ArrayList<Int>()
            for (i in t.indices) {
                if (t[i] != c[i]) {
                    diff.add(i)
                    if (diff.size > 2) return false
                }
            }
            if (diff.size == 1) return nb[t[diff[0]]]?.contains(c[diff[0]]) == true
            if (diff.size == 2 && diff[1] == diff[0] + 1) {
                return t[diff[0]] == c[diff[1]] && t[diff[1]] == c[diff[0]]
            }
            return false
        }
        if (t.length == c.length + 1 && t.length >= 5) {
            return t.indices.any { i -> t.removeRange(i, i + 1).toString() == c }
        }
        if (t.length + 1 == c.length && t.length >= 4) {
            return c.indices.any { i -> c.removeRange(i, i + 1).toString() == t }
        }
        return false
    }

    /**
     * Возвращает исправленное слово или null, если исправлять не нужно.
     * Исправляем только очевидные опечатки: соседняя клавиша, перестановка букв,
     * лишняя/пропущенная буква. Кандидаты — ваши частые слова и встроенный словарь.
     */
    fun autocorrect(word: String, lang: String, store: WordStore, nb: Map<Char, Set<Char>>): String? {
        if (word.length < 4) return null
        if (word.any { !it.isLetter() }) return null
        if (word.drop(1).any { it.isUpperCase() }) return null
        val lower = word.lowercase(Locale.ROOT)
        if (store.isKnown(lang, lower)) return null

        var best: String? = null
        var bestScore = -1
        for ((cand, cnt) in store.entries(lang)) {
            if (cnt < 3 || abs(cand.length - lower.length) > 1 || cand[0] != lower[0]) continue
            if (cnt > bestScore && isNeighborTypo(lower, cand, nb)) { best = cand; bestScore = cnt }
        }
        for (cand in store.dictionary(lang)) {
            if (abs(cand.length - lower.length) > 1 || cand[0] != lower[0]) continue
            if (bestScore < 3 && isNeighborTypo(lower, cand, nb)) { best = cand; bestScore = 3 }
        }
        return best?.let { matchCase(word, it) }
    }

    // ---------- диктовка ----------

    /** Из нескольких вариантов распознавания выбирает тот, где больше слов из вашего словаря. */
    fun rerank(hyps: List<String>, conf: FloatArray?, lang: String, store: WordStore): String {
        if (hyps.isEmpty()) return ""
        var best = hyps[0]
        var bestScore = -1.0
        hyps.forEachIndexed { i, h ->
            val base = conf?.getOrNull(i)?.takeIf { it >= 0f }?.toDouble() ?: (1.0 - i * 0.1)
            val tokens = tokenRe.findAll(h).map { it.value }.toList()
            val personal = if (tokens.isEmpty()) 0.0
            else tokens.count { store.count(lang, it) >= 2 }.toDouble() / tokens.size
            val score = base + personal * 0.25
            if (score > bestScore) { best = h; bestScore = score }
        }
        return best
    }

    private fun sameStemDifferentEnding(a: String, b: String): Boolean {
        var cp = 0
        val lim = minOf(a.length, b.length)
        while (cp < lim && a[cp] == b[cp]) cp++
        return cp >= 3 && cp >= lim - 2
    }

    /** Заменяет «неизвестные» слова из диктовки на близкие слова из вашего личного словаря. */
    fun correctWords(text: String, lang: String, store: WordStore): String {
        val vocab = store.entries(lang).filter { it.value >= 2 && it.key.length >= 4 }
        if (vocab.isEmpty()) return text
        return tokenRe.replace(text) { m ->
            val w = m.value
            val lower = w.lowercase(Locale.ROOT)
            if (w.length < 4 || store.isKnown(lang, lower)) return@replace w
            val maxD = if (lower.length <= 6) 1 else 2
            var best: String? = null
            var bestD = 99
            var bestC = -1
            for ((cand, c) in vocab) {
                if (abs(cand.length - lower.length) > maxD) continue
                // русские окончания (Алексей/Алексея) — это не ошибка
                if (lang == "ru" && sameStemDifferentEnding(lower, cand)) continue
                val d = damerau(lower, cand)
                if (d in 1..maxD && (d < bestD || (d == bestD && c > bestC))) {
                    best = cand; bestD = d; bestC = c
                }
            }
            best?.let { matchCase(w, it) } ?: w
        }
    }

    private fun voiceRules(ru: Boolean): List<Pair<Regex, String>> {
        fun r(phrase: String) = Regex("(?iu)\\s*(?<![\\p{L}])(?:$phrase)(?![\\p{L}])")
        fun rEnd(phrase: String) = Regex("(?iu)\\s*(?<![\\p{L}])(?:$phrase)\\s*$")
        return if (ru) listOf(
            r("точка с запятой") to ";",
            r("запятая") to ",",
            r("вопросительный знак") to "?",
            r("восклицательный знак") to "!",
            r("двоеточие") to ":",
            r("многоточие") to "…",
            r("новая строка|с новой строки|новый абзац") to "\n",
            rEnd("точка") to "."
        ) else listOf(
            r("semicolon") to ";",
            r("comma") to ",",
            r("question mark") to "?",
            r("exclamation mark|exclamation point") to "!",
            r("colon") to ":",
            r("ellipsis") to "…",
            r("new line|new paragraph") to "\n",
            rEnd("period|full stop") to "."
        )
    }

    private fun startsSentence(before: String): Boolean {
        val tr = before.trimEnd(' ')
        if (tr.isEmpty()) return true
        return tr.last() in ".!?…\n"
    }

    /**
     * Приводит результат распознавания к нормальному написанию:
     * голосовые знаки препинания, пробелы, заглавные в начале предложений, пробел перед вставкой.
     */
    fun normalizeDictation(raw: String, before: String, ru: Boolean, voiceCommands: Boolean): String {
        var t = raw.trim().replace(Regex("\\s+"), " ")
        if (t.isEmpty()) return ""
        if (voiceCommands) {
            for ((re, rep) in voiceRules(ru)) t = re.replace(t) { rep }
        }
        t = t.replace(Regex("\\s+([,.!?:;…])"), "\$1")
        t = t.replace(Regex("([,!?;:])(?=[\\p{L}])"), "\$1 ")
        t = t.replace(Regex("(\\.)(?=\\p{Lu})"), "\$1 ")
        t = t.replace(Regex(" *\n *"), "\n").trim(' ')
        if (t.isEmpty()) return ""

        val sb = StringBuilder()
        var cap = startsSentence(before)
        for (ch in t) {
            if (cap && ch.isLetter()) {
                sb.append(ch.uppercaseChar())
                cap = false
            } else {
                sb.append(ch)
                if (ch.isLetterOrDigit()) cap = false
                else if (ch == '.' || ch == '!' || ch == '?' || ch == '\n') cap = true
            }
        }
        val last = before.lastOrNull()
        val first = sb.firstOrNull()
        if (last != null && !last.isWhitespace() && last !in "([{«“\"'" &&
            first != null && first !in ",.!?:;)…\n"
        ) sb.insert(0, ' ')
        return sb.toString()
    }
}
