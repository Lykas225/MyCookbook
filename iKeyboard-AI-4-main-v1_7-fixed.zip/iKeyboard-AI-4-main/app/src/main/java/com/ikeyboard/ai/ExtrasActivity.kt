package com.ikeyboard.ai

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class ExtrasActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("ikeyboard_extras", MODE_PRIVATE) }
    private val vault by lazy { SecureCardVault(this) }
    private val words by lazy { WordStore.get(this) }
    private val blue = Color.rgb(0, 122, 255)
    private val favorites get() = prefs.getStringSet("favorite_emojis", emptySet())?.toMutableSet() ?: mutableSetOf()

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); render() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density + .5f).toInt()

    private fun render() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(24)); setBackgroundColor(Color.rgb(22,23,27)) }
        root.addView(label("Инструменты iKeyboard AI", 25f))
        root.addView(button("GIF-анимации — открыть поиск GIF") {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://giphy.com/search/"))) }
            catch (e: Exception) { toast("Не удалось открыть поиск GIF") }
        })
        root.addView(button("Сохранить текущий буфер обмена") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val value = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
            if (value.isBlank()) toast("Буфер обмена пуст") else {
                val items = prefs.getStringSet("clips", emptySet())?.toMutableSet() ?: mutableSetOf()
                items.add(value.take(500)); prefs.edit().putStringSet("clips", items).apply(); showClips()
            }
        })
        root.addView(button("Мои сохранённые фрагменты") { showClips() })
        root.addView(button("Избранные эмодзи") { editFavorites() })
        root.addView(button("Добавить слово в свой словарь") { addWord() })
        root.addView(button("Добавить слова из TXT (вставкой текста)") { importDictionary() })
        root.addView(button("Экспорт личного словаря") { exportDictionary() })
        root.addView(label("Защищённые карты", 20f))
        root.addView(label("Хранятся только название карты и последние четыре цифры. Полный номер и CVV не сохраняются.", 13f))
        root.addView(button("Открыть защищённое хранилище карт") { unlockVault() })
        root.addView(button("Назад") { finish() })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun unlockVault() {
        if (!vault.hasPin()) {
            val input = EditText(this).apply { hint = "Новый PIN (6 цифр)"; inputType = 2 }
            AlertDialog.Builder(this).setTitle("Создать PIN-код").setView(input)
                .setPositiveButton("Сохранить") { _, _ ->
                    val pin = input.text.toString()
                    if (pin.matches(Regex("\\d{6}"))) { vault.setPin(pin); showVault() }
                    else toast("PIN должен содержать ровно 6 цифр")
                }.setNegativeButton("Отмена", null).show()
            return
        }
        val input = EditText(this).apply { hint = "PIN-код"; inputType = 2 }
        AlertDialog.Builder(this).setTitle("Разблокировать хранилище").setView(input)
            .setPositiveButton("Открыть") { _, _ ->
                if (vault.verifyPin(input.text.toString())) showVault() else toast("Неверный PIN")
            }.setNegativeButton("Отмена", null).show()
    }

    private fun showVault() {
        val cards = vault.loadCards().toMutableList()
        val names = cards.map { "${it.first} •••• ${it.second}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Сохранённые карты")
            .setItems(names) { _, which ->
                AlertDialog.Builder(this).setMessage("Удалить ${cards[which].first}?")
                    .setPositiveButton("Удалить") { _, _ -> cards.removeAt(which); vault.saveCards(cards); showVault() }
                    .setNegativeButton("Отмена", null).show()
            }
            .setPositiveButton("Добавить") { _, _ -> addCard(cards) }
            .setNeutralButton("Закрыть", null).show()
    }

    private fun addCard(cards: MutableList<Pair<String, String>>) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(12), 0) }
        val name = EditText(this).apply { hint = "Название карты, например Основная" }
        val last4 = EditText(this).apply { hint = "Последние 4 цифры"; inputType = 2 }
        box.addView(name); box.addView(last4)
        AlertDialog.Builder(this).setTitle("Добавить карту").setView(box)
            .setMessage("Не вводи полный номер карты или CVV")
            .setPositiveButton("Зашифровать и сохранить") { _, _ ->
                val n = name.text.toString().trim(); val d = last4.text.toString().trim()
                if (n.isNotEmpty() && d.matches(Regex("\\d{4}"))) { cards.add(n to d); vault.saveCards(cards); toast("Сохранено в зашифрованном виде") }
                else toast("Укажи название и ровно 4 цифры")
            }.setNegativeButton("Отмена", null).show()
    }

    private fun showClips() {
        val clips = prefs.getStringSet("clips", emptySet())?.toList().orEmpty()
        if (clips.isEmpty()) { toast("Сохранённых фрагментов пока нет"); return }
        AlertDialog.Builder(this).setTitle("Буфер обмена")
            .setItems(clips.toTypedArray()) { _, i ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("iKeyboard", clips[i])); toast("Скопировано")
            }.setNegativeButton("Закрыть", null).show()
    }

    private fun editFavorites() {
        val all = listOf("❤️","😂","😊","👍","🙏","🔥","🎉","😍","🤔","😎","🥰","🚗","✨","💯","😉","😭")
        val selected = favorites
        val checks = all.map { "$it ${if (selected.contains(it)) "★" else ""}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Избранные эмодзи")
            .setMultiChoiceItems(checks, all.map { selected.contains(it) }.toBooleanArray()) { _, which, checked ->
                if (checked) selected.add(all[which]) else selected.remove(all[which])
            }.setPositiveButton("Сохранить") { _, _ -> prefs.edit().putStringSet("favorite_emojis", selected).apply(); toast("Избранное сохранено") }
            .setNegativeButton("Отмена", null).show()
    }

    private fun addWord() {
        val input = EditText(this).apply { hint = "Слово или имя" }
        AlertDialog.Builder(this).setTitle("Свой словарь").setView(input)
            .setPositiveButton("Добавить") { _, _ ->
                val w = input.text.toString().trim()
                val lang = if (w.any { it in 'а'..'я' || it in 'А'..'Я' || it == 'ё' || it == 'Ё' }) "ru" else "en"
                words.learn(lang, w, 5); toast("Слово добавлено")
            }.setNegativeButton("Отмена", null).show()
    }

    private fun importDictionary() {
        val input = EditText(this).apply { hint = "Вставь слова, каждое с новой строки"; minLines = 5 }
        AlertDialog.Builder(this).setTitle("Импорт TXT-словаря").setView(input)
            .setPositiveButton("Импортировать") { _, _ ->
                var count = 0
                input.text.toString().lines().forEach { raw ->
                    val w = raw.trim(); if (w.length >= 2) {
                        val lang = if (w.any { it in 'а'..'я' || it in 'А'..'Я' || it == 'ё' || it == 'Ё' }) "ru" else "en"
                        words.learn(lang, w, 3); count++
                    }
                }
                toast("Добавлено слов: $count")
            }.setNegativeButton("Отмена", null).show()
    }

    private fun exportDictionary() {
        val data = listOf("ru", "en").flatMap { lang -> words.entries(lang).keys.map { "$lang\t$it" } }.joinToString("\n")
        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "iKeyboard AI dictionary"); putExtra(Intent.EXTRA_TEXT, data) }
        startActivity(Intent.createChooser(send, "Экспорт словаря"))
    }

    private fun label(value: String, size: Float) = TextView(this).apply { text = value; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(12)) }
    private fun button(value: String, action: () -> Unit) = Button(this).apply { text = value; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundColor(blue); setOnClickListener { action() }; layoutParams = LinearLayout.LayoutParams(-1, dp(50)).apply { setMargins(0, dp(5), 0, dp(5)) } }
    private fun toast(value: String) = Toast.makeText(this, value, Toast.LENGTH_SHORT).show()
}
