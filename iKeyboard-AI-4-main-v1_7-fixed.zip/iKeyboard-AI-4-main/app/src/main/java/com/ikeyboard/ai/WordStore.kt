package com.ikeyboard.ai

import android.content.Context
import java.util.Locale

/**
 * Личный словарь пользователя. Хранится только на устройстве.
 *  - частоты слов: "ru:слово" -> сколько раз использовано
 *  - пары слов:    "ru:привет|мир" -> сколько раз «мир» шло после «привет»
 */
class WordStore private constructor(ctx: Context) {

    private val appCtx = ctx.applicationContext
    private val prefs = appCtx.getSharedPreferences("ikeyboard_learning", Context.MODE_PRIVATE)
    private val pairPrefs = appCtx.getSharedPreferences("ikeyboard_pairs", Context.MODE_PRIVATE)

    private val learned = hashMapOf(
        "ru" to HashMap<String, Int>(),
        "en" to HashMap<String, Int>()
    )
    private val nextWords = HashMap<String, HashMap<String, Int>>()   // "ru:prev" -> (next -> count)
    private var pairTotal = 0

    private val staticLists = HashMap<String, List<String>>()
    private val staticSets = HashMap<String, Set<String>>()

    private val wordRegex = Regex("[\\p{L}]{2,32}(?:['’][\\p{L}]{1,20})?")

    init {
        for ((k, v) in prefs.all) {
            if (v !is Int) continue
            val lang = k.substringBefore(':', "")
            val w = k.substringAfter(':', "")
            learned[lang]?.put(w, v)
        }
        for ((k, v) in pairPrefs.all) {
            if (v !is Int) continue
            val lang = k.substringBefore(':', "")
            val rest = k.substringAfter(':', "")
            val p = rest.substringBefore('|', "")
            val n = rest.substringAfter('|', "")
            if (p.isNotEmpty() && n.isNotEmpty()) {
                nextWords.getOrPut("$lang:$p") { HashMap() }[n] = v
                pairTotal++
            }
        }
    }

    // ---------- встроенный словарь ----------

    fun dictionary(lang: String): List<String> = staticLists.getOrPut(lang) {
        try {
            val res = if (lang == "ru") R.raw.words_ru else R.raw.words_en
            appCtx.resources.openRawResource(res).bufferedReader(Charsets.UTF_8).useLines { seq ->
                seq.map { it.trim() }.filter { it.isNotEmpty() }.toList()
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun dictSet(lang: String): Set<String> =
        staticSets.getOrPut(lang) { dictionary(lang).toHashSet() }

    // ---------- чтение ----------

    fun entries(lang: String): Map<String, Int> = learned[lang] ?: emptyMap()

    fun count(lang: String, word: String): Int = learned[lang]?.get(word.lowercase(Locale.ROOT)) ?: 0

    /** Слово «известно», если оно в личном словаре или во встроенном. */
    fun isKnown(lang: String, word: String): Boolean {
        val w = word.lowercase(Locale.ROOT)
        return (learned[lang]?.get(w) ?: 0) > 0 || dictSet(lang).contains(w)
    }

    fun learnedCount(): Int = learned.values.sumOf { it.size }

    fun topWords(lang: String, n: Int): List<String> =
        (learned[lang] ?: emptyMap<String, Int>()).entries
            .sortedByDescending { it.value }.take(n).map { it.key }

    fun topAll(n: Int): List<Pair<String, Int>> =
        learned.values.flatMap { m -> m.entries.map { it.key to it.value } }
            .sortedByDescending { it.second }.take(n)

    // ---------- запись ----------

    @Synchronized
    fun learn(lang: String, word: String, inc: Int = 1) {
        val w = word.lowercase(Locale.ROOT)
        if (!w.matches(wordRegex)) return
        val m = learned[lang] ?: return
        val n = ((m[w] ?: 0) + inc).coerceAtMost(1000)
        m[w] = n
        prefs.edit().putInt("$lang:$w", n).apply()
        if (m.size > 6000) prune(lang)
    }

    /** Усиливает только уже известные слова (для диктовки — чтобы не запоминать ошибки распознавания). */
    @Synchronized
    fun reinforce(lang: String, text: String) {
        val m = learned[lang] ?: return
        val ed = prefs.edit()
        var changed = false
        Regex("[\\p{L}]+(?:['’][\\p{L}]+)*").findAll(text).forEach {
            val w = it.value.lowercase(Locale.ROOT)
            val c = m[w] ?: return@forEach
            val n = (c + 1).coerceAtMost(1000)
            m[w] = n
            ed.putInt("$lang:$w", n)
            changed = true
        }
        if (changed) ed.apply()
    }

    @Synchronized
    fun learnPair(lang: String, prev: String, next: String) {
        val p = prev.lowercase(Locale.ROOT)
        val n = next.lowercase(Locale.ROOT)
        if (!p.matches(wordRegex) || !n.matches(wordRegex)) return
        val map = nextWords.getOrPut("$lang:$p") { HashMap() }
        val isNew = !map.containsKey(n)
        val c = ((map[n] ?: 0) + 1).coerceAtMost(500)
        map[n] = c
        if (isNew) pairTotal++
        pairPrefs.edit().putInt("$lang:$p|$n", c).apply()
        if (pairTotal > 15000) prunePairs()
    }

    @Synchronized
    fun forget(lang: String, word: String) {
        val w = word.lowercase(Locale.ROOT)
        if (learned[lang]?.remove(w) != null) prefs.edit().remove("$lang:$w").apply()
    }

    @Synchronized
    fun clearAll() {
        learned.values.forEach { it.clear() }
        nextWords.clear()
        pairTotal = 0
        prefs.edit().clear().apply()
        pairPrefs.edit().clear().apply()
    }

    private fun prune(lang: String) {
        val m = learned[lang] ?: return
        val drop = m.entries.sortedBy { it.value }.take(m.size - 4500).map { it.key }
        val ed = prefs.edit()
        drop.forEach { m.remove(it); ed.remove("$lang:$it") }
        ed.apply()
    }

    private fun prunePairs() {
        val ed = pairPrefs.edit()
        var total = 0
        val it = nextWords.entries.iterator()
        while (it.hasNext()) {
            val e = it.next()
            val inner = e.value.entries.iterator()
            while (inner.hasNext()) {
                val x = inner.next()
                if (x.value <= 1) {
                    ed.remove("${e.key}|${x.key}")
                    inner.remove()
                } else total++
            }
            if (e.value.isEmpty()) it.remove()
        }
        pairTotal = total
        ed.apply()
    }

    // ---------- подсказки ----------

    /**
     * Подсказки: если [prefix] пуст — предсказание следующего слова по [prev];
     * иначе — дополнение набранного начала слова (личные слова важнее встроенных).
     */
    fun suggest(lang: String, prev: String?, prefix: String, limit: Int = 3): List<String> {
        val m = learned[lang] ?: return emptyList()
        val p = prefix.lowercase(Locale.ROOT)
        val scores = HashMap<String, Double>()
        val pairs = prev?.let { nextWords["$lang:${it.lowercase(Locale.ROOT)}"] }

        if (p.isEmpty()) {
            pairs?.forEach { (w, c) -> scores[w] = 100.0 + c }
            if (scores.size < limit) {
                m.entries.sortedByDescending { it.value }.take(limit * 2).forEach { (w, c) ->
                    if (c >= 3) scores.putIfAbsent(w, c.toDouble())
                }
            }
            if (scores.size < limit) {
                dictionary(lang).take(limit * 3).forEachIndexed { i, w ->
                    scores.putIfAbsent(w, 1.0 - i * 0.01)
                }
            }
        } else {
            for ((w, c) in m) {
                if (w.length > p.length && w.startsWith(p)) scores[w] = 2.0 + c
            }
            val dict = dictionary(lang)
            dict.forEachIndexed { i, w ->
                if (w.length > p.length && w.startsWith(p)) {
                    scores.putIfAbsent(w, 1.0 + (dict.size - i).toDouble() / dict.size)
                }
            }
            pairs?.forEach { (w, c) ->
                if (w.length > p.length && w.startsWith(p)) {
                    scores[w] = (scores[w] ?: 2.0) + 50.0 + c
                }
            }
        }
        return scores.entries
            .sortedWith(compareByDescending<Map.Entry<String, Double>> { it.value }.thenBy { it.key.length })
            .take(limit).map { it.key }
    }

    companion object {
        @Volatile private var instance: WordStore? = null

        fun get(ctx: Context): WordStore =
            instance ?: synchronized(this) {
                instance ?: WordStore(ctx.applicationContext).also { instance = it }
            }
    }
}
