package com.ikeyboard.ai

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color

/** Скин клавиатуры (цвета в стиле iPhone). */
data class Skin(
    val id: String,
    val name: String,
    val bg: Int,             // фон клавиатуры
    val key: Int,            // обычная клавиша
    val keyPressed: Int,
    val special: Int,        // служебная клавиша (shift, ⌫, 123, 🌐)
    val specialPressed: Int,
    val text: Int,
    val action: Int,         // синяя клавиша действия (Поиск / Отправить)
    val actionText: Int,
    val shadow: Int,         // тонкая тень под клавишей
    val hint: Int            // разделители и второстепенный текст
)

object Skins {
    const val AUTO_ID = "auto"

    private fun c(hex: String) = Color.parseColor(hex)

    val IOS_LIGHT = Skin(
        "ios_light", "iOS Светлая",
        c("#D1D4D9"), c("#FFFFFF"), c("#E4E5E9"), c("#ACB0BA"), c("#FFFFFF"),
        c("#000000"), c("#007AFF"), c("#FFFFFF"), c("#898A8D"), c("#8E8E93")
    )
    val IOS_DARK = Skin(
        "ios_dark", "iOS Тёмная",
        c("#2A2A2C"), c("#6B6B6F"), c("#8A8A8E"), c("#444447"), c("#6B6B6F"),
        c("#FFFFFF"), c("#0A84FF"), c("#FFFFFF"), c("#000000"), c("#98989D")
    )
    val MIDNIGHT = Skin(
        "midnight", "Полночь (OLED)",
        c("#000000"), c("#2C2C2E"), c("#48484A"), c("#1C1C1E"), c("#2C2C2E"),
        c("#FFFFFF"), c("#0A84FF"), c("#FFFFFF"), c("#000000"), c("#8E8E93")
    )
    val GRAPHITE = Skin(
        "graphite", "Графит",
        c("#3A3F47"), c("#5A606B"), c("#737A87"), c("#444A53"), c("#5A606B"),
        c("#FFFFFF"), c("#0A84FF"), c("#FFFFFF"), c("#1A1D22"), c("#A1A7B3")
    )
    val OCEAN = Skin(
        "ocean", "Океан",
        c("#BFDDF2"), c("#FFFFFF"), c("#DCEBF7"), c("#8FB9D8"), c("#FFFFFF"),
        c("#0B2A3F"), c("#007AFF"), c("#FFFFFF"), c("#7596AE"), c("#5B7A91")
    )
    val ROSE = Skin(
        "rose", "Розовая",
        c("#F6D5DE"), c("#FFFFFF"), c("#FBE9EE"), c("#E8A9BC"), c("#FFFFFF"),
        c("#3B1D28"), c("#FF2D55"), c("#FFFFFF"), c("#BE8B9A"), c("#9A6B7A")
    )
    val MINT = Skin(
        "mint", "Мятная",
        c("#CFE8DD"), c("#FFFFFF"), c("#E4F3EC"), c("#9CCDB5"), c("#FFFFFF"),
        c("#12352A"), c("#34C759"), c("#FFFFFF"), c("#7FA898"), c("#5A8272")
    )
    val SUNSET = Skin(
        "sunset", "Закат",
        c("#2D1B3D"), c("#52356B"), c("#6E4A8A"), c("#3B2550"), c("#52356B"),
        c("#FFFFFF"), c("#FF9500"), c("#FFFFFF"), c("#150A20"), c("#B79BD0")
    )

    /** Все скины, кроме «Авто». */
    val all: List<Skin> = listOf(IOS_LIGHT, IOS_DARK, MIDNIGHT, GRAPHITE, OCEAN, ROSE, MINT, SUNSET)

    /** Порядок для переключения кнопкой 🎨: «Авто» + все скины. */
    val cycleIds: List<String> = listOf(AUTO_ID) + all.map { it.id }

    fun isNight(ctx: Context): Boolean =
        (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES

    fun resolve(ctx: Context, id: String): Skin {
        if (id == AUTO_ID) return if (isNight(ctx)) IOS_DARK else IOS_LIGHT
        return all.firstOrNull { it.id == id } ?: IOS_LIGHT
    }

    fun displayName(id: String): String =
        if (id == AUTO_ID) "Авто (как в iPhone)" else all.firstOrNull { it.id == id }?.name ?: id
}
