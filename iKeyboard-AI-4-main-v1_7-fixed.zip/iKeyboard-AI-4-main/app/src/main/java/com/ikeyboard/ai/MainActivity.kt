package com.ikeyboard.ai

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private val store by lazy { WordStore.get(this) }

    private val night get() = Skins.isNight(this)
    private val bgColor get() = if (night) Color.rgb(20, 21, 25) else Color.rgb(242, 242, 247)
    private val cardColor get() = if (night) Color.rgb(36, 37, 42) else Color.WHITE
    private val textColor get() = if (night) Color.WHITE else Color.BLACK
    private val subColor get() = Color.GRAY
    private val blue = Color.rgb(0, 122, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createScreen()
        if (intent?.getBooleanExtra("ask_mic", false) == true && !hasMic()) askMic()
    }

    override fun onResume() {
        super.onResume()
        createScreen()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        createScreen()
    }

    private fun hasMic() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun askMic() = requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    // ---------- построение экрана ----------

    private fun createScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bgColor) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(32))
        }
        scroll.addView(root)

        root.addView(text("iKeyboard AI", 30f, textColor, Gravity.CENTER))
        root.addView(text("Умная клавиатура с запоминанием слов, диктовкой и скинами", 14f, subColor, Gravity.CENTER))

        // 1. подключение
        root.addView(section("1. Подключение"))
        val c1 = card(root)
        c1.addView(actionButton("Включить клавиатуру") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        c1.addView(actionButton("Выбрать iKeyboard AI") {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        c1.addView(
            actionButton(if (hasMic()) "Микрофон разрешён ✓" else "Разрешить микрофон (для диктовки)") {
                if (!hasMic()) askMic()
            }
        )

        // 2. скины
        root.addView(section("2. Скин клавиатуры"))
        val c2 = card(root)
        c2.addView(skinRow())
        val test = EditText(this).apply {
            hint = "Попробуйте клавиатуру здесь…"
            setTextColor(textColor)
            setHintTextColor(subColor)
        }
        c2.addView(test)

        // 3. настройки
        root.addView(section("3. Умные функции"))
        val c3 = card(root)
        c3.addView(toggle("Автоисправление опечаток", Prefs.AUTOCORRECT))
        c3.addView(toggle("Подсказки слов и следующего слова", Prefs.PREDICT))
        c3.addView(toggle("Исправлять диктовку по моему словарю", Prefs.DICT_FIX))
        c3.addView(toggle("Голосовые знаки: «запятая», «точка», «новая строка»", Prefs.VOICE_CMDS))
        c3.addView(toggle("Вибро-отклик клавиш", Prefs.HAPTIC))
        c3.addView(toggle("Звук нажатия клавиш", Prefs.KEY_SOUND))
        c3.addView(text("Чувствительность свайпа", 14f, textColor, Gravity.START))
        val sensitivityValue = TextView(this).apply {
            text = "Уровень: ${Prefs.int(this@MainActivity, Prefs.SENSITIVITY, 5)} / 10"
            textSize = 13f
            setTextColor(subColor)
        }
        c3.addView(sensitivityValue)
        val sensitivity = SeekBar(this).apply {
            max = 9
            progress = Prefs.int(this@MainActivity, Prefs.SENSITIVITY, 5).coerceIn(1, 10) - 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = progress + 1
                    Prefs.setInt(this@MainActivity, Prefs.SENSITIVITY, value)
                    sensitivityValue.text = "Уровень: $value / 10"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        c3.addView(sensitivity)

        // 4. личный словарь
        root.addView(section("4. Мой словарь"))
        val c4 = card(root)
        c4.addView(text("Запомнено слов: ${store.learnedCount()}", 16f, textColor, Gravity.START))
        c4.addView(actionButton("Открыть и управлять словарём") {
            showDictionaryScreen()
        })

        val add = EditText(this).apply {
            hint = "Добавить слово или имя"
            setTextColor(textColor)
            setHintTextColor(subColor)
            setSingleLine()
        }
        c4.addView(add)
        c4.addView(actionButton("Добавить в словарь") {
            val w = add.text.toString().trim()
            if (w.length >= 2) {
                val lang = if (w.any { it in 'а'..'я' || it in 'А'..'Я' || it == 'ё' || it == 'Ё' }) "ru" else "en"
                store.learn(lang, w, 5)
                createScreen()
            }
        })
        c4.addView(
            text(
                "Слова хранятся только на телефоне. В полях паролей, почты и ссылок, а также в режиме инкогнито клавиатура не должна обучаться.",
                12f, subColor, Gravity.START
            )
        )

        root.addView(section("5. Дополнительные инструменты"))
        val extras = card(root)
        extras.addView(actionButton("GIF, буфер обмена, эмодзи, свои словари и карты") {
            startActivity(Intent(this, ExtrasActivity::class.java))
        })
        extras.addView(text("Защищённое хранилище сохраняет только название карты и последние четыре цифры. Полный номер и CVV не сохраняются.", 12f, subColor, Gravity.START))

        root.addView(text("Версия 1.7 • Русский • English", 13f, subColor, Gravity.CENTER))
        setContentView(scroll)
    }

    // ---------- экран управления личным словарём ----------

    private fun showDictionaryScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bgColor) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        scroll.addView(root)

        root.addView(text("Мой словарь", 27f, textColor, Gravity.CENTER))
        root.addView(text("Запомнено слов: ${store.learnedCount()}", 15f, subColor, Gravity.CENTER))

        val search = EditText(this).apply {
            hint = "Поиск слова"
            setTextColor(textColor)
            setHintTextColor(subColor)
            setSingleLine()
        }
        root.addView(search)

        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        root.addView(
            list,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        fun render(query: String = "") {
            list.removeAllViews()
            val entries = listOf("ru", "en").flatMap { lang ->
                store.entries(lang).map { entry ->
                    Triple(lang, entry.key, entry.value)
                }
            }.filter { it.second.contains(query.trim(), ignoreCase = true) }
                .sortedByDescending { it.third }

            if (entries.isEmpty()) {
                list.addView(
                    text(
                        if (query.isBlank()) "Слов пока нет. Печатай — клавиатура будет запоминать новые слова."
                        else "Ничего не найдено.",
                        14f, subColor, Gravity.CENTER
                    )
                )
                return
            }

            entries.forEach { entry ->
                val lang = entry.first
                val word = entry.second
                val uses = entry.third

                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(4), 0, dp(4))
                }
                val info = TextView(this).apply {
                    text = "$word   ${if (lang == "ru") "RU" else "EN"}   •   $uses"
                    textSize = 15f
                    setTextColor(textColor)
                    gravity = Gravity.CENTER_VERTICAL
                }
                row.addView(info, LinearLayout.LayoutParams(0, dp(48), 1f))
                row.addView(actionButton("Удалить") {
                    store.forget(lang, word)
                    render(search.text.toString())
                }.apply {
                    textSize = 12f
                    layoutParams = LinearLayout.LayoutParams(dp(104), dp(42))
                })
                list.addView(row)

                val divider = View(this).apply {
                    setBackgroundColor(if (night) Color.DKGRAY else Color.LTGRAY)
                }
                list.addView(
                    divider,
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dp(1)
                    )
                )
            }
        }

        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                render(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })

        render()

        root.addView(actionButton("Очистить весь словарь") {
            AlertDialog.Builder(this)
                .setTitle("Очистить словарь?")
                .setMessage("Все выученные слова и связи между словами будут удалены с устройства.")
                .setPositiveButton("Очистить") { _, _ ->
                    store.clearAll()
                    showDictionaryScreen()
                }
                .setNegativeButton("Отмена", null)
                .show()
        })
        root.addView(actionButton("Назад") { createScreen() })

        setContentView(scroll)
    }

    // ---------- вспомогательные элементы ----------

    private fun text(t: String, size: Float, color: Int, gravity: Int) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        this.gravity = gravity
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun section(t: String) = TextView(this).apply {
        text = t
        textSize = 15f
        setTextColor(blue)
        setPadding(dp(4), dp(22), 0, dp(6))
    }

    private fun card(parent: LinearLayout): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply {
                setColor(cardColor)
                cornerRadius = dp(14).toFloat()
            }
        }
        parent.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return c
    }

    private fun actionButton(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 15f
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply {
            setColor(blue)
            cornerRadius = dp(10).toFloat()
        }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(48)
        ).apply { setMargins(0, dp(5), 0, dp(5)) }
    }

    private fun toggle(label: String, key: String) = Switch(this).apply {
        text = label
        textSize = 14f
        setTextColor(textColor)
        isChecked = Prefs.bool(this@MainActivity, key, key != Prefs.KEY_SOUND)
        setPadding(0, dp(8), 0, dp(8))
        setOnCheckedChangeListener { _, v -> Prefs.setBool(this@MainActivity, key, v) }
    }

    private fun skinRow(): View {
        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        hs.addView(row)
        val current = Prefs.skinId(this)
        for (id in Skins.cycleIds) {
            val s = Skins.resolve(this, id)
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(4), dp(4), dp(4), dp(4))
                setOnClickListener {
                    Prefs.setSkinId(this@MainActivity, id)
                    createScreen()
                }
            }
            item.addView(skinPreview(s, id == current), LinearLayout.LayoutParams(dp(96), dp(66)))
            item.addView(
                text(Skins.displayName(id).replace(" (как в iPhone)", ""), 11f, textColor, Gravity.CENTER)
            )
            row.addView(item, LinearLayout.LayoutParams(dp(106), ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        return hs
    }

    /** Мини-картинка клавиатуры: фон скина и три ряда клавиш. */
    private fun skinPreview(s: Skin, selected: Boolean): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5), dp(5), dp(5), dp(5))
            background = GradientDrawable().apply {
                setColor(s.bg)
                cornerRadius = dp(8).toFloat()
                setStroke(dp(if (selected) 3 else 1), if (selected) blue else Color.GRAY)
            }
        }
        for (r in 0 until 3) {
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in 0 until 6) {
                val special = (r == 2 && (k == 0 || k == 5))
                val key = View(this).apply {
                    background = GradientDrawable().apply {
                        setColor(if (special) s.special else s.key)
                        cornerRadius = dp(2).toFloat()
                    }
                }
                line.addView(key, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    setMargins(dp(1), dp(1), dp(1), dp(1))
                })
            }
            box.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        return box
    }
}
