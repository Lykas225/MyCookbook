package com.ikeyboard.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

private enum class Kind { LETTER, CHAR, SHIFT, BACKSPACE, SPACE, ENTER, FUNC, SPACER }

private data class KeyDef(
    val id: String,
    val label: String = id,
    val kind: Kind = Kind.CHAR,
    val weight: Float = 1f,
    val alt: String? = null
)

private class Undo(val original: String, val corrected: String, val boundary: String)

class KeyboardService : InputMethodService() {

    companion object {
        private const val OFF = 0
        private const val ONCE = 1
        private const val LOCK = 2

        private val RU_ROWS = listOf(
            listOf("й", "ц", "у", "к", "е", "н", "г", "ш", "щ", "з", "х", "ъ"),
            listOf("ф", "ы", "в", "а", "п", "р", "о", "л", "д", "ж", "э"),
            listOf("я", "ч", "с", "м", "и", "т", "ь", "б", "ю")
        )
        private val EN_ROWS = listOf(
            listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
            listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
            listOf("z", "x", "c", "v", "b", "n", "m")
        )

        private val EMOJIS = listOf(
            "😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣", "😊", "😇", "🙂", "😉",
            "😍", "🥰", "😘", "😋", "😎", "🤩", "🥳", "😏", "😒", "😞", "😔", "😢",
            "😭", "😤", "😡", "🤯", "😱", "😴", "🤔", "🤗", "🙄", "😬", "🤝", "👍",
            "👎", "👏", "🙏", "💪", "👌", "✌️", "🤞", "👋", "🤙", "❤️", "🧡", "💛",
            "💚", "💙", "💜", "🖤", "💔", "🔥", "✨", "⭐", "🌟", "💯", "✅", "❌",
            "⚡", "🎉", "🎁", "🎂", "🚗", "🏠", "📱", "💻", "☕", "🍕", "🍔", "🍺",
            "🌹", "🌞", "🌙", "☀️", "🌧️", "⏰", "💰", "📞"
        )

        private val WORD_TAIL = Regex("[\\p{L}]+(?:['’][\\p{L}]+)*$")
        private val PREV_WORD = Regex("([\\p{L}]+)\\s+$")
    }

    private val handler = Handler(Looper.getMainLooper())
    private val store by lazy { WordStore.get(this) }

    private var skin: Skin = Skins.IOS_LIGHT
    private var root: LinearLayout? = null

    private var isRussian = true
    private var page = 0                // 0 буквы, 1 цифры, 2 символы
    private var emojiMode = false
    private var shiftState = OFF
    private var lastShiftTap = 0L
    private var lastSpaceTime = 0L

    private var undo: Undo? = null
    private var skipCorrection: String? = null

    // views
    private val letterKeys = ArrayList<Pair<String, TextView>>()
    private var shiftKey: TextView? = null
    private var sugViews: List<TextView> = emptyList()
    private var micBtn: TextView? = null
    private var partialView: TextView? = null

    // key press handling
    private var pendingLong: Runnable? = null
    private var longFired = false
    private var repeatRunnable: Runnable? = null
    private val swipePath = ArrayList<String>()
    private var swipeStartX = 0f
    private var swipeStartY = 0f
    private var swipeLastX = 0f
    private var swipeLastY = 0f
    private var swipeMoved = false
    private var toneGenerator: ToneGenerator? = null

    // dictation
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var noSpeech = 0
    private var busyRetries = 0

    private val nbRu by lazy { TextFixer.buildNeighbors(RU_ROWS) }
    private val nbEn by lazy { TextFixer.buildNeighbors(EN_ROWS) }

    private fun lang() = if (isRussian) "ru" else "en"
    private fun neighbors() = if (isRussian) nbRu else nbEn

    // ================= жизненный цикл =================

    override fun onCreateInputView(): View {
        val r = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root = r
        buildKeyboard()
        return r
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        undo = null
        skipCorrection = null
        destroyRecognizer()
        if (!restarting) {
            val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
            page = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE ||
                cls == InputType.TYPE_CLASS_DATETIME) 1 else 0
            emojiMode = false
            shiftState = OFF
        }
        updateAutoCap()
        buildKeyboard()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        cancelRepeat()
        destroyRecognizer()
    }

    override fun onWindowHidden() {
        super.onWindowHidden()
        cancelRepeat()
        destroyRecognizer()
    }

    override fun onDestroy() {
        destroyRecognizer()
        try { toneGenerator?.release() } catch (e: Exception) {}
        toneGenerator = null
        super.onDestroy()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(
            oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd
        )
        updateSuggestions()
    }

    // ================= поля ввода =================

    private fun sensitiveField(): Boolean {
        val t = currentInputEditorInfo?.inputType ?: return false
        val cls = t and InputType.TYPE_MASK_CLASS
        val v = t and InputType.TYPE_MASK_VARIATION
        return when (cls) {
            InputType.TYPE_CLASS_TEXT -> v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                v == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS ||
                v == InputType.TYPE_TEXT_VARIATION_URI
            InputType.TYPE_CLASS_NUMBER -> v == InputType.TYPE_NUMBER_VARIATION_PASSWORD
            else -> false
        }
    }

    private fun canLearn(): Boolean {
        val info = currentInputEditorInfo ?: return false
        if (sensitiveField()) return false
        if ((info.imeOptions and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING) != 0) return false
        val t = info.inputType
        if ((t and InputType.TYPE_MASK_CLASS) != InputType.TYPE_CLASS_TEXT) return false
        val v = t and InputType.TYPE_MASK_VARIATION
        return v == InputType.TYPE_TEXT_VARIATION_NORMAL ||
            v == InputType.TYPE_TEXT_VARIATION_SHORT_MESSAGE ||
            v == InputType.TYPE_TEXT_VARIATION_LONG_MESSAGE ||
            v == InputType.TYPE_TEXT_VARIATION_EMAIL_SUBJECT ||
            v == InputType.TYPE_TEXT_VARIATION_PERSON_NAME ||
            v == InputType.TYPE_TEXT_VARIATION_FILTER ||
            v == InputType.TYPE_TEXT_VARIATION_WEB_EDIT_TEXT
    }

    private fun autocorrectAllowed(): Boolean {
        val t = currentInputEditorInfo?.inputType ?: return false
        if ((t and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0) return false
        return Prefs.bool(this, Prefs.AUTOCORRECT) && canLearn()
    }

    // ================= построение клавиатуры =================

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun keyH(): Int =
        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) dp(38) else dp(46)

    private fun buildKeyboard() {
        val r = root ?: return
        skin = Skins.resolve(this, Prefs.skinId(this))
        r.removeAllViews()
        letterKeys.clear()
        shiftKey = null
        r.setBackgroundColor(skin.bg)
        // Чуть больше воздуха вокруг клавиш — ближе к системной iOS-клавиатуре
        r.setPadding(dp(4), dp(4), dp(4), dp(8))

        r.addView(buildBar(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)))

        if (emojiMode) {
            buildEmojiPanel(r)
        } else when (page) {
            0 -> buildLetters(r)
            1 -> buildNumbers(r)
            else -> buildSymbols(r)
        }
        refreshShiftVisuals()
        setListeningUi(listening)
        updateSuggestions()
    }

    private fun spacer(w: Float) = KeyDef("", "", Kind.SPACER, w)

    private fun letterDefs(row: List<String>) =
        row.map { KeyDef(it, it, Kind.LETTER, 1f, if (it == "е") "ё" else null) }

    private fun enterInfo(): Pair<String, Boolean> {
        val info = currentInputEditorInfo ?: return "↵" to false
        if ((info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return "↵" to false
        return when (info.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_GO -> (if (isRussian) "Перейти" else "Go") to true
            EditorInfo.IME_ACTION_SEARCH -> (if (isRussian) "Поиск" else "Search") to true
            EditorInfo.IME_ACTION_SEND -> (if (isRussian) "Отпр." else "Send") to true
            EditorInfo.IME_ACTION_NEXT -> (if (isRussian) "Далее" else "Next") to true
            EditorInfo.IME_ACTION_DONE -> (if (isRussian) "Готово" else "Done") to true
            else -> "↵" to false
        }
    }

    private fun buildLetters(parent: LinearLayout) {
        val rows = if (isRussian) RU_ROWS else EN_ROWS
        addRow(parent, letterDefs(rows[0]))
        addRow(parent, listOf(spacer(0.5f)) + letterDefs(rows[1]) + listOf(spacer(0.5f)))
        addRow(
            parent,
            listOf(KeyDef("SHIFT", "⇧", Kind.SHIFT, 1.5f)) + letterDefs(rows[2]) +
                listOf(KeyDef("BKSP", "⌫", Kind.BACKSPACE, 1.5f))
        )
        addRow(
            parent, listOf(
                KeyDef("PAGE_NUM", "123", Kind.FUNC, 1.3f),
                KeyDef("LANG", "🌐", Kind.FUNC, 1f),
                KeyDef("EMOJI", "😊", Kind.FUNC, 1f),
                KeyDef(",", ",", Kind.CHAR, 0.8f),
                KeyDef("SPACE", if (isRussian) "Русский" else "English", Kind.SPACE, 3.4f),
                KeyDef(".", ".", Kind.CHAR, 0.8f),
                KeyDef("ENTER", enterInfo().first, Kind.ENTER, 1.7f)
            )
        )
    }

    private fun chars(list: List<String>, w: Float = 1f) = list.map { KeyDef(it, it, Kind.CHAR, w) }

    private fun bottomSymbols(): List<KeyDef> = listOf(
        KeyDef("PAGE_ABC", if (isRussian) "АБВ" else "ABC", Kind.FUNC, 1.5f),
        KeyDef("LANG", "🌐", Kind.FUNC, 1f),
        KeyDef("EMOJI", "😊", Kind.FUNC, 1f),
        KeyDef("SPACE", "space", Kind.SPACE, 4.2f),
        KeyDef("ENTER", enterInfo().first, Kind.ENTER, 1.7f)
    )

    private fun buildNumbers(parent: LinearLayout) {
        addRow(parent, chars(listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")))
        addRow(
            parent,
            chars(listOf("-", "/", ":", ";", "(", ")", if (isRussian) "₽" else "$", "&", "@", "\""))
        )
        addRow(
            parent,
            listOf(KeyDef("PAGE_SYM", "#+=", Kind.FUNC, 1.5f)) +
                chars(listOf(".", ",", "?", "!", "'"), 1.4f) +
                listOf(KeyDef("BKSP", "⌫", Kind.BACKSPACE, 1.5f))
        )
        addRow(parent, bottomSymbols())
    }

    private fun buildSymbols(parent: LinearLayout) {
        addRow(parent, chars(listOf("[", "]", "{", "}", "#", "%", "^", "*", "+", "=")))
        addRow(parent, chars(listOf("_", "\\", "|", "~", "<", ">", "€", "£", "¥", "•")))
        addRow(
            parent,
            listOf(KeyDef("PAGE_NUM", "123", Kind.FUNC, 1.5f)) +
                chars(listOf(".", ",", "?", "!", "'"), 1.4f) +
                listOf(KeyDef("BKSP", "⌫", Kind.BACKSPACE, 1.5f))
        )
        addRow(parent, bottomSymbols())
    }

    private fun buildEmojiPanel(parent: LinearLayout) {
        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        EMOJIS.chunked(8).forEach { chunk ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in 0 until 8) {
                val e = chunk.getOrNull(i)
                val tv = TextView(this).apply {
                    text = e ?: ""
                    textSize = 26f
                    gravity = Gravity.CENTER
                    if (e != null) setOnClickListener {
                        performHaptic(it)
                        currentInputConnection?.commitText(e, 1)
                        updateSuggestions()
                    }
                }
                line.addView(tv, LinearLayout.LayoutParams(0, dp(44), 1f))
            }
            col.addView(line)
        }
        scroll.addView(col)
        parent.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, keyH() * 3 + dp(12)))
        addRow(
            parent, listOf(
                KeyDef("PAGE_ABC", if (isRussian) "АБВ" else "ABC", Kind.FUNC, 1.5f),
                KeyDef("SPACE", "space", Kind.SPACE, 5f),
                KeyDef("BKSP", "⌫", Kind.BACKSPACE, 1.5f)
            )
        )
    }

    private fun addRow(parent: LinearLayout, defs: List<KeyDef>) {
        val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (d in defs) {
            val lp = LinearLayout.LayoutParams(0, keyH(), d.weight)
            if (d.kind == Kind.SPACER) {
                lp.setMargins(0, dp(4), 0, dp(4))
                line.addView(View(this), lp)
            } else {
                lp.setMargins(dp(3), dp(4), dp(3), dp(4))
                line.addView(makeKey(d), lp)
            }
        }
        parent.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    // ================= оформление клавиш =================

    private fun keyShape(fill: Int): Drawable {
        // Нижний слой остаётся виден под лицевой частью и создаёт объёмную тень
        val radius = dp(10).toFloat()
        val shadow = GradientDrawable().apply {
            setColor(skin.shadow)
            cornerRadius = radius
        }
        val face = GradientDrawable().apply {
            setColor(fill)
            cornerRadius = radius
            setStroke(dp(1), (skin.hint and 0x00FFFFFF) or 0x22000000)
        }
        return LayerDrawable(arrayOf<Drawable>(shadow, face)).apply {
            // Четыре dp тени снизу делают каждую клавишу визуально приподнятой
            setLayerInset(1, 0, 0, 0, dp(4))
        }
    }

    private fun stateBg(normal: Int, pressed: Int): Drawable = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), keyShape(pressed))
        addState(intArrayOf(), keyShape(normal))
    }

    private fun bgFor(kind: Kind, action: Boolean): Drawable = when {
        kind == Kind.ENTER && action -> stateBg(skin.action, skin.action)
        kind == Kind.LETTER || kind == Kind.CHAR || kind == Kind.SPACE -> stateBg(skin.key, skin.keyPressed)
        else -> stateBg(skin.special, skin.specialPressed)
    }

    private fun makeKey(d: KeyDef): View {
        val enter = if (d.kind == Kind.ENTER) enterInfo() else null
        val isAction = enter?.second == true
        val tv = TextView(this).apply {
            text = when (d.kind) {
                Kind.LETTER -> if (shiftState != OFF) d.label.uppercase(Locale.ROOT) else d.label
                else -> d.label
            }
            gravity = Gravity.CENTER
            setTextColor(if (isAction) skin.actionText else skin.text)
            textSize = when {
                d.kind == Kind.LETTER || d.kind == Kind.CHAR -> 22f
                d.kind == Kind.SPACE -> 13f
                d.label.length > 2 -> 15f
                else -> 20f
            }
            background = bgFor(d.kind, isAction)
            includeFontPadding = false
            isClickable = true
            isFocusable = true
            // Слегка приподнятый вид клавиш с ровным внутренним отступом
            setPadding(dp(1), 0, dp(1), dp(2))
            stateListAnimator = null
        }
        if (d.kind == Kind.LETTER) letterKeys.add(d.id to tv)
        if (d.kind == Kind.SHIFT) shiftKey = tv
        tv.setOnTouchListener { v, e -> handleTouch(v, e, d) }
        return tv
    }

    private fun refreshShiftVisuals() {
        for ((base, tv) in letterKeys) {
            tv.text = if (shiftState != OFF) base.uppercase(Locale.ROOT) else base
        }
        shiftKey?.let {
            it.text = if (shiftState == LOCK) "⇪" else "⇧"
            it.background = if (shiftState == OFF) bgFor(Kind.SHIFT, false) else bgFor(Kind.LETTER, false)
        }
    }

    // ================= нажатия =================

    private fun performHaptic(v: View) {
        if (!Prefs.bool(this, Prefs.HAPTIC)) return
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(VIBRATOR_SERVICE) as Vibrator
            }
            if (vibrator.hasVibrator()) {
                vibrator.vibrate(VibrationEffect.createOneShot(18L, 90))
            } else {
                v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            }
        } catch (e: Exception) {
            try { v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) } catch (e: Exception) {}
        }
    }

    private fun playKeySound() {
        if (!Prefs.bool(this, Prefs.KEY_SOUND, false)) return
        try {
            if (toneGenerator == null) toneGenerator = ToneGenerator(AudioManager.STREAM_SYSTEM, 18)
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 18)
        } catch (e: Exception) { }
    }

    private fun nearestLetter(rawX: Float, rawY: Float): String? {
        var best: String? = null
        var bestDistance = Float.MAX_VALUE
        for ((id, view) in letterKeys) {
            val location = IntArray(2)
            view.getLocationOnScreen(location)
            val cx = location[0] + view.width / 2f
            val cy = location[1] + view.height / 2f
            val dx = rawX - cx
            val dy = rawY - cy
            val distance = dx * dx + dy * dy
            val radius = view.width * (0.35f + Prefs.int(this, Prefs.SENSITIVITY, 5).coerceIn(1, 10) * 0.055f)
            if (distance < bestDistance && distance <= radius * radius) {
                bestDistance = distance
                best = id
            }
        }
        return best
    }

    private fun addSwipeLetter(letter: String?) {
        if (letter != null && swipePath.lastOrNull() != letter) swipePath.add(letter)
    }

    private fun handleTouch(v: View, e: MotionEvent, d: KeyDef): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                v.isPressed = true
                v.animate().scaleX(0.94f).scaleY(0.92f).translationY(dp(2).toFloat())
                    .setDuration(65).start()
                performHaptic(v)
                playKeySound()
                if (d.kind == Kind.LETTER) {
                    swipePath.clear()
                    swipePath.add(d.id)
                    swipeStartX = e.rawX
                    swipeStartY = e.rawY
                    swipeLastX = e.rawX
                    swipeLastY = e.rawY
                    swipeMoved = false
                } else if (d.alt != null) {
                    longFired = false
                    val r = Runnable {
                        longFired = true
                        onChar(if (shiftState != OFF) d.alt.uppercase(Locale.ROOT) else d.alt, true)
                    }
                    pendingLong = r
                    handler.postDelayed(r, 380)
                } else {
                    fire(d)
                    if (d.kind == Kind.BACKSPACE) startRepeat()
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (d.kind == Kind.LETTER) {
                    val dx = e.rawX - swipeStartX
                    val dy = e.rawY - swipeStartY
                    if (dx * dx + dy * dy > dp(12) * dp(12)) swipeMoved = true
                    if (swipeMoved) addSwipeLetter(nearestLetter(e.rawX, e.rawY))
                    swipeLastX = e.rawX
                    swipeLastY = e.rawY
                }
            }
            MotionEvent.ACTION_UP -> {
                v.isPressed = false
                v.animate().scaleX(1f).scaleY(1f).translationY(0f).setDuration(90).start()
                pendingLong?.let { handler.removeCallbacks(it) }
                pendingLong = null
                if (d.kind == Kind.LETTER) {
                    if (swipeMoved && swipePath.size >= 3) {
                        val candidate = bestSwipeWord(swipePath.joinToString(""))
                        if (candidate != null) commitSwipeWord(candidate)
                        else fire(d)
                    } else fire(d)
                    swipePath.clear()
                }
                if (d.alt != null && !longFired) fire(d)
                cancelRepeat()
            }
            MotionEvent.ACTION_CANCEL -> {
                v.isPressed = false
                v.animate().scaleX(1f).scaleY(1f).translationY(0f).setDuration(80).start()
                pendingLong?.let { handler.removeCallbacks(it) }
                pendingLong = null
                swipePath.clear()
                cancelRepeat()
            }
        }
        return true
    }

    private fun bestSwipeWord(path: String): String? {
        if (path.length < 3 || sensitiveField()) return null
        val words = LinkedHashSet<String>()
        words.addAll(store.entries(lang()).keys)
        val resource = if (isRussian) R.raw.words_ru else R.raw.words_en
        try {
            resources.openRawResource(resource).bufferedReader().useLines { lines ->
                lines.forEach { line ->
                    val w = line.trim().lowercase(Locale.ROOT)
                    if (w.length in 3..18) words.add(w)
                }
            }
        } catch (e: Exception) { }
        if (words.isEmpty()) return null
        val ranked = words.map { it to swipeDistance(path, it) }.sortedBy { it.second }
        val best = ranked.firstOrNull() ?: return null
        val threshold = 0.48f + (10 - Prefs.int(this, Prefs.SENSITIVITY, 5).coerceIn(1, 10)) * 0.018f
        return best.first.takeIf { best.second <= threshold }
    }

    private fun swipeDistance(a: String, b: String): Float {
        val prev = IntArray(b.length + 1) { it }
        for (i in a.indices) {
            val cur = IntArray(b.length + 1)
            cur[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                cur[j + 1] = minOf(cur[j] + 1, prev[j + 1] + 1, prev[j] + cost)
            }
            for (j in prev.indices) prev[j] = cur[j]
        }
        return prev[b.length].toFloat() / maxOf(a.length, b.length, 1)
    }

    private fun commitSwipeWord(word: String) {
        val output = if (shiftState != OFF) word.replaceFirstChar { it.uppercase(Locale.ROOT) } else word
        currentInputConnection?.commitText(output + " ", 1)
        if (canLearn()) store.learn(lang(), word)
        shiftState = OFF
        updateAutoCap()
        refreshShiftVisuals()
        updateSuggestions()
    }

    private fun startRepeat() {
        cancelRepeat()
        val r = object : Runnable {
            override fun run() {
                onBackspace()
                handler.postDelayed(this, 55)
            }
        }
        repeatRunnable = r
        handler.postDelayed(r, 400)
    }

    private fun cancelRepeat() {
        repeatRunnable?.let { handler.removeCallbacks(it) }
        repeatRunnable = null
    }

    private fun fire(d: KeyDef) {
        when (d.kind) {
            Kind.LETTER -> onChar(if (shiftState != OFF) d.id.uppercase(Locale.ROOT) else d.id, true)
            Kind.CHAR -> onChar(d.id, false)
            Kind.SHIFT -> onShift()
            Kind.BACKSPACE -> onBackspace()
            Kind.SPACE -> onSpace()
            Kind.ENTER -> onEnter()
            Kind.FUNC -> onFunc(d.id)
            Kind.SPACER -> {}
        }
    }

    private fun onFunc(id: String) {
        undo = null
        when (id) {
            "LANG" -> {
                destroyRecognizer()
                isRussian = !isRussian
                page = 0
                emojiMode = false
                buildKeyboard()
            }
            "EMOJI" -> { emojiMode = true; buildKeyboard() }
            "PAGE_NUM" -> { page = 1; emojiMode = false; buildKeyboard() }
            "PAGE_SYM" -> { page = 2; buildKeyboard() }
            "PAGE_ABC" -> { page = 0; emojiMode = false; buildKeyboard() }
        }
    }

    private fun onShift() {
        val now = SystemClock.uptimeMillis()
        shiftState = when (shiftState) {
            OFF -> ONCE
            ONCE -> if (now - lastShiftTap < 350) LOCK else OFF
            else -> OFF
        }
        lastShiftTap = now
        refreshShiftVisuals()
    }

    private fun updateAutoCap() {
        if (shiftState == LOCK) return
        val info = currentInputEditorInfo
        val conn = currentInputConnection
        val caps = if (info != null && conn != null && info.inputType != 0)
            conn.getCursorCapsMode(info.inputType) else 0
        val n = if (caps != 0) ONCE else OFF
        if (n != shiftState) {
            shiftState = n
            refreshShiftVisuals()
        }
    }

    // ================= ввод текста =================

    private fun onChar(c: String, letter: Boolean) {
        val conn = currentInputConnection ?: return
        undo = null
        if (!letter && c.length == 1 && !c[0].isLetterOrDigit() && c[0] != '\'') finishWord(c[0])
        conn.commitText(c, 1)
        if (letter && shiftState == ONCE) shiftState = OFF
        updateAutoCap()
        refreshShiftVisuals()
        updateSuggestions()
    }

    private fun onSpace() {
        val conn = currentInputConnection ?: return
        undo = null
        val now = SystemClock.uptimeMillis()
        val before = conn.getTextBeforeCursor(2, 0)?.toString().orEmpty()
        if (before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit() &&
            now - lastSpaceTime < 700 && !sensitiveField()
        ) {
            conn.deleteSurroundingText(1, 0)
            conn.commitText(". ", 1)
            lastSpaceTime = 0
        } else {
            finishWord(' ')
            conn.commitText(" ", 1)
            lastSpaceTime = now
        }
        updateAutoCap()
        refreshShiftVisuals()
        updateSuggestions()
    }

    private fun onEnter() {
        val conn = currentInputConnection ?: return
        undo = null
        finishWord('\n')
        val info = currentInputEditorInfo
        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noAction = ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (info != null && !noAction &&
            action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            conn.performEditorAction(action)
        } else {
            conn.commitText("\n", 1)
        }
        updateAutoCap()
        refreshShiftVisuals()
        updateSuggestions()
    }

    private fun onBackspace() {
        val conn = currentInputConnection ?: return
        val u = undo
        if (u != null) {
            val tail = u.corrected + u.boundary
            val before = conn.getTextBeforeCursor(tail.length, 0)?.toString()
            if (before == tail) {
                // откат автоисправления: вернуть слово как было и больше его не исправлять
                conn.deleteSurroundingText(tail.length, 0)
                conn.commitText(u.original, 1)
                skipCorrection = u.original.lowercase(Locale.ROOT)
                if (canLearn()) store.learn(lang(), u.original, 2)
                undo = null
                updateAutoCap(); refreshShiftVisuals(); updateSuggestions()
                return
            }
        }
        undo = null
        val sel = conn.getSelectedText(0)
        if (!sel.isNullOrEmpty()) {
            conn.commitText("", 1)
        } else {
            val before = conn.getTextBeforeCursor(2, 0)
            if (before.isNullOrEmpty()) {
                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            } else if (before.length == 2 && Character.isLowSurrogate(before[1]) &&
                Character.isHighSurrogate(before[0])
            ) {
                conn.deleteSurroundingText(2, 0)
            } else {
                conn.deleteSurroundingText(1, 0)
            }
        }
        updateAutoCap()
        refreshShiftVisuals()
        updateSuggestions()
    }

    /** Слово закончено (пробел, знак препинания, Enter): исправить опечатку и запомнить слово. */
    private fun finishWord(boundary: Char) {
        val conn = currentInputConnection ?: return
        val before = conn.getTextBeforeCursor(64, 0)?.toString().orEmpty()
        val word = WORD_TAIL.find(before)?.value ?: return
        var finalWord = word
        val lower = word.lowercase(Locale.ROOT)

        if (skipCorrection == lower) {
            skipCorrection = null
        } else if (boundary in " .,!?;:\n" && autocorrectAllowed()) {
            val fix = TextFixer.autocorrect(word, lang(), store, neighbors())
            if (fix != null) {
                conn.deleteSurroundingText(word.length, 0)
                conn.commitText(fix, 1)
                undo = Undo(word, fix, boundary.toString())
                finalWord = fix
            }
        }
        learnWord(finalWord, before.dropLast(word.length))
    }

    private fun learnWord(word: String, textBefore: String) {
        if (!canLearn()) return
        val w = word.lowercase(Locale.ROOT)
        if (w.length < 2) return
        store.learn(lang(), w)
        val prev = PREV_WORD.find(textBefore)?.groupValues?.get(1)?.lowercase(Locale.ROOT)
        if (prev != null) store.learnPair(lang(), prev, w)
    }

    // ================= панель подсказок =================

    private fun buildBar(): View {
        val frame = FrameLayout(this)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val skinBtn = barButton("🎨") { cycleSkin() }
        row.addView(skinBtn, LinearLayout.LayoutParams(dp(44), ViewGroup.LayoutParams.MATCH_PARENT))

        val list = ArrayList<TextView>()
        for (i in 0 until 3) {
            val tv = TextView(this).apply {
                textSize = 16f
                setTextColor(skin.text)
                gravity = Gravity.CENTER
                maxLines = 1
            }
            list.add(tv)
            row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            if (i < 2) {
                val sep = View(this).apply { setBackgroundColor((skin.hint and 0x00FFFFFF) or 0x66000000) }
                val lp = LinearLayout.LayoutParams(dp(1), dp(20))
                row.addView(sep, lp)
            }
        }
        sugViews = list

        val mic = barButton("🎤") { toggleDictation() }
        micBtn = mic
        row.addView(mic, LinearLayout.LayoutParams(dp(44), ViewGroup.LayoutParams.MATCH_PARENT))

        val partial = TextView(this).apply {
            visibility = View.GONE
            gravity = Gravity.CENTER
            textSize = 15f
            maxLines = 1
            setTextColor(skin.text)
            setBackgroundColor(skin.bg)
        }
        partialView = partial

        frame.addView(row, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.addView(
            partial,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                .apply { setMargins(dp(44), 0, dp(44), 0) }
        )
        return frame
    }

    private fun barButton(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 19f
        gravity = Gravity.CENTER
        setTextColor(skin.text)
        isClickable = true
        setOnClickListener { performHaptic(it); onClick() }
    }

    private fun cycleSkin() {
        val ids = Skins.cycleIds
        val cur = ids.indexOf(Prefs.skinId(this)).let { if (it < 0) 0 else it }
        val next = ids[(cur + 1) % ids.size]
        Prefs.setSkinId(this, next)
        buildKeyboard()
        toast(Skins.displayName(next))
    }

    private fun capitalize(w: String) = w.replaceFirstChar { it.uppercase(Locale.ROOT) }

    private fun updateSuggestions() {
        if (sugViews.isEmpty()) return
        val conn = currentInputConnection
        val before = conn?.getTextBeforeCursor(80, 0)?.toString().orEmpty()
        val prefix = WORD_TAIL.find(before)?.value.orEmpty()
        val prevWord = PREV_WORD.find(before.dropLast(prefix.length))?.groupValues?.get(1)

        val words: List<String> =
            if (!Prefs.bool(this, Prefs.PREDICT) || sensitiveField() || conn == null) emptyList()
            else store.suggest(lang(), prevWord, prefix, 3)

        val shown = words.map {
            when {
                prefix.isNotEmpty() && prefix[0].isUpperCase() -> capitalize(it)
                prefix.isEmpty() && shiftState != OFF -> capitalize(it)
                else -> it
            }
        }

        sugViews.forEachIndexed { i, tv ->
            val w = shown.getOrNull(i)
            if (w == null) {
                tv.text = if (i == 0 && prefix.isNotEmpty()) prefix else ""
                tv.isClickable = false
                tv.setOnClickListener(null)
            } else {
                tv.text = w
                tv.isClickable = true
                tv.setOnClickListener { performHaptic(it); applySuggestion(w, prefix) }
            }
        }
    }

    private fun applySuggestion(word: String, prefix: String) {
        val conn = currentInputConnection ?: return
        undo = null
        val before = conn.getTextBeforeCursor(64, 0)?.toString().orEmpty()
        conn.beginBatchEdit()
        if (prefix.isNotEmpty()) conn.deleteSurroundingText(prefix.length, 0)
        else if (before.isNotEmpty() && !before.last().isWhitespace()) conn.commitText(" ", 1)
        conn.commitText("$word ", 1)
        conn.endBatchEdit()
        learnWord(word, if (prefix.isNotEmpty()) before.dropLast(prefix.length) else before)
        updateAutoCap()
        refreshShiftVisuals()
        updateSuggestions()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    // ================= голосовой ввод =================

    private fun toggleDictation() {
        if (listening) stopDictationSoft() else startDictation()
    }

    private fun startDictation() {
        if (sensitiveField()) {
            toast("В этом поле диктовка отключена")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Разрешите доступ к микрофону")
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra("ask_mic", true)
            )
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("Нет службы распознавания речи (нужно приложение Google)")
            return
        }
        listening = true
        noSpeech = 0
        busyRetries = 0
        setListeningUi(true)
        beginRecognition()
    }

    private fun recognitionIntent(): Intent {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (isRussian) "ru-RU" else "en-US")
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        // Android 13+: подсказать распознавателю ваши частые слова (имена, жаргон)
        val bias = store.topWords(lang(), 100).filter { it.length >= 4 }
        if (bias.isNotEmpty()) i.putStringArrayListExtra("android.speech.extra.BIASING_STRINGS", ArrayList(bias))
        return i
    }

    private fun beginRecognition() {
        try {
            val r: SpeechRecognizer = recognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(listener)
                recognizer = it
            }
            r.startListening(recognitionIntent())
        } catch (e: Exception) {
            toast("Не удалось запустить диктовку")
            listening = false
            setListeningUi(false)
            destroyRecognizer()
        }
    }

    private fun stopDictationSoft() {
        listening = false
        setListeningUi(false)
        try { recognizer?.stopListening() } catch (e: Exception) { destroyRecognizer() }
    }

    private fun destroyRecognizer() {
        listening = false
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (e: Exception) { /* ignore */ }
        recognizer = null
        setListeningUi(false)
    }

    private fun setListeningUi(on: Boolean) {
        micBtn?.apply {
            text = if (on) "⏹" else "🎤"
            setTextColor(if (on) Color.rgb(255, 59, 48) else skin.text)
        }
        partialView?.apply {
            visibility = if (on) View.VISIBLE else View.GONE
            if (on) text = if (isRussian) "Говорите…" else "Listening…"
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!p.isNullOrBlank() && listening) partialView?.text = p
        }

        override fun onResults(results: Bundle?) {
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val conf = results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)
            if (!list.isNullOrEmpty()) {
                noSpeech = 0
                busyRetries = 0
                commitDictation(list, conf)
            }
            if (listening) {
                partialView?.text = if (isRussian) "Говорите…" else "Listening…"
                handler.postDelayed({ if (listening) beginRecognition() }, 150)
            } else {
                destroyRecognizer()
            }
        }

        override fun onError(error: Int) {
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    noSpeech++
                    if (listening && noSpeech < 2) {
                        handler.postDelayed({ if (listening) beginRecognition() }, 150)
                    } else {
                        destroyRecognizer()
                    }
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    busyRetries++
                    try { recognizer?.cancel() } catch (e: Exception) { /* ignore */ }
                    if (listening && busyRetries < 3) {
                        handler.postDelayed({ if (listening) beginRecognition() }, 400)
                    } else {
                        destroyRecognizer()
                    }
                }
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    destroyRecognizer()
                    toast("Разрешите доступ к микрофону")
                    startActivity(
                        Intent(this@KeyboardService, MainActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            .putExtra("ask_mic", true)
                    )
                }
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                SpeechRecognizer.ERROR_SERVER -> {
                    destroyRecognizer()
                    toast("Нет сети для распознавания речи")
                }
                else -> {
                    destroyRecognizer()
                    toast("Ошибка распознавания речи ($error)")
                }
            }
        }
    }

    /** Результат диктовки → правильное написание → вставка в поле. */
    private fun commitDictation(hyps: List<String>, conf: FloatArray?) {
        val conn = currentInputConnection ?: return
        val lang = lang()
        var text = TextFixer.rerank(hyps, conf, lang, store)
        if (Prefs.bool(this, Prefs.DICT_FIX)) text = TextFixer.correctWords(text, lang, store)
        val before = conn.getTextBeforeCursor(40, 0)?.toString().orEmpty()
        text = TextFixer.normalizeDictation(text, before, isRussian, Prefs.bool(this, Prefs.VOICE_CMDS))
        if (text.isEmpty()) return
        undo = null
        conn.commitText(text, 1)
        if (canLearn()) store.reinforce(lang, text)
        updateAutoCap()
        refreshShiftVisuals()
        updateSuggestions()
    }
}
