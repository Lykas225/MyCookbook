package com.ikeyboard.ai

import android.content.Context
import android.content.SharedPreferences

/** Настройки клавиатуры (общие для приложения и сервиса клавиатуры). */
object Prefs {
    const val AUTOCORRECT = "autocorrect"   // автоисправление опечаток при наборе
    const val PREDICT = "predict"           // подсказки слов и следующего слова
    const val HAPTIC = "haptic"             // вибро-отклик
    const val KEY_SOUND = "key_sound"       // звук клавиш
    const val SENSITIVITY = "sensitivity"   // чувствительность свайпа 1..10
    const val VOICE_CMDS = "voice_cmds"     // «запятая», «точка», «новая строка» при диктовке
    const val DICT_FIX = "dict_fix"         // исправление диктовки по вашему словарю

    private fun sp(c: Context): SharedPreferences =
        c.getSharedPreferences("ikeyboard_settings", Context.MODE_PRIVATE)

    fun skinId(c: Context): String = sp(c).getString("skin", Skins.AUTO_ID) ?: Skins.AUTO_ID
    fun setSkinId(c: Context, id: String) = sp(c).edit().putString("skin", id).apply()

    fun bool(c: Context, key: String, def: Boolean = true): Boolean = sp(c).getBoolean(key, def)
    fun setBool(c: Context, key: String, v: Boolean) = sp(c).edit().putBoolean(key, v).apply()
    fun int(c: Context, key: String, def: Int = 5): Int = sp(c).getInt(key, def)
    fun setInt(c: Context, key: String, v: Int) = sp(c).edit().putInt(key, v).apply()
}
