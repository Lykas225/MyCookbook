package com.ikeyboard.ai

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Хранит только название карты и последние четыре цифры. Полный номер и CVV не сохраняются. */
class SecureCardVault(context: Context) {
    private val prefs = context.getSharedPreferences("secure_card_vault", Context.MODE_PRIVATE)
    private val alias = "ikeyboard_card_vault_key"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    fun hasPin() = prefs.contains("pin_hash")
    fun setPin(pin: String) {
        prefs.edit().putString("pin_hash", sha256(pin)).apply()
    }
    fun verifyPin(pin: String) = prefs.getString("pin_hash", null) == sha256(pin)

    fun saveCards(cards: List<Pair<String, String>>) {
        val plain = cards.joinToString("\n") { (name, last4) ->
            Base64.encodeToString(name.toByteArray(Charsets.UTF_8), Base64.NO_WRAP) + ":" + last4
        }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        val packed = cipher.iv + encrypted
        prefs.edit().putString("cards", Base64.encodeToString(packed, Base64.NO_WRAP)).apply()
    }

    fun loadCards(): List<Pair<String, String>> {
        val packed = Base64.decode(prefs.getString("cards", "") ?: "", Base64.DEFAULT)
        if (packed.size < 13) return emptyList()
        val iv = packed.copyOfRange(0, 12)
        val data = packed.copyOfRange(12, packed.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        val plain = cipher.doFinal(data).toString(Charsets.UTF_8)
        return plain.lines().filter { it.contains(':') }.mapNotNull {
            val name64 = it.substringBefore(':')
            val last4 = it.substringAfter(':')
            try { Base64.decode(name64, Base64.DEFAULT).toString(Charsets.UTF_8) to last4 }
            catch (e: Exception) { null }
        }
    }

    fun clear() { prefs.edit().remove("cards").apply() }

    private fun sha256(value: String): String = java.security.MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}
