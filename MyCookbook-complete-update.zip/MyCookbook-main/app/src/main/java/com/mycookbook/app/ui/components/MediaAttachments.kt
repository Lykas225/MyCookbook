package com.mycookbook.app.ui.components

import android.media.MediaController
import android.net.Uri
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.mycookbook.app.data.model.MediaAttachment
import com.mycookbook.app.data.storage.MediaFileManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun MediaAttachmentsEditor(
    photos: List<MediaAttachment>,
    videos: List<MediaAttachment>,
    onPhotosChange: (List<MediaAttachment>) -> Unit,
    onVideosChange: (List<MediaAttachment>) -> Unit,
    textColor: Color
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isCopying by remember { mutableStateOf(false) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(20)
    ) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch {
                isCopying = true
                val copied = withContext(Dispatchers.IO) {
                    uris.mapNotNull { uri ->
                        MediaFileManager.copyFromUri(context, uri, "PHOTO")
                    }
                }
                onPhotosChange(photos + copied)
                isCopying = false
            }
        }
    }

    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(10)
    ) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch {
                isCopying = true
                val copied = withContext(Dispatchers.IO) {
                    uris.mapNotNull { uri ->
                        MediaFileManager.copyFromUri(context, uri, "VIDEO")
                    }
                }
                onVideosChange(videos + copied)
                isCopying = false
            }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            "Фотографии и видео",
            color = textColor,
            style = MaterialTheme.typography.titleMedium
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = {
                    photoPicker.launch(
                        PickVisualMediaRequest(
                            ActivityResultContracts.PickVisualMedia.ImageOnly
                        )
                    )
                },
                enabled = !isCopying,
                modifier = Modifier.weight(1f)
            ) {
                Text("＋ Фото")
            }

            OutlinedButton(
                onClick = {
                    videoPicker.launch(
                        PickVisualMediaRequest(
                            ActivityResultContracts.PickVisualMedia.VideoOnly
                        )
                    )
                },
                enabled = !isCopying,
                modifier = Modifier.weight(1f)
            ) {
                Text("＋ Видео")
            }
        }

        if (isCopying) {
            LinearProgressIndicator(Modifier.fillMaxWidth())
            Text("Сохраняем выбранные файлы…", color = textColor)
        }

        if (photos.isNotEmpty()) {
            Text("Фотографии: ${photos.size}", color = textColor)
            photos.forEach { item ->
                MediaAttachmentEditorRow(
                    item = item,
                    onDelete = {
                        onPhotosChange(photos.filterNot { it.id == item.id })
                    }
                )
            }
        }

        if (videos.isNotEmpty()) {
            Text("Видео: ${videos.size}", color = textColor)
            videos.forEach { item ->
                MediaAttachmentEditorRow(
                    item = item,
                    onDelete = {
                        onVideosChange(videos.filterNot { it.id == item.id })
                    }
                )
            }
        }

        if (photos.isEmpty() && videos.isEmpty()) {
            Text(
                "Пока ничего не прикреплено",
                color = textColor.copy(alpha = 0.7f),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun MediaAttachmentEditorRow(
    item: MediaAttachment,
    onDelete: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (item.type == "PHOTO") {
            AsyncImage(
                model = mediaImageModel(item.path),
                contentDescription = item.name,
                modifier = Modifier
                    .size(width = 88.dp, height = 68.dp),
                contentScale = ContentScale.Crop
            )
        } else {
            Surface(
                modifier = Modifier.size(width = 88.dp, height = 68.dp),
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("▶ Видео")
                }
            }
        }

        Spacer(Modifier.width(10.dp))

        Text(
            text = item.name.ifBlank { if (item.type == "VIDEO") "Видео" else "Фото" },
            modifier = Modifier.weight(1f),
            maxLines = 2,
            style = MaterialTheme.typography.bodySmall
        )

        TextButton(onClick = onDelete) {
            Text("Удалить")
        }
    }
}

@Composable
fun MediaAttachmentGallery(
    title: String,
    media: List<MediaAttachment>,
    textColor: Color
) {
    var selected by remember { mutableStateOf<MediaAttachment?>(null) }

    if (media.isNotEmpty()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                title,
                color = textColor,
                style = MaterialTheme.typography.titleMedium
            )

            media.forEach { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selected = item },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (item.type == "PHOTO") {
                            AsyncImage(
                                model = mediaImageModel(item.path),
                                contentDescription = item.name,
                                modifier = Modifier.size(76.dp),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Surface(
                                modifier = Modifier.size(76.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text("▶")
                                }
                            }
                        }

                        Spacer(Modifier.width(12.dp))

                        Column(Modifier.weight(1f)) {
                            Text(
                                item.name.ifBlank {
                                    if (item.type == "VIDEO") "Видео" else "Фото"
                                },
                                color = textColor
                            )
                            Text(
                                if (item.type == "VIDEO") "Нажми для просмотра видео"
                                else "Нажми для просмотра фотографии",
                                color = textColor.copy(alpha = 0.7f),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }

    selected?.let { item ->
        MediaViewerDialog(item = item, onDismiss = { selected = null })
    }
}

@Composable
fun MediaViewerDialog(
    item: MediaAttachment,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = Color.Black
        ) {
            if (item.type == "PHOTO") {
                AsyncImage(
                    model = mediaImageModel(item.path),
                    contentDescription = item.name,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 620.dp),
                    contentScale = ContentScale.Fit
                )
            } else {
                val videoView = remember(item.path) {
                    VideoView(context)
                }

                DisposableEffect(videoView, item.path) {
                    val controller = MediaController(context)
                    controller.setAnchorView(videoView)
                    videoView.setMediaController(controller)
                    videoView.setVideoURI(Uri.fromFile(File(item.path)))
                    videoView.setOnPreparedListener { player ->
                        player.isLooping = false
                        videoView.start()
                    }

                    onDispose {
                        videoView.stopPlayback()
                    }
                }

                AndroidView(
                    factory = { videoView },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                )
            }
        }
    }
}


private fun mediaImageModel(path: String): Any {
    return if (path.startsWith("https://") || path.startsWith("http://")) {
        path
    } else {
        File(path)
    }
}
