package com.mycookbook.app.data.repository

import android.content.Context
import com.mycookbook.app.data.model.MediaAttachment
import com.mycookbook.app.data.model.NotebookNote
import com.mycookbook.app.data.model.Recipe
import com.mycookbook.app.data.storage.CookbookStorage
import com.mycookbook.app.data.storage.MediaFileManager

class CookbookRepository(context: Context) {

    private val appContext = context.applicationContext
    private val storage = CookbookStorage(appContext)

    fun getRecipes(): List<Recipe> = storage.loadRecipes()

    fun getNotes(): List<NotebookNote> = storage.loadNotes()

    fun addRecipe(recipe: Recipe) {
        val recipes = getRecipes().toMutableList()
        recipes.add(recipe)
        storage.saveRecipes(recipes)
    }

    fun updateRecipe(recipe: Recipe) {
        val current = getRecipes()
        val oldRecipe = current.firstOrNull { it.id == recipe.id }

        if (oldRecipe != null) {
            val retainedIds = recipeMedia(recipe).map { it.id }.toSet()
            recipeMedia(oldRecipe)
                .filterNot { it.id in retainedIds }
                .forEach { MediaFileManager.delete(appContext, it) }
        }

        val updated = current.map {
            if (it.id == recipe.id) {
                recipe.copy(updatedAt = System.currentTimeMillis())
            } else {
                it
            }
        }
        storage.saveRecipes(updated)
    }

    fun deleteRecipe(id: String) {
        val current = getRecipes()
        current.firstOrNull { it.id == id }?.let { recipe ->
            recipeMedia(recipe).forEach {
                MediaFileManager.delete(appContext, it)
            }
        }
        storage.saveRecipes(current.filterNot { it.id == id })
    }

    fun toggleFavorite(id: String) {
        val recipes = getRecipes().map {
            if (it.id == id) {
                it.copy(
                    isFavorite = !it.isFavorite,
                    updatedAt = System.currentTimeMillis()
                )
            } else {
                it
            }
        }

        storage.saveRecipes(recipes)
    }

    fun getFavoriteRecipes(): List<Recipe> {
        return getRecipes().filter { it.isFavorite }
    }

    fun addNote(note: NotebookNote) {
        val notes = getNotes().toMutableList()
        notes.add(note)
        storage.saveNotes(notes)
    }

    fun updateNote(note: NotebookNote) {
        val current = getNotes()
        val oldNote = current.firstOrNull { it.id == note.id }

        if (oldNote != null) {
            val retainedIds = noteMedia(note).map { it.id }.toSet()
            noteMedia(oldNote)
                .filterNot { it.id in retainedIds }
                .forEach { MediaFileManager.delete(appContext, it) }
        }

        val updated = current.map {
            if (it.id == note.id) {
                note.copy(updatedAt = System.currentTimeMillis())
            } else {
                it
            }
        }

        storage.saveNotes(updated)
    }

    fun deleteNote(id: String) {
        val current = getNotes()
        current.firstOrNull { it.id == id }?.let { note ->
            noteMedia(note).forEach {
                MediaFileManager.delete(appContext, it)
            }
        }
        storage.saveNotes(current.filterNot { it.id == id })
    }

    fun clearAllData() {
        (getRecipes().flatMap { recipeMedia(it) } +
            getNotes().flatMap { noteMedia(it) })
            .forEach { MediaFileManager.delete(appContext, it) }

        storage.clearAll()
    }

    private fun recipeMedia(recipe: Recipe): List<MediaAttachment> {
        return recipe.photos +
            recipe.videos +
            recipe.steps.flatMap { it.photos + it.videos }
    }

    private fun noteMedia(note: NotebookNote): List<MediaAttachment> {
        return note.photos + note.videos
    }
}
