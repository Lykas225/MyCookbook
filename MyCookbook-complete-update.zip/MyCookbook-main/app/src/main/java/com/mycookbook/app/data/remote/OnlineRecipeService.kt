package com.mycookbook.app.data.remote

import com.mycookbook.app.data.model.CookingStep
import com.mycookbook.app.data.model.MediaAttachment
import com.mycookbook.app.data.model.Recipe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class OnlineRecipe(
    val id: String,
    val title: String,
    val category: String,
    val area: String,
    val instructions: String,
    val ingredients: List<String>,
    val imageUrl: String,
    val sourceUrl: String,
    val videoUrl: String
) {
    fun toLocalRecipe(): Recipe {
        val stepDescriptions = instructions
            .split(Regex("\\r?\\n+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .ifEmpty { listOf(instructions.trim()).filter { it.isNotBlank() } }

        val photoList = if (imageUrl.isNotBlank()) {
            listOf(
                MediaAttachment(
                    name = "Фото из интернет-рецепта",
                    path = imageUrl,
                    type = "PHOTO"
                )
            )
        } else {
            emptyList()
        }

        return Recipe(
            title = title,
            description = listOf(area, category).filter { it.isNotBlank() }
                .joinToString(" · "),
            category = category.ifBlank { "Из интернета" },
            ingredients = ingredients,
            steps = stepDescriptions.mapIndexed { index, text ->
                CookingStep(
                    number = index + 1,
                    title = "Шаг ${index + 1}",
                    description = text
                )
            },
            photos = photoList,
            sourceUrl = sourceUrl,
            videoUrl = videoUrl
        )
    }
}

object OnlineRecipeService {
    suspend fun search(query: String): List<OnlineRecipe> = withContext(Dispatchers.IO) {
        val encoded = URLEncoder.encode(query.trim(), "UTF-8")
        val url = URL("https://www.themealdb.com/api/json/v1/1/search.php?s=$encoded")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12000
            readTimeout = 15000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "MyCookbook-Android")
        }

        try {
            val responseCode = connection.responseCode
            if (responseCode !in 200..299) {
                throw IllegalStateException("Сервис рецептов ответил с кодом $responseCode")
            }

            val response = connection.inputStream.bufferedReader(Charsets.UTF_8).use {
                it.readText()
            }
            val meals = JSONObject(response).optJSONArray("meals")
                ?: return@withContext emptyList()

            buildList {
                for (index in 0 until meals.length()) {
                    val meal = meals.optJSONObject(index) ?: continue
                    val ingredients = mutableListOf<String>()

                    for (number in 1..20) {
                        val ingredient = meal.optString("strIngredient$number").trim()
                        if (ingredient.isNotBlank() && ingredient != "null") {
                            val measure = meal.optString("strMeasure$number")
                                .trim()
                                .takeUnless { it.isBlank() || it == "null" }
                                .orEmpty()
                            ingredients += listOf(measure, ingredient)
                                .filter { it.isNotBlank() }
                                .joinToString(" ")
                        }
                    }

                    val mealId = meal.optString("idMeal")
                    val mealTitle = meal.optString("strMeal")
                    val instructions = meal.optString("strInstructions")
                        .replace("\r\n", "\n")
                        .trim()

                    if (mealId.isNotBlank() && mealTitle.isNotBlank()) {
                        add(
                            OnlineRecipe(
                                id = mealId,
                                title = mealTitle,
                                category = meal.optString("strCategory").orEmpty(),
                                area = meal.optString("strArea").orEmpty(),
                                instructions = instructions,
                                ingredients = ingredients,
                                imageUrl = meal.optString("strMealThumb").orEmpty(),
                                sourceUrl = meal.optString("strSource").orEmpty()
                                    .ifBlank { "https://www.themealdb.com/meal/$mealId" },
                                videoUrl = meal.optString("strYoutube").orEmpty()
                            )
                        )
                    }
                }
            }
        } finally {
            connection.disconnect()
        }
    }
}
