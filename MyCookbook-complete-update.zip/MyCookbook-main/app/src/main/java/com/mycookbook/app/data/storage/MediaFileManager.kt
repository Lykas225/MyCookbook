package com.mycookbook.app.data.storage

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import com.mycookbook.app.data.model.MediaAttachment
import java.io.File
import java.util.UUID

object MediaFileManager {

    fun copyFromUri(
        context: Context,
        uri: Uri,
        type: String
    ): MediaAttachment? {
        return try {
            val resolver = context.contentResolver
            val originalName = queryDisplayName(context, uri)
            val mimeType = resolver.getType(uri)
            val extensionFromMime = mimeType
                ?.let { MimeTypeMap.getSingleton().getExtensionFromMimeType(it) }

            val extensionFromName = originalName
                .substringAfterLast('.', "")
                .takeIf { it.isNotBlank() && it.length <= 8 }

            val fallbackExtension = if (type == "VIDEO") "mp4" else "jpg"
            val extension = (extensionFromMime ?: extensionFromName ?: fallbackExtension)
                .filter { it.isLetterOrDigit() }
                .take(8)
                .lowercase()
                .ifBlank { fallbackExtension }

            val folderName = if (type == "VIDEO") "videos" else "photos"
            val directory = File(context.filesDir, "media/$folderName")
            if (!directory.exists() && !directory.mkdirs()) {
                return null
            }

            val destination = File(directory, "${UUID.randomUUID()}.$extension")
            val input = resolver.openInputStream(uri) ?: return null

            input.use { source ->
                destination.outputStream().use { output ->
                    source.copyTo(output)
                }
            }

            if (!destination.exists() || destination.length() == 0L) {
                destination.delete()
                return null
            }

            MediaAttachment(
                name = originalName.ifBlank {
                    if (type == "VIDEO") "Видео" else "Фото"
                },
                path = destination.absolutePath,
                type = type
            )
        } catch (_: Exception) {
            null
        }
    }

    fun delete(context: Context, attachment: MediaAttachment) {
        try {
            val mediaRoot = File(context.filesDir, "media").canonicalFile
            val file = File(attachment.path).canonicalFile
            val rootPath = mediaRoot.path + File.separator

            if (file.path.startsWith(rootPath)) {
                file.delete()
            }
        } catch (_: Exception) {
            // Ошибка удаления файла не должна останавливать приложение
        }
    }

    private fun queryDisplayName(context: Context, uri: Uri): String {
        return try {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) cursor.getString(index).orEmpty() else ""
                } else {
                    ""
                }
            }.orEmpty()
        } catch (_: Exception) {
            ""
        }
    }
}
