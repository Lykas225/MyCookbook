package com.mycookbook.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.mycookbook.app.data.model.CookingStep
import com.mycookbook.app.data.model.MediaAttachment
import com.mycookbook.app.data.model.Recipe
import com.mycookbook.app.ui.components.MediaAttachmentsEditor

private data class StepDraft(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String = "",
    val description: String = "",
    val photos: List<MediaAttachment> = emptyList(),
    val videos: List<MediaAttachment> = emptyList()
)

@Composable
fun RecipeEditorScreen(
    recipe: Recipe?,
    textColor: Color,
    onBack: () -> Unit,
    onSave: (Recipe) -> Unit
) {
    var title by remember(recipe?.id) { mutableStateOf(recipe?.title ?: "") }
    var description by remember(recipe?.id) { mutableStateOf(recipe?.description ?: "") }
    var category by remember(recipe?.id) { mutableStateOf(recipe?.category ?: "Другое") }
    var ingredients by remember(recipe?.id) {
        mutableStateOf(recipe?.ingredients?.joinToString("\n") ?: "")
    }
    var photos by remember(recipe?.id) {
        mutableStateOf(recipe?.photos ?: emptyList())
    }
    var videos by remember(recipe?.id) {
        mutableStateOf(recipe?.videos ?: emptyList())
    }
    var stepDrafts by remember(recipe?.id) {
        mutableStateOf(
            recipe?.steps?.map { step ->
                StepDraft(
                    id = step.id,
                    title = step.title,
                    description = step.description,
                    photos = step.photos,
                    videos = step.videos
                )
            }?.ifEmpty { listOf(StepDraft()) } ?: listOf(StepDraft())
        )
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        TextButton(onClick = onBack) { Text("← Назад") }

        Text(
            if (recipe == null) "Новый рецепт" else "Изменить рецепт",
            color = textColor,
            style = MaterialTheme.typography.headlineSmall
        )

        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Название блюда") },
            singleLine = true
        )

        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            value = category,
            onValueChange = { category = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Категория") },
            singleLine = true
        )

        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            value = description,
            onValueChange = { description = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Описание блюда") },
            minLines = 3
        )

        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            value = ingredients,
            onValueChange = { ingredients = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Ингредиенты — каждый с новой строки") },
            minLines = 5
        )

        Spacer(Modifier.height(18.dp))

        MediaAttachmentsEditor(
            photos = photos,
            videos = videos,
            onPhotosChange = { photos = it },
            onVideosChange = { videos = it },
            textColor = textColor
        )

        Spacer(Modifier.height(22.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                "Шаги приготовления",
                color = textColor,
                style = MaterialTheme.typography.titleLarge
            )

            TextButton(
                onClick = { stepDrafts = stepDrafts + StepDraft() }
            ) {
                Text("+ Добавить шаг")
            }
        }

        stepDrafts.forEachIndexed { index, draft ->
            key(draft.id) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "Шаг ${index + 1}",
                                color = textColor,
                                style = MaterialTheme.typography.titleMedium
                            )

                            TextButton(
                                onClick = {
                                    stepDrafts = stepDrafts.filterNot {
                                        it.id == draft.id
                                    }
                                }
                            ) {
                                Text("Удалить шаг")
                            }
                        }

                        OutlinedTextField(
                            value = draft.title,
                            onValueChange = { value ->
                                stepDrafts = stepDrafts.map {
                                    if (it.id == draft.id) it.copy(title = value) else it
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Название шага") },
                            singleLine = true
                        )

                        Spacer(Modifier.height(8.dp))

                        OutlinedTextField(
                            value = draft.description,
                            onValueChange = { value ->
                                stepDrafts = stepDrafts.map {
                                    if (it.id == draft.id) it.copy(description = value) else it
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Что нужно сделать") },
                            minLines = 3
                        )

                        Spacer(Modifier.height(10.dp))

                        MediaAttachmentsEditor(
                            photos = draft.photos,
                            videos = draft.videos,
                            onPhotosChange = { value ->
                                stepDrafts = stepDrafts.map {
                                    if (it.id == draft.id) it.copy(photos = value) else it
                                }
                            },
                            onVideosChange = { value ->
                                stepDrafts = stepDrafts.map {
                                    if (it.id == draft.id) it.copy(videos = value) else it
                                }
                            },
                            textColor = textColor
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        Button(
            onClick = {
                if (title.isNotBlank()) {
                    val stepList = stepDrafts
                        .filter {
                            it.title.isNotBlank() ||
                                it.description.isNotBlank() ||
                                it.photos.isNotEmpty() ||
                                it.videos.isNotEmpty()
                        }
                        .mapIndexed { index, draft ->
                            CookingStep(
                                id = draft.id,
                                number = index + 1,
                                title = draft.title.trim().ifBlank { "Шаг ${index + 1}" },
                                description = draft.description.trim(),
                                photos = draft.photos,
                                videos = draft.videos
                            )
                        }

                    val updated = Recipe(
                        id = recipe?.id ?: java.util.UUID.randomUUID().toString(),
                        title = title.trim(),
                        description = description.trim(),
                        category = category.trim().ifBlank { "Другое" },
                        ingredients = ingredients.lines()
                            .map { it.trim() }
                            .filter { it.isNotBlank() },
                        steps = stepList,
                        photos = photos,
                        videos = videos,
                        isFavorite = recipe?.isFavorite ?: false,
                        createdAt = recipe?.createdAt ?: System.currentTimeMillis(),
                        updatedAt = System.currentTimeMillis(),
                        sourceUrl = recipe?.sourceUrl ?: "",
                        videoUrl = recipe?.videoUrl ?: ""
                    )

                    onSave(updated)
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = title.isNotBlank()
        ) {
            Text("Сохранить рецепт")
        }

        Spacer(Modifier.height(24.dp))
    }
}
