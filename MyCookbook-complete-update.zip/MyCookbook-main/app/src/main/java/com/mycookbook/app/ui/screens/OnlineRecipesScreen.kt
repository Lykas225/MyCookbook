package com.mycookbook.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.mycookbook.app.data.remote.OnlineRecipe
import com.mycookbook.app.data.remote.OnlineRecipeService
import kotlinx.coroutines.launch

@Composable
fun OnlineRecipesScreen(
    textColor: Color,
    card: Color,
    accent: Color,
    onBack: () -> Unit,
    onImport: (OnlineRecipe) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<OnlineRecipe>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var searched by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var importedIds by remember { mutableStateOf(setOf<String>()) }
    val scope = rememberCoroutineScope()

    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        TextButton(onClick = onBack) { Text("← Назад") }

        Text(
            "Поиск рецептов в интернете 🌐",
            color = textColor,
            style = MaterialTheme.typography.headlineSmall
        )

        Spacer(Modifier.height(6.dp))

        Text(
            "Ищем блюда в открытой базе TheMealDB. Найденный рецепт можно сохранить в свою книгу",
            color = textColor,
            style = MaterialTheme.typography.bodySmall
        )

        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Название блюда, например chicken curry") },
            singleLine = true
        )

        Spacer(Modifier.height(8.dp))

        Button(
            onClick = {
                if (query.isNotBlank() && !loading) {
                    scope.launch {
                        loading = true
                        error = null
                        searched = true
                        try {
                            results = OnlineRecipeService.search(query)
                        } catch (exception: Exception) {
                            results = emptyList()
                            error = exception.message
                                ?: "Не удалось выполнить поиск. Проверь подключение к интернету"
                        } finally {
                            loading = false
                        }
                    }
                }
            },
            enabled = query.isNotBlank() && !loading,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (loading) "Ищем…" else "Найти рецепты")
        }

        Spacer(Modifier.height(12.dp))

        if (loading) {
            LinearProgressIndicator(Modifier.fillMaxWidth())
        }

        error?.let {
            Text(
                "Ошибка поиска: $it",
                color = MaterialTheme.colorScheme.error
            )
        }

        if (!loading && searched && results.isEmpty() && error == null) {
            Text(
                "Ничего не найдено. Попробуй название на английском языке",
                color = textColor
            )
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(results, key = { it.id }) { recipe ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = card)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        if (recipe.imageUrl.isNotBlank()) {
                            AsyncImage(
                                model = recipe.imageUrl,
                                contentDescription = recipe.title,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(170.dp),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(Modifier.height(8.dp))
                        }

                        Text(
                            recipe.title,
                            color = textColor,
                            style = MaterialTheme.typography.titleLarge
                        )

                        val subtitle = listOf(recipe.area, recipe.category)
                            .filter { it.isNotBlank() }
                            .joinToString(" · ")

                        if (subtitle.isNotBlank()) {
                            Text(subtitle, color = accent)
                        }

                        Text(
                            "Ингредиентов: ${recipe.ingredients.size}",
                            color = textColor
                        )

                        Spacer(Modifier.height(8.dp))

                        Text(
                            recipe.ingredients.take(6).joinToString(" • "),
                            color = textColor,
                            style = MaterialTheme.typography.bodySmall
                        )

                        Spacer(Modifier.height(10.dp))

                        Button(
                            onClick = {
                                onImport(recipe)
                                importedIds = importedIds + recipe.id
                            },
                            enabled = recipe.id !in importedIds,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                if (recipe.id in importedIds) "Добавлено в книгу ✓"
                                else "Добавить в кулинарную книгу"
                            )
                        }
                    }
                }
            }
        }
    }
}
