package com.mycookbook.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import com.mycookbook.app.data.model.MediaAttachment
import com.mycookbook.app.ui.components.MediaViewerDialog
import java.io.File

@Composable
fun GalleryScreen(
    media: List<MediaAttachment>,
    videosOnly: Boolean,
    textColor: Color,
    onBack: () -> Unit
) {
    val filtered = media.filter {
        if (videosOnly) it.type == "VIDEO" else it.type == "PHOTO"
    }
    var selected by remember { mutableStateOf<MediaAttachment?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TextButton(onClick = onBack) { Text("← Назад") }

        Text(
            if (videosOnly) "Видео приготовления 🎬" else "Фото блюд 📷",
            color = textColor,
            style = MaterialTheme.typography.headlineSmall
        )

        Spacer(Modifier.height(14.dp))

        if (filtered.isEmpty()) {
            Text(
                "Здесь пока пусто. Добавленные к рецептам и записям файлы появятся здесь",
                color = textColor
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(filtered, key = { it.id }) { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selected = item }
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text(
                                item.name.ifBlank {
                                    if (item.type == "VIDEO") "Видео" else "Фото"
                                }
                            )

                            if (item.type == "PHOTO") {
                                AsyncImage(
                                    model = if (item.path.startsWith("http://") || item.path.startsWith("https://")) item.path else File(item.path),
                                    contentDescription = item.name,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(max = 260.dp),
                                    contentScale = ContentScale.Fit
                                )
                            } else {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 18.dp),
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Button(onClick = { selected = item }) {
                                        Text("▶ Воспроизвести видео")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    selected?.let { item ->
        MediaViewerDialog(
            item = item,
            onDismiss = { selected = null }
        )
    }
}
