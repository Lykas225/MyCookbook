package com.mycookbook.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.mycookbook.app.data.model.Recipe

@Composable
fun AssistantScreen(
    recipes: List<Recipe>,
    textColor: Color,
    card: Color,
    onBack: () -> Unit,
    onOpenRecipe: (Recipe) -> Unit,
    onSearchOnline: () -> Unit
) {
    var ingredientsText by remember { mutableStateOf("") }
    var matchedRecipes by remember { mutableStateOf<List<Recipe>>(emptyList()) }
    var searched by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        TextButton(onClick = onBack) { Text("← Назад") }

        Text(
            "Кулинарный помощник 🤖",
            color = textColor,
            style = MaterialTheme.typography.headlineSmall
        )

        Spacer(Modifier.height(8.dp))

        Text(
            "Напиши продукты, которые есть дома. Помощник найдёт подходящие рецепты из твоей кулинарной книги",
            color = textColor
        )

        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = ingredientsText,
            onValueChange = { ingredientsText = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Например: курица, картофель, сыр") },
            minLines = 3
        )

        Spacer(Modifier.height(8.dp))

        Button(
            onClick = {
                val terms = ingredientsText
                    .split(",", ";", "\n")
                    .map { it.trim() }
                    .filter { it.isNotBlank() }

                matchedRecipes = if (terms.isEmpty()) {
                    emptyList()
                } else {
                    recipes.mapNotNull { recipe ->
                        val haystack = (recipe.title + " " + recipe.ingredients.joinToString(" "))
                            .lowercase()
                        val matches = terms.count { term ->
                            haystack.contains(term.lowercase())
                        }
                        if (matches > 0) recipe to matches else null
                    }.sortedByDescending { it.second }.map { it.first }
                }
                searched = true
            },
            enabled = ingredientsText.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Подобрать мои рецепты")
        }

        OutlinedButton(
            onClick = onSearchOnline,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Найти новые рецепты в интернете")
        }

        Spacer(Modifier.height(12.dp))

        if (searched && matchedRecipes.isEmpty()) {
            Text(
                "Подходящих сохранённых рецептов не найдено. Попробуй поиск в интернете",
                color = textColor
            )
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(matchedRecipes, key = { it.id }) { recipe ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = card)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(
                            recipe.title,
                            color = textColor,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            recipe.ingredients.take(5).joinToString(" • "),
                            color = textColor
                        )
                        TextButton(onClick = { onOpenRecipe(recipe) }) {
                            Text("Открыть рецепт")
                        }
                    }
                }
            }
        }

        Text(
            "Подбор по сохранённым рецептам работает без интернета. Генеративный ИИ можно подключить позднее через отдельный безопасный сервис и ключ API",
            color = textColor.copy(alpha = 0.7f),
            style = MaterialTheme.typography.bodySmall
        )
    }
}
